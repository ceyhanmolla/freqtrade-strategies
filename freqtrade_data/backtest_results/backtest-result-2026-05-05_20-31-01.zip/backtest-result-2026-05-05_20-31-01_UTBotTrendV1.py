"""
UTBotTrendV1 - UTBot Alerts Strategy (Futures Ready)
====================================================

STRATEJİ AÇIKLAMASI:
- ATR-based trailing stop
- Long ve Short pozisyon desteği (futures mod)
- can_short = True ile aktif

YAPILANDIRMA:
- trading_mode: futures
- margin_mode: isolated
- can_short: True

Author: Engineering from Medium doc
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import numpy as np
import talib.abstract as ta


class UTBotTrendV1(IStrategy):
    INTERFACE_VERSION = 2

    # Futures için short aktif
    can_short = True

    minimal_roi = {
        "0": 0.3,
        "30": 0.6,
        "60": 1.0,
        "180": 1.5,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.008
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    use_exit_signal = False
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 300

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        atr = ta.ATR(dataframe, timeperiod=3)
        highest_high = dataframe['high'].rolling(3).max()
        lowest_low = dataframe['low'].rolling(3).min()
        
        dataframe['atr_stop_long'] = highest_high - (atr * 1.5)
        dataframe['atr_stop_short'] = lowest_low + (atr * 1.5)
        
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_trend'] = np.where(dataframe['ema_50'] > dataframe['ema_200'], 1, -1)
        
        dataframe['adx'] = ta.ADX(dataframe)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0
        
        # Simplified conditions for futures
        long_conditions = (
            (dataframe['close'] > dataframe['atr_stop_long']) &
            (dataframe['ema_trend'] == 1) &
            (dataframe['adx'] > 10) &
            (dataframe['rsi'] < 70) &
            (dataframe['volume'] > 0)
        )
        
        short_conditions = (
            (dataframe['close'] < dataframe['atr_stop_short']) &
            (dataframe['ema_trend'] == -1) &
            (dataframe['adx'] > 10) &
            (dataframe['rsi'] > 30) &
            (dataframe['volume'] > 0)
        )
        
        dataframe.loc[long_conditions, 'enter_long'] = 1
        dataframe.loc[short_conditions, 'enter_short'] = 1
        
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0
        return dataframe