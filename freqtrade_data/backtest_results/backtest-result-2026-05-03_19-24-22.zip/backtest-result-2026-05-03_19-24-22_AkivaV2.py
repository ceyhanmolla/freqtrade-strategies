# AkivaV2 - Modern EWO Strategy (Fixed)
# Target: 1+ trade/day with positive returns

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta
import numpy as np
from datetime import datetime


class AkivaV2(IStrategy):
    INTERFACE_VERSION = 3
    
    timeframe = '5m'
    inf_1h = '1h'
    
    # ROI - daha uzun süre pozisyonda kalmak için
    minimal_roi = {
        "0": 0.025,
        "20": 0.015,
        "60": 0.008,
        "180": 0,
    }
    
    # Stoploss - basit static
    stoploss = -0.015
    use_custom_stoploss = False
    
    # Trailing stop - DISABLED for now
    trailing_stop = False
    
    # Sell signals
    use_exit_signal = True
    exit_profit_only = True
    ignore_roi_if_entry_signal = False
    
    # Processing
    process_only_new_candles = True
    startup_candle_count = 400
    exit_timeout = 720
    
    @property
    def protections(self):
        return [
            {"method": "CooldownPeriod", "stop_duration_candles": 5},
            {"method": "MaxDrawdown", "lookback_period_candles": 48, "trade_limit": 20, 
             "stop_duration_candles": 4, "max_allowed_drawdown": 0.2},
            {"method": "StoplossGuard", "lookback_period_candles": 24, "trade_limit": 4, 
             "stop_duration_candles": 2, "only_per_pair": False},
        ]
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)
        
        # EMAs
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        # SMA
        dataframe['sma_9'] = ta.SMA(dataframe, timeperiod=9)
        dataframe['sma_200'] = ta.SMA(dataframe, timeperiod=200)
        
        # EWO - Elliot Wave Oscillator
        ema_fast = ta.EMA(dataframe, timeperiod=50)
        ema_slow = ta.EMA(dataframe, timeperiod=200)
        dataframe['EWO'] = (ema_fast - ema_slow) / dataframe['close'] * 100
        
        # HMA (Hull Moving Average)
        dataframe['hma_50'] = self._hull_ma(dataframe['close'], 50)
        
        # ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        
        # Volume MA
        dataframe['volume_ma'] = dataframe['volume'].rolling(20).mean()
        
        return dataframe
    
    def _hull_ma(self, series, window):
        wma1 = series.rolling(int(window/2)).mean()
        wma2 = series.rolling(window).mean()
        hull = (2 * wma1 - wma2).rolling(int(np.sqrt(window))).mean()
        return hull
    
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Condition 1: EWO High (bullish momentum) + RSI oversold
        cond1 = (
            (dataframe['rsi_fast'] < 40) &
            (dataframe['EWO'] > 2.5) &
            (dataframe['close'] < dataframe['ema_50'] * 0.97)
        )
        
        # Condition 2: RSI oversold
        cond2 = (dataframe['rsi'] < 30)
        
        # Condition 3: EWO Low (dip buy)
        cond3 = (
            (dataframe['EWO'] < -4) &
            (dataframe['rsi_fast'] < 35) &
            (dataframe['close'] < dataframe['ema_50'] * 0.93)
        )
        
        dataframe.loc[cond1 | cond2 | cond3, 'enter_long'] = 1
        return dataframe
    
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Daha az agresif çıkış koşulları
        # Sell 1: RSI aşırı alım (daha yüksek eşik)
        cond1 = (dataframe['rsi'] > 75) & (dataframe['rsi'] < dataframe['rsi'].shift(1))
        
        # Sell 2: Strong momentum kaybı
        cond2 = (dataframe['EWO'] < -2) & (dataframe['rsi_fast'] > 65) & (dataframe['close'] < dataframe['open'])
        
        # Sell 3: Fiyat önemli düşüş
        cond3 = (dataframe['close'] < dataframe['ema_20'] * 0.95) & (dataframe['close'] < dataframe['open'])
        
        dataframe.loc[cond1 | cond2 | cond3, 'exit_long'] = 1
        return dataframe
    
    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        if current_profit < -0.02:
            return 0.001
        if current_profit < -0.01:
            return 0.01
        if current_profit < 0:
            return 0.015
        if current_profit > 0.15:
            return 0.05
        if current_profit > 0.08:
            return 0.03
        if current_profit > 0.04:
            return 0.02
        if current_profit > 0.02:
            return 0.015
        return self.stoploss
    
    def confirm_trade_exit(self, pair: str, trade: 'Trade', order_type: str, amount: float,
                           rate: float, time_in_force: str, sell_reason: str,
                           current_time: datetime, **kwargs) -> bool:
        return True