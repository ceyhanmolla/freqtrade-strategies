from freqtrade.strategy import IStrategy, informative
from pandas import DataFrame
from datetime import datetime
from freqtrade.persistence import Trade

import talib.abstract as ta


def EWO(dataframe, sma_fast_length=50, sma_slow_length=200):
    sma_fast = ta.SMA(dataframe, timeperiod=sma_fast_length)
    sma_slow = ta.SMA(dataframe, timeperiod=sma_slow_length)
    return (sma_fast - sma_slow) / dataframe['close'] * 100


class EwoMomentumV1F(IStrategy):
    INTERFACE_VERSION = 3
    can_short = True

    minimal_roi = {
        "0": 0.03,
        "120": 0.015,
    }

    stoploss = -0.10

    use_custom_stoploss = True

    trailing_stop = False

    use_exit_signal = True

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    @informative('1h')
    def populate_indicators_1h(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_mean_20'] = dataframe['volume'].rolling(20).mean()
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, entry_tag: str | None, side: str,
                 **kwargs) -> float:
        return 1.0

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, after_fill: bool,
                        **kwargs) -> float | None:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or dataframe.empty:
            return -0.10
        last_candle = dataframe.iloc[-1].copy()
        atr = last_candle.get('atr', None)
        if atr is None or atr <= 0 or current_rate <= 0:
            return -0.10
        atr_pct = atr / current_rate
        stoploss_ratio = -(atr_pct * 4.0)
        return max(min(stoploss_ratio, -0.03), -0.10) * trade.leverage

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_short'] = 0

        long_cond1 = (
            (dataframe['EWO_1h'] > 0) &
            (dataframe['EWO'] > 0) &
            (dataframe['rsi'] < 45) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_mean_20'] * 3)
        )

        long_cond2 = (
            (dataframe['EWO_1h'] > 0) &
            (dataframe['EWO'] < -1.5) &
            (dataframe['rsi'] < 35) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] > dataframe['volume_mean_20'] * 0.5)
        )

        short_cond1 = (
            (dataframe['EWO_1h'] < 0) &
            (dataframe['EWO'] < 0) &
            (dataframe['rsi'] > 55) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_mean_20'] * 3)
        )

        short_cond2 = (
            (dataframe['EWO_1h'] < 0) &
            (dataframe['EWO'] > 1.5) &
            (dataframe['rsi'] > 65) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] > dataframe['volume_mean_20'] * 0.5)
        )

        dataframe.loc[long_cond1, 'enter_long'] = 1
        dataframe.loc[long_cond1, 'enter_tag'] = 'mtf_pullback_long'
        dataframe.loc[long_cond2, 'enter_long'] = 1
        dataframe.loc[long_cond2, 'enter_tag'] = 'mtf_dip_long'

        dataframe.loc[short_cond1, 'enter_short'] = 1
        dataframe.loc[short_cond1, 'enter_tag'] = 'mtf_pullback_short'
        dataframe.loc[short_cond2, 'enter_short'] = 1
        dataframe.loc[short_cond2, 'enter_tag'] = 'mtf_dip_short'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_short'] = 0

        dataframe.loc[
            (dataframe['EWO_1h'] < 0) &
            (dataframe['EWO'] < -1.5) &
            (dataframe['rsi'] > 50) &
            (dataframe['volume'] > 0),
            ['exit_long', 'exit_tag']
        ] = (1, 'ewo_bearish_exit_long')

        dataframe.loc[
            (dataframe['EWO_1h'] > 0) &
            (dataframe['EWO'] > 1.5) &
            (dataframe['rsi'] < 50) &
            (dataframe['volume'] > 0),
            ['exit_short', 'exit_tag']
        ] = (1, 'ewo_bullish_exit_short')

        return dataframe
