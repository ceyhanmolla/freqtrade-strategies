# Ichimoku Cloud based strategy - Modernized 2024 version
# High frequency 5m trading with ATR-based risk management

from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas as pd
import numpy as np
from datetime import datetime
from functools import reduce


class IchiV1_Modern(IStrategy):
    # Strategy version
    INTERFACE_VERSION = 3

    # === TIMEFRAME ===
    timeframe = '5m'

    # === BUY PARAMETERS ===
    buy_params = {
        "buy_rsi": 45,
        "buy_rsi_fast": 30,
        "buy_adx": 25,
        "buy_fan_threshold": 1.002,
        "buy_ema_diff": 0.98,
    }

    # === SELL PARAMETERS ===
    sell_params = {
        "sell_rsi_exit": 65,
        "sell_trailing_stop": 0.03,
    }

    # === ROI ===
    minimal_roi = {
        "0": 0.05,
        "15": 0.025,
        "45": 0.01,
        "120": 0,
    }

    # === STOPLOSS ===
    stoploss = -0.02
    use_custom_stoploss = True

    # === TRAILING STOP ===
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    # === SELL SIGNAL ===
    use_sell_signal = True
    sell_profit_only = True  # Sadece kârda sat
    ignore_roi_if_buy_signal = False

    # === PROCESSING ===
    process_only_new_candles = True
    startup_candle_count = 200

    # === PARAMETERS ===
    buy_rsi = IntParameter(30, 60, default=buy_params['buy_rsi'], space='buy')
    buy_rsi_fast = IntParameter(20, 40, default=buy_params['buy_rsi_fast'], space='buy')
    buy_adx = DecimalParameter(15, 40, default=buy_params['buy_adx'], space='buy')
    buy_fan_threshold = DecimalParameter(1.001, 1.010, default=buy_params['buy_fan_threshold'], space='buy')
    buy_ema_diff = DecimalParameter(0.95, 1.0, default=buy_params['buy_ema_diff'], space='buy')

    sell_rsi_exit = IntParameter(55, 80, default=sell_params['sell_rsi_exit'], space='sell')
    sell_trailing_stop = DecimalParameter(0.01, 0.05, default=sell_params['sell_trailing_stop'], space='sell')

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)

        # ADX - Trend strength
        dataframe['adx'] = ta.ADX(dataframe)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe)

        # EMA for trend
        for period in [9, 20, 50, 100, 200]:
            dataframe[f'ema_{period}'] = ta.EMA(dataframe, timeperiod=period)

        # SMA
        for period in [20, 50, 200]:
            dataframe[f'sma_{period}'] = ta.SMA(dataframe, timeperiod=period)

        # VWAP - rolling calculation
        typical_price = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        dataframe['vwap'] = (typical_price * dataframe['volume']).rolling(window=20).sum() / dataframe['volume'].rolling(window=20).sum()

        # ATR for stoploss
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['atr_percent'] = (dataframe['atr'] / dataframe['close']) * 100

        # MACD
        dataframe['macd'], dataframe['macd_signal'], dataframe['macd_hist'] = ta.MACD(
            dataframe, fastperiod=12, slowperiod=26, signalperiod=9
        )

        # Ichimoku Cloud (manual calculation without technical library)
        # Conversion Line (Tenkan-sen)
        dataframe['tenkan_sen'] = (dataframe['high'].rolling(window=9).max() + 
                                    dataframe['low'].rolling(window=9).min()) / 2

        # Base Line (Kijun-sen)
        dataframe['kijun_sen'] = (dataframe['high'].rolling(window=26).max() + 
                                   dataframe['low'].rolling(window=26).min()) / 2

        # Senkou Span A
        dataframe['senkou_a'] = ((dataframe['tenkan_sen'] + dataframe['kijun_sen']) / 2).shift(26)

        # Senkou Span B
        dataframe['senkou_b'] = ((dataframe['high'].rolling(window=52).max() + 
                                   dataframe['low'].rolling(window=52).min()) / 2).shift(26)

        # Cloud colors
        dataframe['cloud_green'] = dataframe['senkou_a'] > dataframe['senkou_b']
        dataframe['cloud_red'] = dataframe['senkou_a'] <= dataframe['senkou_b']

        # Chikou Span ( lagging ) - not using to avoid lookahead bias
        # dataframe['chikou_span'] = dataframe['close'].shift(-26)

        # Fan Magnitude (momentum indicator)
        dataframe['ema_8h_equivalent'] = ta.EMA(dataframe, timeperiod=8)
        dataframe['ema_40h_equivalent'] = ta.EMA(dataframe, timeperiod=40)
        dataframe['fan_magnitude'] = dataframe['ema_8h_equivalent'] / dataframe['ema_40h_equivalent']
        dataframe['fan_magnitude_gain'] = dataframe['fan_magnitude'] / dataframe['fan_magnitude'].shift(1)

        # Trend indicators
        dataframe['trend_up'] = dataframe['close'] > dataframe['ema_50']
        dataframe['trend_strong'] = (dataframe['adx'] > self.buy_adx.value) & (dataframe['plus_di'] > dataframe['minus_di'])

        # Volume filter
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        dataframe['volume_ok'] = dataframe['volume'] > dataframe['volume_ma'] * 0.5

        # Stochastic
        dataframe['stoch_k'], dataframe['stoch_d'] = ta.STOCH(
            dataframe, fastk_period=14, slowk_period=3, slowk_matype=0, slowd_period=3, slowd_matype=0
        )

        # Bollinger Bands for volatility
        bb = ta.BBANDS(dataframe['close'], timeperiod=20, nbdevup=2.0, nbdevdn=2.0, matype=0)
        dataframe['bb_upper'] = bb[0]
        dataframe['bb_middle'] = bb[1]
        dataframe['bb_lower'] = bb[2]

        # Support/Resistance levels
        dataframe['high_20'] = dataframe['high'].rolling(window=20).max()
        dataframe['low_20'] = dataframe['low'].rolling(window=20).min()

        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # === CONDITION 1: RSI Oversold + Trend Start ===
        # Price in oversold territory but showing recovery
        conditions.append(
            (dataframe['rsi'] < self.buy_rsi.value) &
            (dataframe['rsi_fast'] < self.buy_rsi_fast.value) &
            (dataframe['rsi'] > dataframe['rsi'].shift(1))  # RSI rising
        )

        # === CONDITION 2: ADX Trend Strength ===
        # Strong trend but not overbought
        conditions.append(
            (dataframe['adx'] > self.buy_adx.value) &
            (dataframe['plus_di'] > dataframe['minus_di']) &
            (dataframe['rsi'] < 60) &
            (dataframe['volume_ok'])
        )

        # === CONDITION 3: MACD Crossover ===
        # MACD turning positive
        conditions.append(
            (dataframe['macd'] > dataframe['macd_signal']) &
            (dataframe['macd'].shift(1) <= dataframe['macd_signal'].shift(1)) &
            (dataframe['rsi'] < 50) &
            (dataframe['volume_ok'])
        )

        # === CONDITION 4: Fan Momentum ===
        # Strong upward momentum
        conditions.append(
            (dataframe['fan_magnitude_gain'] >= self.buy_fan_threshold.value) &
            (dataframe['fan_magnitude'] > 1) &
            (dataframe['close'] > dataframe['vwap'])
        )

        # === CONDITION 5: Ichimoku Cloud Breakout ===
        # Price breaking above cloud
        conditions.append(
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b']) &
            (dataframe['cloud_green']) &
            (dataframe['trend_up'])
        )

        # === CONDITION 6: EMA Crossover ===
        # Short EMA crossing above long EMA
        conditions.append(
            (dataframe['ema_9'] > dataframe['ema_20']) &
            (dataframe['ema_9'].shift(1) <= dataframe['ema_20'].shift(1)) &
            (dataframe['close'] > dataframe['ema_9'] * self.buy_ema_diff.value)
        )

        # Combine all conditions
        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x | y, conditions),
                'buy'
            ] = 1

        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # === CONDITION 1: RSI Overbought ===
        conditions.append(
            (dataframe['rsi'] > self.sell_rsi_exit.value) &
            (dataframe['rsi'] < dataframe['rsi'].shift(1))
        )

        # === CONDITION 2: Trailing Stop Trigger ===
        # This is handled by trailing_stop - no additional condition needed
        # But we add profit taking levels
        conditions.append(
            (dataframe['close'] > dataframe['open'] * 1.05) &  # 5% profit
            (dataframe['rsi'] > 70)
        )

        # === CONDITION 3: MACD Cross Down ===
        conditions.append(
            (dataframe['macd'] < dataframe['macd_signal']) &
            (dataframe['macd'].shift(1) >= dataframe['macd_signal'].shift(1))
        )

        # === CONDITION 4: ADX Weakening ===
        conditions.append(
            (dataframe['adx'] < 20) &
            (dataframe['minus_di'] > dataframe['plus_di'])
        )

        # === CONDITION 5: Price below VWAP after profit ===
        conditions.append(
            (dataframe['close'] < dataframe['vwap']) &
            (dataframe['close'] > dataframe['open'] * 1.02)  # Some profit
        )

        # === CONDITION 6: Time-based exit (max hold time) ===
        # Handled by ROI

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x | y, conditions),
                'sell'
            ] = 1

        return dataframe

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        """
        Step-based dynamic stoploss - Inspired by NASOSv5
        Profit arttıkça stoploss sıkılaşır
        """
        if current_profit > 0.30:
            return 0.05  # %5 profit -> %5 stoploss
        elif current_profit > 0.15:
            return 0.03  # %15+ profit -> %3 stoploss
        elif current_profit > 0.08:
            return 0.02  # %8+ profit -> %2 stoploss
        elif current_profit > 0.05:
            return 0.015 # %5+ profit -> %1.5 stoploss
        elif current_profit > 0.03:
            return 0.01  # %3+ profit -> %1 stoploss
        elif current_profit > 0.015:
            return 0.005 # %1.5+ profit -> %0.5 stoploss
        else:
            return 0.10  # Default %10 stoploss

    def confirm_trade_exit(self, pair: str, trade: 'Trade', order_type: str, amount: float,
                           rate: float, time_in_force: str, sell_reason: str,
                           current_time: datetime, **kwargs) -> bool:
        """
        Additional exit confirmation
        """
        if sell_reason == 'exit_signal':
            # Don't exit if just hit trailing stop
            if trade.get_profit_ratio(rate) > 0.03:
                return True
        return True