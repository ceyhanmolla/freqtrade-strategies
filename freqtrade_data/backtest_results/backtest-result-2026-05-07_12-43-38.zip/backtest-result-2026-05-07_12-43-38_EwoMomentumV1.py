"""
EwoMomentumV1 - EWO Momentum (Let It Run)
============================================
- EWO = SMA(50) - SMA(200), close'a normalize
- Trend takibi (EWO > 3.0, RSI < 40) — selektif giris
- ROI: %5 hemen, %2 2 saat sonra
- Trailing: %1.5 buffer, %2 offset (kazanca daha fazla kosma sansi)
- Custom stoploss: ATR(14) x 3.0 (clamp %3-%10)
- 5m timeframe / v3 interface
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame

import talib.abstract as ta


def EWO(dataframe, sma_fast_length=50, sma_slow_length=200):
    sma_fast = ta.SMA(dataframe, timeperiod=sma_fast_length)
    sma_slow = ta.SMA(dataframe, timeperiod=sma_slow_length)
    return (sma_fast - sma_slow) / dataframe['close'] * 100


class EwoMomentumV1(IStrategy):
    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.05,
        "120": 0.02,
    }

    stoploss = -0.10

    use_custom_stoploss = True

    trailing_stop = True
    trailing_stop_positive = 0.015
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    use_exit_signal = False

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_mean_20'] = dataframe['volume'].rolling(20).mean()
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        return dataframe

    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, **kwargs):
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or dataframe.empty:
            return -0.10
        last_candle = dataframe.iloc[-1].copy()
        atr = last_candle.get('atr', None)
        if atr is None or atr <= 0 or current_rate <= 0:
            return -0.10
        atr_pct = atr / current_rate
        stoploss_ratio = -(atr_pct * 3.0)
        return max(min(stoploss_ratio, -0.03), -0.10)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        buy_cond1 = (
            (dataframe['EWO'] > 3.0) &
            (dataframe['rsi'] < 40) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_mean_20'] * 3)
        )

        dataframe.loc[buy_cond1, 'enter_long'] = 1
        dataframe.loc[buy_cond1, 'enter_tag'] = 'trend_momentum'
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe
