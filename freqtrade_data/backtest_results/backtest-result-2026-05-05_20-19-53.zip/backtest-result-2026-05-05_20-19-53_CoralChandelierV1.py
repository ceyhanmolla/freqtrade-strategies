"""
CoralChandelierV1 - Custom Indicators Strategy
=============================================

STRATEJİ AÇIKLAMASI:
- Coral Trend Indicator (EMA + CCI kombinasyonu)
- Chandelier Exit (ATR Trailing Stop)
- STC Indicator (MACD + Stochastic)
- ADX ile trend gücü doğrulama
- EMA ile trend yönü

Author: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import numpy as np
import talib.abstract as ta


def coral_trend(dataframe, ema_fast=50, ema_slow=200, cci_period=14, cci_threshold=100):
    """Coral Trend - EMA + CCI kombinasyonu"""
    ema_fast = ta.EMA(dataframe, timeperiod=ema_fast)
    ema_slow = ta.EMA(dataframe, timeperiod=ema_slow)
    cci = ta.CCI(dataframe, timeperiod=cci_period)
    
    trend = np.where((ema_fast > ema_slow) & (cci < -cci_threshold), 1,
             np.where((ema_fast < ema_slow) & (cci > cci_threshold), -1, 0))
    return trend


def chandelier_exit(dataframe, atr_period=22, atr_multiplier=3):
    """Chandelier Exit - ATR Trailing Stop"""
    atr = ta.ATR(dataframe, timeperiod=atr_period)
    highest_high = dataframe['high'].rolling(atr_period).max()
    long_stop = highest_high - (atr * atr_multiplier)
    return long_stop


def stc_indicator(dataframe, macd_fast=12, macd_slow=26, macd_signal=9, stoch_k=14, stoch_d=3):
    """STC Indicator - MACD + Stochastic kombinasyonu"""
    macd = ta.MACD(dataframe, fastperiod=macd_fast, slowperiod=macd_slow, signalperiod=macd_signal)
    macd_line = macd['macd']
    macd_signal_line = macd['macdsignal']
    
    stoch = ta.STOCH(dataframe, fastk_period=stoch_k, slowk_period=stoch_k, slowk_matype=0)
    stoch_k_val = stoch['slowk']
    stoch_d_val = stoch['slowd']
    
    trend = np.where((macd_line > macd_signal_line) & (stoch_k_val > stoch_d_val), 1,
             np.where((macd_line < macd_signal_line) & (stoch_k_val < stoch_d_val), -1, 0))
    return trend


class CoralChandelierV1(IStrategy):
    INTERFACE_VERSION = 2

    minimal_roi = {
        "0": 0.5,
        "30": 1.0,
        "60": 1.5,
        "180": 2.5,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.015
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    use_exit_signal = False
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '15m'

    process_only_new_candles = True
    startup_candle_count = 300

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['coral_trend'] = coral_trend(dataframe)
        dataframe['stc_trend'] = stc_indicator(dataframe)
        dataframe['chandelier_stop'] = chandelier_exit(dataframe)
        dataframe['adx'] = ta.ADX(dataframe)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['ema_trend'] = np.where(dataframe['ema_50'] > dataframe['ema_200'], 1, -1)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['buy'] = 0
        
        volume_filter = dataframe['volume'] > dataframe['volume_sma'] * 0.5
        
        buy_conditions = (
            ((dataframe['coral_trend'] == 1) | (dataframe['stc_trend'] == 1)) &
            (dataframe['adx'] > 20) &
            (dataframe['ema_trend'] == 1) &
            (dataframe['volume'] > 0) &
            volume_filter
        )
        
        dataframe.loc[buy_conditions, 'buy'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0
        
        # RSI overbought veya trend değişimi
        sell_conditions = (
            (dataframe['rsi'] > 70) |
            (dataframe['coral_trend'] == -1) |
            (dataframe['ema_trend'] == -1)
        )
        
        dataframe.loc[sell_conditions, 'sell'] = 1
        return dataframe