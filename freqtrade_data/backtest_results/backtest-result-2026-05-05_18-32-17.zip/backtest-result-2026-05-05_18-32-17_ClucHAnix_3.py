"""
ClucHAnix_3 - Heikin Ashi + Bollinger Bands Stratejisi
======================================================

STRATEJİ AÇIKLAMASI:
- Heikin Ashi ile pürüzsüz fiyat analizi
- Bollinger Bands ile volatilite
- Multi-timeframe: 15m + 1h
- Custom trailing stoploss

YAPILAN MÜHENDİSLİK DÜZELTMELERİ (2026-05-05):
1. minimal_roi: 100 → 0.5%-3% stepwise
2. stoploss: -0.99 → -0.10
3. timeframe: 1m → 15m (veri yoktu)
4. Entry parametreleri gevşetildi
5. Sell optimization açıldı

PERFORMANS (düzeltmeden önce): 0 trade
Sonraki test: yapılacak

Author: OpenCode Assistant
Date: 2026-05-05
"""

import freqtrade.vendor.qtpylib.indicators as qtpylib
import numpy as np
import talib.abstract as ta

from freqtrade.persistence import Trade
from freqtrade.strategy.interface import IStrategy
from freqtrade.strategy import merge_informative_pair, DecimalParameter, stoploss_from_open, IntParameter
from pandas import DataFrame, Series
from datetime import datetime


def bollinger_bands(stock_price, window_size, num_of_std):
    """Manuel Bollinger Bands hesaplama"""
    rolling_mean = stock_price.rolling(window=window_size).mean()
    rolling_std = stock_price.rolling(window=window_size).std()
    lower_band = rolling_mean - (rolling_std * num_of_std)
    return np.nan_to_num(rolling_mean), np.nan_to_num(lower_band)


def ha_typical_price(bars):
    """Heikin Ashi Typical Price = (High + Low + Close) / 3"""
    res = (bars['ha_high'] + bars['ha_low'] + bars['ha_close']) / 3.
    return Series(index=bars.index, data=res)


class ClucHAnix_3(IStrategy):

    """
    PASTE OUTPUT FROM HYPEROPT HERE
    Can be overridden for specific sub-strategies (stake currencies) at the bottom.
    """

    # Düzeltilmiş parametreler (2026-05-05)
    sell_params = {
        'sell_fisher': 0.38414,
        'sell_bbmiddle_close': 1.07634
    }

    # Düzeltme: %100 → stepwise 0.5%-3%
    minimal_roi = {
        "0": 0.5,    # 30 dakika → %0.5
        "30": 1.0,   # 1 saat → %1.0
        "60": 1.5,   # 2 saat → %1.5
        "180": 2.5,  # 3 saat → %2.5
    }

    # Düzeltme: -0.99 → -0.10
    stoploss = -0.10

    trailing_stop = False
    trailing_stop_positive = 0.001
    trailing_stop_positive_offset = 0.012
    trailing_only_offset_is_reached = False

    """
    END HYPEROPT
    """
    
    # Düzeltme: 1m → 15m (1m veri yok, 15m daha az gürültü)
    timeframe = '15m'

    use_custom_stoploss = True

    process_only_new_candles = True
    startup_candle_count = 168

    order_types = {
        'entry': 'market',
        'exit': 'market',
        'emergency_exit': 'market',
        'force_entry': 'market',
        'force_exit': "market",
        'stoploss': 'market',
        'stoploss_on_exchange': False,

        'stoploss_on_exchange_interval': 60,
        'stoploss_on_exchange_limit_ratio': 0.99
    }

    # Düzeltme: Parametreler gevşetildi (daha fazla trade için)
    buy_op = True
    bbdelta_close = DecimalParameter(0.001, 0.05, default=0.02, decimals=4, space='buy', optimize=buy_op)
    bbdelta_tail = DecimalParameter(0.5, 1.0, default=0.7, decimals=4, space='buy', optimize=buy_op)
    close_bblower = DecimalParameter(0.001, 0.05, default=0.02, decimals=4, space='buy', optimize=buy_op)
    closedelta_close = DecimalParameter(0.001, 0.05, default=0.02, decimals=4, space='buy', optimize=buy_op)
    rocr_1h = DecimalParameter(0.3, 1.0, default=0.5, decimals=4, space='buy', optimize=buy_op)

    leverage_optimize = True
    leverage_num = IntParameter(low=1, high=10, default=1, space='buy', optimize=leverage_optimize)

    # Düzeltme: Sell optimization açıldı
    sell_op = True
    sell_fisher = DecimalParameter(0.1, 0.5, default=0.5, decimals=4, space='sell', optimize=sell_op)
    sell_bbmiddle_close = DecimalParameter(0.97, 1.1, default=1.1, decimals=4, space='sell', optimize=sell_op)

    trailing_optimize = True
    pHSL = DecimalParameter(-0.990, -0.040, default=-0.08, decimals=3, space='sell', optimize=trailing_optimize)
    pPF_1 = DecimalParameter(0.008, 0.100, default=0.016, decimals=3, space='sell', optimize=trailing_optimize)
    pSL_1 = DecimalParameter(0.008, 0.100, default=0.011, decimals=3, space='sell', optimize=trailing_optimize)
    pPF_2 = DecimalParameter(0.040, 0.200, default=0.080, decimals=3, space='sell', optimize=trailing_optimize)
    pSL_2 = DecimalParameter(0.040, 0.200, default=0.040, decimals=3, space='sell', optimize=trailing_optimize)

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative_pairs = [(pair, '1h') for pair in pairs]
        return informative_pairs

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:

        HSL = self.pHSL.value
        PF_1 = self.pPF_1.value
        SL_1 = self.pSL_1.value
        PF_2 = self.pPF_2.value
        SL_2 = self.pSL_2.value




        if current_profit > PF_2:
            sl_profit = SL_2 + (current_profit - PF_2)
        elif current_profit > PF_1:
            sl_profit = SL_1 + ((current_profit - PF_1) * (SL_2 - SL_1) / (PF_2 - PF_1))
        else:
            sl_profit = HSL

        if self.can_short:
            if (-1 + ((1 - sl_profit) / (1 - current_profit))) <= 0:
                return 1
        else:
            if (1 - ((1 + sl_profit) / (1 + current_profit))) <= 0:
                return 1

        return stoploss_from_open(sl_profit, current_profit, is_short=trade.is_short)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        heikinashi = qtpylib.heikinashi(dataframe)
        dataframe['ha_open'] = heikinashi['open']
        dataframe['ha_close'] = heikinashi['close']
        dataframe['ha_high'] = heikinashi['high']
        dataframe['ha_low'] = heikinashi['low']

        mid, lower = bollinger_bands(ha_typical_price(dataframe), window_size=40, num_of_std=2)
        dataframe['lower'] = lower
        dataframe['mid'] = mid
        
        dataframe['bbdelta'] = (mid - dataframe['lower']).abs()
        dataframe['closedelta'] = (dataframe['ha_close'] - dataframe['ha_close'].shift()).abs()
        dataframe['tail'] = (dataframe['ha_close'] - dataframe['ha_low']).abs()

        dataframe['bb_lowerband'] = dataframe['lower']
        dataframe['bb_middleband'] = dataframe['mid']

        dataframe['ema_fast'] = ta.EMA(dataframe['ha_close'], timeperiod=3)
        dataframe['ema_slow'] = ta.EMA(dataframe['ha_close'], timeperiod=50)
        dataframe['volume_mean_slow'] = dataframe['volume'].rolling(window=30).mean()
        dataframe['rocr'] = ta.ROCR(dataframe['ha_close'], timeperiod=28)

        rsi = ta.RSI(dataframe)
        dataframe["rsi"] = rsi
        rsi = 0.1 * (rsi - 50)
        dataframe["fisher"] = (np.exp(2 * rsi) - 1) / (np.exp(2 * rsi) + 1)
        
        inf_tf = '1h'
        
        informative = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe=inf_tf)
        
        inf_heikinashi = qtpylib.heikinashi(informative)

        informative['ha_close'] = inf_heikinashi['close']
        informative['rocr'] = ta.ROCR(informative['ha_close'], timeperiod=168)
     
        dataframe = merge_informative_pair(dataframe, informative, self.timeframe, inf_tf, ffill=True)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        # Düzeltme: Entry koşulları basitleştirildi
        # Koşul 1: Ana BB delta koşulu
        condition_1 = (
            (dataframe['lower'].shift().gt(0)) &
            (dataframe['bbdelta'].gt(dataframe['ha_close'] * self.bbdelta_close.value)) &
            (dataframe['closedelta'].gt(dataframe['ha_close'] * self.closedelta_close.value)) &
            (dataframe['tail'].lt(dataframe['bbdelta'] * self.bbdelta_tail.value)) &
            (dataframe['ha_close'].lt(dataframe['lower'].shift())) &
            (dataframe['ha_close'].le(dataframe['ha_close'].shift()))
        )

        # Koşul 2: EMA trend koşulu (daha basit)
        condition_2 = (
            (dataframe['ha_close'] < dataframe['ema_slow']) &
            (dataframe['ha_close'] < self.close_bblower.value * dataframe['bb_lowerband'])
        )

        # Koşul 3: Basit RSI oversold (yedek - daha az karmaşık)
        condition_3 = (
            (dataframe['rsi'] < 35) &
            (dataframe['volume'] > dataframe['volume_mean_slow'] * 0.5)
        )

        # ROC 1h trend kontrolü (isteğe bağlı - olmadan da çalışsın)
        rocr_condition = True  # dataframe['rocr_1h'].gt(self.rocr_1h.value)

        # Entry: Herhangi bir koşul + trend kontrolü
        dataframe.loc[
            (condition_1 | condition_2 | condition_3) & rocr_condition,
            'enter_long'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        dataframe.loc[
            (dataframe['fisher'] > self.sell_fisher.value) &
            (dataframe['ha_high'].le(dataframe['ha_high'].shift(1))) &
            (dataframe['ha_high'].shift(1).le(dataframe['ha_high'].shift(2))) &
            (dataframe['ha_close'].le(dataframe['ha_close'].shift(1))) &
            (dataframe['ema_fast'] > dataframe['ha_close']) &
            ((dataframe['ha_close'] * self.sell_bbmiddle_close.value) > dataframe['bb_middleband']) &
            (dataframe['volume'] > 0)
            ,
            'exit_long'
        ] = 1

        return dataframe

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, max_leverage: float, side: str,
                 **kwargs) -> float:

        return self.leverage_num.value
