"""
TheForceV3c - Dengeli Giriş + Sıkı Stoploss
============================================

MÜHENDİSLİK KARARLARI:
-----------------------
V3'ün 106 trade, %69.8 win oranı başarılıydı ama -5% stoploss
kaybeden işlemlerde büyük zarar verdiriyordu.
V3b'de -3% stoploss iyiydi ama entry çok sıkıydı (23 trade).

BU VERSİYONDA:
1. V3'ün entry koşullarını koru (106 trade, yüksek win rate)
2. V3b'nin -3% stoploss'unu al (küçük kayıplar)
3. Exit'te MACD + BB + RSI üçlü teyit (erken çıkış yok)
4. Trailing stop ile kârı kilitle

Author: OpenCode Assistant
Date: 2026-05-06
"""

import numpy as np
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class TheForceV3c(IStrategy):

    INTERFACE_VERSION = 3

    minimal_roi = {
        "60": 0.01,
        "30": 0.005,
        "0": 0.003
    }

    # V3b'den: -5% → -3%
    stoploss = -0.03

    trailing_stop = True
    trailing_stop_positive = 0.008
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    timeframe = '15m'
    startup_candle_count = 50

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    order_time_in_force = {
        'entry': 'GTC',
        'exit': 'GTC'
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        # 1. Stochastic
        stoch_fast = ta.STOCHF(dataframe, 5, 3, 3)
        dataframe['fastd'] = stoch_fast['fastd']
        dataframe['fastk'] = stoch_fast['fastk']

        # 2. MACD - BİASSIZ
        macd = ta.MACD(dataframe, 12, 26, 9)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        # 3. EMA
        dataframe['ema5'] = ta.EMA(dataframe['close'], timeperiod=5)
        dataframe['ema20'] = ta.EMA(dataframe['close'], timeperiod=20)
        dataframe['ema5o'] = ta.EMA(dataframe['open'], timeperiod=5)

        # 4. Bollinger Bands
        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bb['upperband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_lower'] = bb['lowerband']
        dataframe['bb_width'] = (dataframe['bb_upper'] - dataframe['bb_lower']) / dataframe['bb_middle']
        bb_range = dataframe['bb_upper'] - dataframe['bb_lower']
        bb_range = bb_range.replace(0, np.nan)
        dataframe['bb_position'] = (dataframe['close'] - dataframe['bb_lower']) / bb_range

        # 5. RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # 6. Volume
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()

        # 7. ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        V3'ün orijinal entry koşulları (aynı - 106 trade veriyordu)
        """
        dataframe['enter_long'] = 0

        dataframe.loc[
            (
                # 1. MACD histogram momentum
                (dataframe['macdhist'] > 0) &
                (dataframe['macdhist'] > dataframe['macdhist'].shift(2))
            ) &
            (
                # 2. Stochastic filtre
                (dataframe['fastk'] >= 20) & (dataframe['fastk'] <= 85) &
                (dataframe['fastd'] >= 20) & (dataframe['fastd'] <= 85)
            ) &
            (
                # 3. BB pozisyonu
                (dataframe['bb_position'] <= 0.6)
            ) &
            (
                # 4. EMA trend
                (dataframe['ema5'] > dataframe['ema5o'])
            ) &
            (
                # 5. RSI
                (dataframe['rsi'] > 40)
            ) &
            (
                # 6. Hacim onayı
                (dataframe['volume'] > dataframe['volume_sma'] * 0.7)
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        V3 exit: MACD zayıflıyor + (Stochastic/BB/RSI aşırı)
        """
        dataframe['exit_long'] = 0

        dataframe.loc[
            (
                # MACD momentum zayıflıyor
                (dataframe['macdhist'] < dataframe['macdhist'].shift(3))
            ) &
            (
                (dataframe['fastk'] > 85) |
                (dataframe['bb_position'] > 0.85) |
                (dataframe['rsi'] > 70)
            ),
            'exit_long'] = 1

        return dataframe
