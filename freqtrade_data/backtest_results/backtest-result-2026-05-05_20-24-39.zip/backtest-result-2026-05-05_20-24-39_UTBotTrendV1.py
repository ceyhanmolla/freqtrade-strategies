"""
UTBotTrendV1 - UTBot Alerts Strategy
====================================

STRATEJİ AÇIKLAMASI:
- UTBot: ATR-based trailing stop (dinamik stop-loss)
- Long ve Short pozisyon desteği
- ADX ile trend gücü doğrulama
- EMA ile exit kontrolü
- Volume filter

DOC RESULTS (2021-2023):
- Profit: 3202% ROI
- Period: 955 days
- Max Drawdown: 14.29%
- Avg Daily Trades: 19.55
- Timeframe: 15m

Author: Based on Medium article by pppicasso
Engineering: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame, Series
import numpy as np
import talib.abstract as ta


def utbot_alerts(dataframe, key_value=1, atr_period=3, ema_period=200):
    """UTBot Alerts - ATR Trailing Stop based trend"""
    xATR = ta.ATR(dataframe, timeperiod=atr_period)
    nLoss = key_value * xATR
    src = dataframe['close']
    
    xATRTrailingStop = np.zeros(len(dataframe))
    xATRTrailingStop[0] = src.iloc[0] - nLoss.iloc[0]
    
    for i in range(1, len(dataframe)):
        if src.iloc[i] > xATRTrailingStop[i-1] and src.iloc[i-1] > xATRTrailingStop[i-1]:
            xATRTrailingStop[i] = max(xATRTrailingStop[i-1], src.iloc[i] - nLoss.iloc[i])
        elif src.iloc[i] < xATRTrailingStop[i-1] and src.iloc[i-1] < xATRTrailingStop[i-1]:
            xATRTrailingStop[i] = min(xATRTrailingStop[i-1], src.iloc[i] + nLoss.iloc[i])
        elif src.iloc[i] > xATRTrailingStop[i-1]:
            xATRTrailingStop[i] = src.iloc[i] - nLoss.iloc[i]
        else:
            xATRTrailingStop[i] = xATRTrailingStop[i-1]
    
    xATRTrailingStop = Series(xATRTrailingStop, index=dataframe.index)
    
    prev_src = src.shift(1)
    prev_stop = xATRTrailingStop.shift(1)
    
    mask_buy = (prev_src < prev_stop) & (src > prev_stop)
    mask_sell = (prev_src > prev_stop) & (src < prev_stop)
    
    pos = np.zeros(len(dataframe))
    pos[mask_buy] = 1
    pos[mask_sell] = -1
    pos[(pos != 1) & (pos != -1)] = 0
    
    ema = ta.EMA(dataframe, timeperiod=ema_period)
    
    buy_condition = (xATRTrailingStop > ema) & (pos > 0) & (src > ema)
    sell_condition = (xATRTrailingStop < ema) & (pos < 0) & (src < ema)
    
    trend = np.where(buy_condition, 1, np.where(sell_condition, -1, 0))
    
    return trend


class UTBotTrendV1(IStrategy):
    INTERFACE_VERSION = 2

    # Entry parametreleri
    key_value_l = 1.0
    key_value_s = 1.0
    atr_period_l = 3
    atr_period_s = 3
    ema_period_l = 200
    ema_period_s = 200
    
    # ADX filtre
    adx_long_min = 20
    adx_long_max = 60
    adx_short_min = 20
    adx_short_max = 60
    
    # Volume filtre
    volume_check = 20
    
    # Exit EMA
    ema_period_l_exit = 50
    ema_period_s_exit = 50
    volume_check_exit = 20

    minimal_roi = {
        "0": 0.3,
        "30": 0.6,
        "60": 1.0,
        "180": 2.0,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    use_exit_signal = True
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '15m'

    process_only_new_candles = True
    startup_candle_count = 300

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Long term UTBot
        dataframe['trend_l'] = utbot_alerts(
            dataframe, 
            key_value=self.key_value_l,
            atr_period=self.atr_period_l,
            ema_period=self.ema_period_l
        )
        
        # Short term UTBot
        dataframe['trend_s'] = utbot_alerts(
            dataframe,
            key_value=self.key_value_s,
            atr_period=self.atr_period_s,
            ema_period=self.ema_period_s
        )
        
        # ADX - trend strength
        dataframe['adx'] = ta.ADX(dataframe)
        
        # EMA for exit
        dataframe['ema_l'] = ta.EMA(dataframe, timeperiod=self.ema_period_l_exit)
        dataframe['ema_s'] = ta.EMA(dataframe, timeperiod=self.ema_period_s_exit)
        
        # Volume filter
        dataframe['volume_mean'] = dataframe['volume'].rolling(self.volume_check).mean().shift(1)
        dataframe['volume_mean_exit'] = dataframe['volume'].rolling(self.volume_check_exit).mean().shift(1)
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Long entry
        dataframe.loc[
            (
                (dataframe['adx'] > self.adx_long_min) &
                (dataframe['adx'] < self.adx_long_max) &
                (dataframe['trend_l'] > 0) &
                (dataframe['volume'] > dataframe['volume_mean']) &
                (dataframe['volume'] > 0)
            ),
            'buy'
        ] = 1
        
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0
        
        # Long exit: close below EMA
        exit_long = (
            (dataframe['close'] < dataframe['ema_l']) &
            (dataframe['volume'] > dataframe['volume_mean_exit'])
        )
        
        dataframe.loc[exit_long, 'sell'] = 1
        return dataframe