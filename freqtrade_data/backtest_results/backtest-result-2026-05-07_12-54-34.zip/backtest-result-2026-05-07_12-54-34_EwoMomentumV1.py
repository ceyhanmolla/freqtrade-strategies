"""
EwoMomentumV1 - Multi-Timeframe EWO Momentum
===============================================
- 1h EWO(50,200) for trend confirmation
- 5m entry on pullbacks within 1h uptrend
- ROI: %3 immediate, %1.5 after 2h
- Custom stoploss: ATR(14) x 4.0 (clamp %3-%10)
- NO trailing stop (conflicts with stoploss)
- 5m + 1h timeframes
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import pandas as pd

import talib.abstract as ta


def EWO(dataframe, sma_fast_length=50, sma_slow_length=200):
    sma_fast = ta.SMA(dataframe, timeperiod=sma_fast_length)
    sma_slow = ta.SMA(dataframe, timeperiod=sma_slow_length)
    return (sma_fast - sma_slow) / dataframe['close'] * 100


class EwoMomentumV1(IStrategy):
    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.03,
        "120": 0.015,
    }

    stoploss = -0.10

    use_custom_stoploss = True

    trailing_stop = False

    use_exit_signal = False

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata['pair']

        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_mean_20'] = dataframe['volume'].rolling(20).mean()
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        if self.dp:
            df_1h = self.dp.get_pair_dataframe(pair, '1h')
            df_1h['EWO_1h'] = EWO(df_1h, 50, 200)
            df_1h_sorted = df_1h[['date', 'EWO_1h']].sort_values('date')
            dataframe = pd.merge_asof(
                dataframe.sort_values('date'),
                df_1h_sorted, on='date', direction='backward'
            ).sort_index()

        return dataframe

    def custom_stoploss(self, pair, trade, current_time, current_rate, current_profit, **kwargs):
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or dataframe.empty:
            return -0.10
        last_candle = dataframe.iloc[-1].copy()
        atr = last_candle.get('atr', None)
        if atr is None or atr <= 0 or current_rate <= 0:
            return -0.10
        atr_pct = atr / current_rate
        stoploss_ratio = -(atr_pct * 4.0)
        return max(min(stoploss_ratio, -0.03), -0.10)

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        buy_cond1 = (
            (dataframe['EWO_1h'] > 0) &
            (dataframe['EWO'] > 0) &
            (dataframe['rsi'] < 45) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_mean_20'] * 3)
        )

        buy_cond2 = (
            (dataframe['EWO_1h'] > 0) &
            (dataframe['EWO'] < -1.5) &
            (dataframe['rsi'] < 35) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] > dataframe['volume_mean_20'] * 0.5)
        )

        dataframe.loc[buy_cond1, 'enter_long'] = 1
        dataframe.loc[buy_cond1, 'enter_tag'] = 'mtf_pullback'
        dataframe.loc[buy_cond2, 'enter_long'] = 1
        dataframe.loc[buy_cond2, 'enter_tag'] = 'mtf_dip'
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe
