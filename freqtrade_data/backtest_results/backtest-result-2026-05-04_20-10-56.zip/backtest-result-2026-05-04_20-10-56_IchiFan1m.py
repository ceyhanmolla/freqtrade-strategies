# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
from datetime import datetime
from typing import Optional
import numpy as np
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from freqtrade.persistence import Trade


def calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26):
    """Ichimoku Cloud - Tam kapsamlı hesaplama
    
    Returns: Tenkan-sen, Kijun-sen, Senkou Span A/B, Chikou Span, Cloud Thickness
    """
    df = dataframe.copy()
    
    # Tenkan-sen (Conversion Line) - 9 periyotluk en yüksek/en düşük ortalama
    high_conv = df['high'].rolling(window=conversion).max()
    low_conv = df['low'].rolling(window=conversion).min()
    df['tenkan_sen'] = (high_conv + low_conv) / 2
    
    # Kijun-sen (Base Line) - 26 periyotluk en yüksek/en düşük ortalama
    high_base = df['high'].rolling(window=base).max()
    low_base = df['low'].rolling(window=base).min()
    df['kijun_sen'] = (high_base + low_base) / 2
    
    # Senkou Span A (Leading Span A) - (Tenkan + Kijun) / 2, 26 ileri
    df['senkou_span_a'] = ((df['tenkan_sen'] + df['kijun_sen']) / 2).shift(displacement)
    
    # Senkou Span B (Leading Span B) - 52 periyot HL ort, 26 ileri
    high_span = df['high'].rolling(window=span).max()
    low_span = df['low'].rolling(window=span).min()
    df['senkou_span_b'] = ((high_span + low_span) / 2).shift(displacement)
    
    # Chikou Span (Lagging Span) - Kapanış fiyatı 26 geri
    df['chikou_span'] = df['close'].shift(-displacement)
    
    # Cloud Thickness (Bulut kalınlığı) - Destek/direnç gücü
    df['cloud_thickness'] = abs(df['senkou_span_a'] - df['senkou_span_b'])
    df['cloud_thickness_pct'] = df['cloud_thickness'] / df['close'] * 100
    
    # TK Cross (Tenkan/Kijun crossover) - Momentum sinyali
    df['tk_cross'] = 0
    df.loc[df['tenkan_sen'] > df['kijun_sen'], 'tk_cross'] = 1   # Bullish cross
    df.loc[df['tenkan_sen'] < df['kijun_sen'], 'tk_cross'] = -1  # Bearish cross
    
    # TK Cross signal (previous cross detection)
    df['tk_cross_bullish'] = (df['tenkan_sen'] > df['kijun_sen']) & \
                             (df['tenkan_sen'].shift(1) <= df['kijun_sen'].shift(1))
    df['tk_cross_bearish'] = (df['tenkan_sen'] < df['kijun_sen']) & \
                             (df['tenkan_sen'].shift(1) >= df['kijun_sen'].shift(1))
    
    # Chikou confirmation - Trend gücü
    df['chikou_above'] = df['chikou_span'] > df['close'].shift(displacement)
    df['chikou_below'] = df['chikou_span'] < df['close'].shift(displacement)
    
    return df


class IchiFan1m(IStrategy):
    """
    Ichimoku ve EMA Fan stratejisi - Freqtrade uyumlu
    """
    INTERFACE_VERSION = 3

    # Zaman dilimi - 5m olarak değiştirildi
    timeframe = '5m'
    startup_candle_count = 120

    # Stoploss
    stoploss = -0.10

    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    # ROI
    minimal_roi = {
        "0": 0.03,
        "30": 0.015,
        "60": 0.01,
        "180": 0
    }

    # Hyperopt parametreleri (optimize=False ile varsayılan)
    buy_fan_magnitude_gain = DecimalParameter(0.00000, 0.00005, default=0.00001, space='buy', optimize=False)
    buy_fan_magnitude = DecimalParameter(-0.00100, 0.00100, default=-0.00057, space='buy', optimize=False)
    buy_ema_96_diff = DecimalParameter(0.00000, 0.00100, default=0.00057, space='buy', optimize=False)
    buy_ema_open_48_diff = DecimalParameter(-0.00050, 0.00050, default=-0.00001, space='buy', optimize=False)
    buy_fan_magnitude_shift_value = IntParameter(1, 5, default=1, space='buy', optimize=False)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # === TEMEL GÖSTERGELER ===
        # EMA Serileri
        for period in [12, 24, 48, 96]:
            dataframe[f'ema_close_{period}'] = ta.EMA(dataframe, timeperiod=period)
        
        # Açılış fiyatına dayalı EMA
        dataframe['ema_open_48'] = ta.EMA(dataframe['open'], timeperiod=48)
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # === ICHIMOKU CLOUD (TAM KAPSAMLI) ===
        ichimoku = calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26)
        
        # Tenkan & Kijun (momentum & timing)
        dataframe['tenkan_sen'] = ichimoku['tenkan_sen']
        dataframe['kijun_sen'] = ichimoku['kijun_sen']
        
        # Senkou Spans (Cloud)
        dataframe['senkou_span_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_span_b'] = ichimoku['senkou_span_b']
        # Aliases for compatibility
        dataframe['senkou_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_b'] = ichimoku['senkou_span_b']
        
        # Chikou (trend confirmation)
        dataframe['chikou_span'] = ichimoku['chikou_span']
        dataframe['chikou_above'] = ichimoku['chikou_above']
        
        # Cloud properties
        dataframe['cloud_thickness'] = ichimoku['cloud_thickness']
        dataframe['cloud_thickness_pct'] = ichimoku['cloud_thickness_pct']
        
        # TK Cross signals
        dataframe['tk_cross'] = ichimoku['tk_cross']
        dataframe['tk_cross_bullish'] = ichimoku['tk_cross_bullish']
        dataframe['tk_cross_bearish'] = ichimoku['tk_cross_bearish']
        
        # === EMA FAN (MOMENTUM) ===
        # Fan Magnitude: Hızlı EMA ile Yavaş EMA arasındaki yüzdelik fark
        dataframe['fan_magnitude'] = (dataframe['ema_close_12'] - dataframe['ema_close_96']) / dataframe['ema_close_96']
        
        # Fan Magnitude Gain (momentum)
        shift_val = self.buy_fan_magnitude_shift_value.value
        dataframe['fan_magnitude_gain'] = dataframe['fan_magnitude'] - dataframe['fan_magnitude'].shift(shift_val)
        
        # Yüzdelik fiyat farklılıkları
        dataframe['ema_96_diff'] = (dataframe['close'] - dataframe['ema_close_96']) / dataframe['ema_close_96']
        dataframe['ema_open_48_diff'] = (dataframe['close'] - dataframe['ema_open_48']) / dataframe['ema_open_48']
        
        # === VOLUME FİLTRE ===
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # === GÜÇLENDİRİLMİŞ GİRİŞ KOŞULLARI ===
        
        # Koşul A: Ichimoku Trend Filter
        # Fiyat cloud'un üzerinde (bullish trend)
        ichimoku_bullish = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b'])
        )
        
        # Koşul B: TK Cross (Tenkan/Kijun crossover - EN ÖNEMLİ GİRİŞ SİNYALİ)
        # Tenkan Kijun'un üzerinde VE crossover var (momentum değişimi)
        tk_bullish = dataframe['tk_cross_bullish']
        
        # Koşul C: Chikou Confirmation (trend gücü)
        # Chikou Span fiyatın 26 periyot üzerinde (geçmiş trend güçlü)
        chikou_confirm = dataframe['chikou_above']
        
        # Koşul D: EMA Fan Momentum
        fan_momentum = (
            (dataframe['fan_magnitude_gain'] >= self.buy_fan_magnitude_gain.value) &
            (dataframe['fan_magnitude'] >= self.buy_fan_magnitude.value) &
            (dataframe['ema_96_diff'] >= self.buy_ema_96_diff.value) &
            (dataframe['ema_open_48_diff'] >= self.buy_ema_open_48_diff.value)
        )
        
        # Koşul E: Volume filter
        volume_ok = dataframe['volume'] > 0
        
        # === TAM GİRİŞ (Güçlü) ===
        # Tüm koşullar sağlandığında
        strong_entry = ichimoku_bullish & tk_bullish & chikou_confirm & fan_momentum & volume_ok
        dataframe.loc[strong_entry, 'enter_long'] = 1
        dataframe.loc[strong_entry, 'enter_tag'] = 'ichifan_strong'
        
        # === ORTA GİRİŞ (TK Cross + Ichimoku) ===
        # Sadece trend + TK crossover (daha fazla sinyal)
        medium_entry = ichimoku_bullish & tk_bullish & volume_ok
        dataframe.loc[medium_entry & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[medium_entry & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichifan_medium'
        
        # === FALLBACK (Sadece Ichimoku bullish) ===
        # En basit giriş - trend filter
        fallback_entry = ichimoku_bullish & volume_ok
        dataframe.loc[fallback_entry & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[fallback_entry & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichimoku_bullish'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''
        
        # === ÇIKIŞ KOŞULLARI ===
        
        # Koşul 1: Ichimoku Bearish (fiyat cloud altına düştü)
        ichimoku_bearish = (
            (dataframe['close'] < dataframe['senkou_a']) &
            (dataframe['close'] < dataframe['senkou_b'])
        )
        
        # Koşul 2: TK Cross Bearish (momentum değişimi)
        tk_bearish = dataframe['tk_cross_bearish']
        
        # Koşul 3: Chikou aşağıda (trend zayıflıyor)
        chikou_weak = ~dataframe['chikou_above']
        
        # Güçlü çıkış: Trend tersi + momentum kaybı
        strong_exit = ichimoku_bearish & tk_bearish
        dataframe.loc[strong_exit, 'exit_long'] = 1
        dataframe.loc[strong_exit, 'exit_tag'] = 'ichifan_exit_strong'
        
        # Orta çıkış: Sadece cloud altı
        medium_exit = ichimoku_bearish & (dataframe['exit_long'] == 0)
        dataframe.loc[medium_exit, 'exit_long'] = 1
        dataframe.loc[medium_exit, 'exit_tag'] = 'ichimoku_bearish'
        
        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: 'datetime', 
                    current_rate: float, current_profit: float, **kwargs) -> Optional[str]:
        """Time-based exit - Uzun süreli pozisyonları önlemek için"""
        # 48 saat (2880 dakika = 5m * 576) sonra kâr varsa çık
        trade_duration_minutes = (current_time - trade.open_date_utc).total_seconds() / 60
        
        # 48 saat sonra kârlıysa çık
        if trade_duration_minutes > 2880 and current_profit > 0:
            return 'time_exit_profit'
        
        # 72 saat sonra (3 gün) kâra bakılmadan çık - uzun pozisyon önleme
        if trade_duration_minutes > 4320:
            return 'time_exit_force'
        
        return None