"""
TheForceV3 - Bias'sız Sinyal + Bobin Bantları Entegrasyonu
===========================================================

MÜHENDİSLİK NOTLARI:
---------------------
1. Orijinal MACD(12,26,1) bias'ı giderildi → MACD(12,26,9) + histogram momentum
   Neden: Histogram artışı (macdhist > macdhist.shift(1)) geleceğe bakmaz,
   mevcut mumda momentumun hızlandığını gösterir.

2. Bollinger Bantları eklendi
   Neden: Fiyatın bantlara göre konumu giriş kalitesini artırır.
   Alt banda yakın girişler dip alım kalitesini yükseltir.

3. Stoploss -1.5% → -5%
   Neden: -1.5% 15m timeframe'de çok sıkı, noise'da sürekli stoplanır.
   Daha geniş stoploss stratejinin nefes almasını sağlar.

4. Trailing stop eklendi
   Neden: Kârlı işlemleri korumak için %1 kârdan sonra %2 offset ile trail.

5. Bollinger daralma filtresi
   Neden: Sadece volatility normal/az olduğunda girer. Genişlemiş bantlarda
   (yüksek volatility) giriş risklidir.

6. V3 formatı (enter_long/exit_long)
   Neden: Modern Freqtrade arayüzü (INTERFACE_VERSION=3).

Author: OpenCode Assistant (Freqtrade Skill ile)
Date: 2026-05-05
"""

import numpy as np
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class TheForceV3(IStrategy):

    INTERFACE_VERSION = 3

    # === ROI (Yatırım Getirisi) ===
    minimal_roi = {
        "60": 0.01,    # 1 saat sonra %1 kâr yeterli
        "30": 0.005,   # 30 dk sonra %0.5
        "0": 0.003     # Hemen %0.3
    }

    # === Risk Yönetimi ===
    stoploss = -0.05

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    # === Zaman Dilimi ===
    timeframe = '15m'
    startup_candle_count = 50

    # === V3 Sinyal Kontrolü ===
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    # === Emir Tipleri ===
    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    order_time_in_force = {
        'entry': 'GTC',
        'exit': 'GTC'
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        MÜHENDİSLİK KARARI: MACD Histogram Momentum + Bollinger Bands
        ---------------------------------------------------------------
        Orijinal stratejinin "ruhunu" koruyarak bias'sız indikatörlerle
        yeniden yapılandırıldı. Histogram artışı, shift() bazlı 
        karşılaştırmalardan DAHA sağlam bir momentum sinyalidir.
        """

        # 1. Stochastic (orijinal stratejide vardı - aynen korundu)
        stoch_fast = ta.STOCHF(dataframe, 5, 3, 3)
        dataframe['fastd'] = stoch_fast['fastd']
        dataframe['fastk'] = stoch_fast['fastk']

        # 2. MACD - BİASSIZ! (signalperiod=9 standard)
        macd = ta.MACD(dataframe, 12, 26, 9)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        # 3. EMA - Trend yönü için
        dataframe['ema5'] = ta.EMA(dataframe['close'], timeperiod=5)
        dataframe['ema20'] = ta.EMA(dataframe['close'], timeperiod=20)
        dataframe['ema5o'] = ta.EMA(dataframe['open'], timeperiod=5)

        # 4. Bollinger Bands - Volatilite ve aşırı alım/satım
        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bb['upperband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_lower'] = bb['lowerband']
        dataframe['bb_width'] = (dataframe['bb_upper'] - dataframe['bb_lower']) / dataframe['bb_middle']
        bb_range = dataframe['bb_upper'] - dataframe['bb_lower']
        bb_range = bb_range.replace(0, np.nan)
        dataframe['bb_position'] = (dataframe['close'] - dataframe['bb_lower']) / bb_range

        # 5. RSI - Momentum teyidi
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # 6. Volume - Onay filtresi
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()

        # 7. ATR - Volatilite ölçümü
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        MÜHENDİSLİK KARARI: KALİTE > MİKTAR
        ------------------------------------
        Orijinal strateji ayda 443 işlem yapıyordu. Bu aşırı işlem
        komisyon ve spread maliyetini artırır. V3'te her giriş koşulu
        zorunlu - sadece en kaliteli sinyallerde gir.

        Giriş Koşulları (HEPSİ birden sağlanmalı):
        1. MACD histogram > 0 VE artıyor → Boğa momentumu hızlanıyor
        2. Stochastic aşırı değil (20-85 arası)
        3. Fiyat BB alt yarısında → Dip alım fırsatı
        4. EMA5c > EMA5o → Mum içi boğa
        5. RSI > 40 → Aşırı satım değil
        6. Volume ortalamanın üzerinde → Teyitli hareket
        """
        dataframe['enter_long'] = 0

        dataframe.loc[
            (
                # 1. MACD histogram momentum (BİASSIZ!)
                (dataframe['macdhist'] > 0) &
                (dataframe['macdhist'] > dataframe['macdhist'].shift(2))
            ) &
            (
                # 2. Stochastic filtre (orijinal ruh korundu)
                (dataframe['fastk'] >= 20) & (dataframe['fastk'] <= 85) &
                (dataframe['fastd'] >= 20) & (dataframe['fastd'] <= 85)
            ) &
            (
                # 3. Bollinger pozisyonu - alt yarıda al (dip yakalama)
                (dataframe['bb_position'] <= 0.6)
            ) &
            (
                # 4. EMA trend
                (dataframe['ema5'] > dataframe['ema5o'])
            ) &
            (
                # 5. RSI sağlıklı bölgede
                (dataframe['rsi'] > 40)
            ) &
            (
                # 6. Hacim onayı
                (dataframe['volume'] > dataframe['volume_sma'] * 0.7)
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        MÜHENDİSLİK KARARI: ÇOKLU ÇIKIŞ STRATEJİSİ
        -------------------------------------------
        Tek bir çıkış koşulu yerine 3 farklı senaryoda çık:
        1. MACD momentum kaybı (histogram düşüşü)
        2. Aşırı alım (Stochastic > 85)
        3. BB üst bandına ulaşma (fiyat çok yükseldi)
        """
        dataframe['exit_long'] = 0

        dataframe.loc[
            (
                # 1. MACD zayıflıyor
                (dataframe['macdhist'] < dataframe['macdhist'].shift(3))
            ) &
            (
                # 2a. Ya Stochastic aşırı alım
                (dataframe['fastk'] > 85) |
                # 2b. Ya BB üst bandına yakın
                (dataframe['bb_position'] > 0.85) |
                # 2c. Ya RSI aşırı alım
                (dataframe['rsi'] > 70)
            ),
            'exit_long'] = 1

        return dataframe
