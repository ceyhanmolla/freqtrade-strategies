from datetime import datetime
import talib.abstract as ta
import numpy as np
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.persistence import Trade
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from pandas import DataFrame


class E0V1E(IStrategy):
    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.03,
        "60": 0.015,
        "120": 0.01
    }

    timeframe = '5m'

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.025
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    process_only_new_candles = True
    startup_candle_count = 120
    position_adjustment_enable = True

    buy_rsi_fast = IntParameter(20, 70, default=46, space='buy')
    buy_rsi = IntParameter(15, 50, default=19, space='buy')
    buy_sma15 = DecimalParameter(0.900, 1.0, default=0.942, decimals=3, space='buy')

    def custom_stake_amount(self, pair: str, current_time: datetime, current_rate: float,
                            proposed_stake: float, min_stake: float, max_stake: float,
                            leverage: float, entry_tag: str, side: str,
                            **kwargs) -> float:
        return proposed_stake * 0.7

    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float,
                              min_stake: float, max_stake: float,
                              current_entry_rate: float, current_exit_rate: float,
                              current_entry_profit: float, current_exit_profit: float,
                              **kwargs) -> float:

        count_of_exits = trade.nr_of_successful_exits
        if current_profit >= 0.02 and count_of_exits == 0:
            return -0.5 * trade.stake_amount

        count_of_entries = trade.nr_of_successful_entries
        filled_entries = trade.select_filled_orders(trade.entry_side)
        initial_stake = filled_entries[0].cost

        if current_profit < -0.05 and count_of_entries == 1:
            return initial_stake / 0.7 * 0.3
        return None

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        dataframe['sma_15'] = ta.SMA(dataframe, timeperiod=15)
        
        # CTI replacement: Correlation with linear regression slope
        # Using linearreg slope as trend indicator
        dataframe['cti'] = ta.LINEARREG_SLOPE(dataframe['close'], timeperiod=20)
        
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)
        dataframe['rsi_slow'] = ta.RSI(dataframe, timeperiod=20)

        stoch_fast = ta.STOCHF(dataframe, fastk_period=5, fastd_period=3, fastd_matype=0)
        dataframe['fastk'] = stoch_fast['fastk']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # Entry 1: RSI-based
        buy_1 = (
                (dataframe['rsi'] < 35) &
                (dataframe['close'] < dataframe['sma_15']) &
                (dataframe['volume'] > 0)
        )
        dataframe.loc[buy_1, 'enter_long'] = 1
        dataframe.loc[buy_1, 'enter_tag'] = 'rsi_oversold'

        # Entry 2: Stochastic oversold
        buy_2 = (
                (dataframe['fastk'] < 20) &
                (dataframe['rsi'] < 40) &
                (dataframe['volume'] > 0)
        )
        dataframe.loc[buy_2, 'enter_long'] = 1
        dataframe.loc[buy_2, 'enter_tag'] = 'stoch_oversold'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''

        # RSI extreme overbought exit (80+ only)
        dataframe.loc[
            (dataframe['rsi'] > 80) &
            (dataframe['rsi'] < dataframe['rsi'].shift(1)),
            ['exit_long', 'exit_tag']
        ] = (1, 'rsi_extreme')

        return dataframe