"""
EwoMomentumV1 - EWO Momentum Strategy
======================================
- EWO = SMA(50) - SMA(200), close'a normalize
- Trend takibi (EWO > 1.5, RSI < 48) + Dip alim (EWO < -2.0, RSI < 40)
- Cikis: trailing stop + ROI + stoploss
- 5m timeframe / v3 interface
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame

import talib.abstract as ta


def EWO(dataframe, sma_fast_length=50, sma_slow_length=200):
    sma_fast = ta.SMA(dataframe, timeperiod=sma_fast_length)
    sma_slow = ta.SMA(dataframe, timeperiod=sma_slow_length)
    return (sma_fast - sma_slow) / dataframe['close'] * 100


class EwoMomentumV1(IStrategy):
    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.02,
        "60": 0.01,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.01
    trailing_only_offset_is_reached = True

    use_exit_signal = False

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_mean_20'] = dataframe['volume'].rolling(20).mean()
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        buy_cond1 = (
            (dataframe['EWO'] > 5.0) &
            (dataframe['rsi'] < 35) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_mean_20'] * 3)
        )

        buy_cond2 = (
            (dataframe['EWO'] < -2.0) &
            (dataframe['rsi'] < 35) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] > dataframe['volume_mean_20'] * 0.5)
        )

        dataframe.loc[buy_cond1, 'enter_long'] = 1
        dataframe.loc[buy_cond1, 'enter_tag'] = 'trend_momentum'
        dataframe.loc[buy_cond2, 'enter_long'] = 1
        dataframe.loc[buy_cond2, 'enter_tag'] = 'dip_oversold'
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        return dataframe
