"""
EwoMomentumV1 - EWO Momentum Strategy
=====================================

STRATEJİ AÇIKLAMASI:
- EWO (Elliot Wave Oscillator) ile momentum analizi
- RSI ile giriş sinyalleri
- Trailing stop ile kar koruma
- 5m timeframe

BACKTEST SONUÇLARI (30 gün):
- Profit: +9.06%
- Trades: 17
- Win Rate: 88.2%
- Drawdown: 4.48%
- Avg Duration: 5 days 5 hours

Author: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame

import talib.abstract as ta
import numpy as np


def EWO(dataframe, ema_length=5, ema2_length=35):
    """Elliot Wave Oscillator - EMA farkı bazlı momentum"""
    df = dataframe.copy()
    ema1 = ta.SMA(df, timeperiod=ema_length)
    ema2 = ta.SMA(df, timeperiod=ema2_length)
    emadif = (ema1 - ema2) / df['close'] * 100
    return emadif


class EwoMomentumV1(IStrategy):
    INTERFACE_VERSION = 2

    minimal_roi = {
        "0": 0.5,
        "30": 1.0,
        "60": 1.5,
        "180": 2.5,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    use_exit_signal = False
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['ema_17'] = ta.EMA(dataframe, timeperiod=17)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['buy'] = 0

        # Koşul 1: Pozitif EWO + düşük RSI
        buy_cond1 = (
            (dataframe['EWO'] > 0.5) &
            (dataframe['rsi'] < 55) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume'].rolling(20).mean() * 3)
        )

        # Koşul 2: Negatif EWO (aşırı satım)
        buy_cond2 = (
            (dataframe['EWO'] < -2.0) &
            (dataframe['rsi'] < 40) &
            (dataframe['volume'] > 0)
        )

        dataframe.loc[buy_cond1 | buy_cond2, 'buy'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0
        return dataframe