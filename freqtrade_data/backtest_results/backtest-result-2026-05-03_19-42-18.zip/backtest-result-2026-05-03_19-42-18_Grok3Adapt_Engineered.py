import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, merge_informative_pair
from typing import Dict, Optional
from pandas import DataFrame
import talib.abstract as ta
from datetime import datetime, timedelta
from freqtrade.persistence import Trade
import pandas as pd

class Grok3Adapt_Engineered(IStrategy):
    INTERFACE_VERSION = 3
    can_short = False

    minimal_roi = {
        "360": 0.004,
        "120": 0.012,
        "60": 0.008,
        "30": 0.006,
        "0": 0.004
    }

    stoploss = -0.08  
    trailing_stop = True
    trailing_stop_positive = 0.004  
    trailing_stop_positive_offset = 0.012  
    trailing_only_offset_is_reached = True

    timeframe = "5m"
    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = True

    max_open_trades = 2  
    position_adjustment_enable = True
    max_entry_position_adjustment = 2  
    max_dca_multiplier = 0.4  
    rsi_upper_threshold = 75
    rsi_lower_threshold = 25

    buy_rsi = IntParameter(20, 40, default=30, space="buy", optimize=True)
    sell_rsi = IntParameter(60, 80, default=75, space="sell", optimize=True)
    risk_factor = DecimalParameter(0.3, 0.7, default=0.5, decimals=2, space="buy", optimize=True)
    leverage_factor = DecimalParameter(2.0, 5.0, default=3.0, decimals=1, space="buy", optimize=True)

    startup_candle_count = 200

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False,
    }

    order_time_in_force = {"entry": "GTC", "exit": "GTC"}

    logger = logging.getLogger(__name__)

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.last_dca_level = {}
        self.initial_balance = 95.0 
        # Haber API'si ve gereksiz ağırlıklar temizlendi[cite: 5].

    def informative_pairs(self):
        # BTC ve ETH için 1 saatlik verileri çekiyoruz
        pairs = self.dp.current_whitelist()
        informative_pairs = [(pair, '1h') for pair in pairs]
        informative_pairs.extend([("BTC/USDT", "1h"), ("ETH/USDT", "1h")])
        return informative_pairs

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=10)
        dataframe["rsi_prev"] = dataframe["rsi"].shift(1) # RSI teyidi için[cite: 5]
        
        dataframe["sma_short"] = ta.SMA(dataframe, timeperiod=5)
        dataframe["sma_long"] = ta.SMA(dataframe, timeperiod=10)
        dataframe["ema_short"] = ta.EMA(dataframe, timeperiod=5)
        dataframe["ema_long"] = ta.EMA(dataframe, timeperiod=10)
        
        macd = ta.MACD(dataframe)
        dataframe["macd"] = macd["macd"]
        dataframe["macd_signal"] = macd["macdsignal"]
        
        stochrsi = ta.STOCHRSI(dataframe, timeperiod=14, fastk_period=3, fastd_period=3)
        dataframe["stoch_rsi"] = stochrsi["fastk"]
        dataframe["min_price_20"] = dataframe["low"].rolling(window=20).min()
        
        dataframe["close_prev"] = dataframe["close"].shift(1)
        dataframe["max_price_10"] = dataframe["high"].rolling(window=10).max()
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=14)
        
        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()
        dataframe["volume_sma_50"] = ta.SMA(dataframe["volume"], timeperiod=50)
        
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe["bb_lower"] = bollinger["lowerband"]
        dataframe["bb_middle"] = bollinger["middleband"]
        dataframe["bb_upper"] = bollinger["upperband"]
        dataframe["bb_width"] = (dataframe["bb_upper"] - dataframe["bb_lower"]) / dataframe["bb_middle"]
        
        dataframe["vwap"] = ((dataframe["close"] * dataframe["volume"]).cumsum() / dataframe["volume"].cumsum())

        # =========================================================
        # KALKAN 2: YÖNLÜ HACİM ŞOKU FİLTRESİ
        # Hacim ortalamanın 5 katıysa VE mum kırmızıysa (Satış/Dump baskısı)
        # =========================================================
        dataframe["red_volume_shock"] = (dataframe["volume"] > dataframe["volume_sma_50"] * 5) & (dataframe["open"] > dataframe["close"])

        # =========================================================
        # KALKAN 1: ÇİFT TEYİT MODU (BTC & ETH 1h 50-200 EMA)
        # =========================================================
        if self.dp:
            btc_1h = self.dp.get_pair_dataframe(pair="BTC/USDT", timeframe="1h")
            eth_1h = self.dp.get_pair_dataframe(pair="ETH/USDT", timeframe="1h")

            btc_1h["btc_ema_50_1h"] = ta.EMA(btc_1h, timeperiod=50)
            btc_1h["btc_ema_200_1h"] = ta.EMA(btc_1h, timeperiod=200)
            btc_1h["btc_close_1h"] = btc_1h["close"]

            eth_1h["eth_ema_50_1h"] = ta.EMA(eth_1h, timeperiod=50)
            eth_1h["eth_ema_200_1h"] = ta.EMA(eth_1h, timeperiod=200)
            eth_1h["eth_close_1h"] = eth_1h["close"]

            dataframe = merge_informative_pair(dataframe, btc_1h, self.timeframe, "1h", ffill=True)
            dataframe = merge_informative_pair(dataframe, eth_1h, self.timeframe, "1h", ffill=True)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata["pair"]
        open_trades = Trade.get_open_trades()
        if any(trade.pair == pair for trade in open_trades):
            return dataframe

        last_candle = dataframe.iloc[-1]
        
        # Hata önleme: BTC/ETH verisi çekilemediyse güvenli olarak işlemi kapat.
        if "btc_close_1h" not in dataframe.columns or "eth_close_1h" not in dataframe.columns:
            return dataframe

        # MACRO TREND KORUMASI: Hem BTC hem ETH kendi 200 EMA'sının üzerinde olmalı.
        macro_protection = (
            (dataframe["btc_close_1h"] > dataframe["btc_ema_200_1h"]) &
            (dataframe["eth_close_1h"] > dataframe["eth_ema_200_1h"]) &
            (~dataframe["red_volume_shock"])  # Kırmızı hacim şoku yoksa
        )

        dynamic_rsi = max(20, self.buy_rsi.value - (last_candle["atr"] / last_candle["close"] * 10))
        alternative_entry = (
            (dataframe["ema_short"] > dataframe["ema_long"]) &
            (dataframe["macd"] > dataframe["macd_signal"])
        )
        
        initial_entry = (
            (dataframe["rsi"] < dynamic_rsi) &
            (dataframe["sma_short"] > dataframe["sma_long"]) &
            (dataframe["adx"] > 25) &
            (dataframe["volume"] > dataframe["volume_sma"] * (2.0 * self.risk_factor.value)) &
            (dataframe["volume"] > dataframe["volume_sma_50"]) &
            (dataframe["stoch_rsi"] < 0.2) &
            (dataframe["close"] <= dataframe["bb_lower"] * 1.01) &
            (dataframe["bb_width"] < 0.05) &
            (dataframe["close"] > dataframe["vwap"] * 0.995) 
        ) | alternative_entry

        dataframe.loc[initial_entry & macro_protection, "enter_long"] = 1
        dataframe["enter_long"] = dataframe["enter_long"].fillna(0).astype(int)
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata["pair"]
        open_trades = Trade.get_open_trades()
        trade = next((t for t in open_trades if t.pair == pair), None)
        if not trade:
            return dataframe

        last_candle = dataframe.iloc[-1]
        current_profit = trade.calc_profit_ratio(last_candle["close"])
        volatility_factor = last_candle["atr"] / last_candle["close"]

        base_rsi = self.sell_rsi.value
        adaptive_rsi = min(95, base_rsi + (0.02 / (volatility_factor + 0.01) * 100))
        if last_candle["adx"] > 25:
            adaptive_rsi = min(95, adaptive_rsi + 5 * self.risk_factor.value)
        if current_profit > 0.01 * self.risk_factor.value:
            adaptive_rsi = min(95, adaptive_rsi + 3 * self.risk_factor.value)

        exit_condition = (
            (current_profit > 0.005 * self.risk_factor.value) &
            (
                (dataframe["rsi"] > adaptive_rsi) &
                (dataframe["rsi"] < dataframe["rsi_prev"]) &
                (dataframe["close"] < dataframe["max_price_10"] * 0.995) &
                (dataframe["close"] < dataframe["vwap"] * 1.005)  
            ) |
            (
                (dataframe["macd"] < dataframe["macd_signal"]) &
                (dataframe["adx"] < 20)
            )
        )

        dataframe.loc[exit_condition, "exit_long"] = 1
        dataframe["exit_long"] = dataframe["exit_long"].fillna(0).astype(int)
        return dataframe

    def custom_stake_amount(self, pair: str, current_rate: float, current_time: datetime, 
                           proposed_stake: float, min_stake: float, max_stake: float, **kwargs) -> float:
        
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return min_stake
            
        last_candle = dataframe.iloc[-1].squeeze()
        
        # =========================================================
        # KADEMELİ HİBRİT TREND: 50 EMA Altındaysa riski (bütçeyi) yarıya indir
        # =========================================================
        btc_weak = last_candle.get("btc_close_1h", 0) < last_candle.get("btc_ema_50_1h", 0)
        eth_weak = last_candle.get("eth_close_1h", 0) < last_candle.get("eth_ema_50_1h", 0)
        
        risk_modifier = 0.5 if (btc_weak or eth_weak) else 1.0
        
        available_balance = self.wallets.get_free("USDT")
        # Eski risk_factor'e risk_modifier çarpanını ekliyoruz[cite: 5].
        stake_percentage = 0.05 * (self.risk_factor.value * risk_modifier)  
        fixed_stake = available_balance * stake_percentage * self.leverage_factor.value
        
        min_stake = max(min_stake, 1.0)  
        if fixed_stake < min_stake:
            return min_stake
        if fixed_stake > max_stake:
            return max_stake
        if fixed_stake > available_balance:
            return available_balance
            
        self.logger.info(f"Entry stake for {pair}: {fixed_stake:.2f} USDT (leverage: {self.leverage_factor.value}x, Risk Modifier: {risk_modifier})")
        return fixed_stake

    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float,
                              min_stake: float, max_stake: float,
                              **kwargs) -> Optional[float]:
        if not trade.is_open:
            return None

        pair = trade.pair
        orders_count = trade.nr_of_successful_entries
        if orders_count > self.max_entry_position_adjustment:
            return None

        avg_price = trade.open_rate
        close = current_rate
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        last_candle = dataframe.iloc[-1]

        if current_profit > 0.008 * self.risk_factor.value:
            amount_to_sell = trade.amount * 0.4 * self.risk_factor.value
            return -amount_to_sell

        price_drop = (avg_price - close) / avg_price
        dca_step = 1.5 * last_candle["atr"] / last_candle["close"]
        max_price_drop = 3 * last_candle["atr"] / last_candle["close"]
        adx = last_candle["adx"]
        macd = last_candle["macd"]
        macd_signal = last_candle["macd_signal"]
        rsi = last_candle["rsi"]
        rsi_prev = last_candle.get("rsi_prev", rsi)

        if adx < 15:
            return None

        if macd < macd_signal and rsi > self.rsi_lower_threshold:
            pass
        elif macd >= macd_signal:
            pass
        else:
            return None

        # =========================================================
        # KALKAN 3: MOMENTUM TEYİTLİ DCA (Düşen Bıçak Koruması)
        # Fiyat DCA seviyesine gelmiş olsa bile, RSI kafasını yukarı kaldırmadan alım yapma.
        # =========================================================
        if rsi <= rsi_prev:
            self.logger.info(f"DCA delayed for {pair}: RSI ({rsi:.2f}) is not rising (Prev: {rsi_prev:.2f}). Waiting for momentum shift.")
            return None

        if price_drop >= max_price_drop:
            return None

        if trade.id not in self.last_dca_level:
            self.last_dca_level[trade.id] = 0.0

        current_dca_level = (price_drop // dca_step) * dca_step
        last_dca_level = self.last_dca_level[trade.id]

        if price_drop >= dca_step and current_dca_level > last_dca_level:
            self.last_dca_level[trade.id] = current_dca_level
            atr = last_candle["atr"]
            volatility_factor = atr / last_candle["close"]
            total_position = sum(o.stake_amount for o in trade.orders)

            if rsi < self.rsi_lower_threshold:
                new_stake = trade.stake_amount * 0.7 * self.risk_factor.value * (1 + volatility_factor) * self.leverage_factor.value
            elif rsi > self.rsi_upper_threshold:
                new_stake = trade.stake_amount * 0.3 * self.risk_factor.value * (1 + volatility_factor) * self.leverage_factor.value
            else:
                new_stake = trade.stake_amount * 0.4 * self.risk_factor.value * (1 + volatility_factor) * self.leverage_factor.value

            if total_position + new_stake > trade.stake_amount * 3 * self.risk_factor.value * self.leverage_factor.value:
                return None

            min_stake = max(min_stake, 1.0)
            if new_stake < min_stake:
                new_stake = min_stake
            if new_stake > max_stake:
                new_stake = max_stake

            available_balance = self.wallets.get_free("USDT")
            if new_stake > available_balance:
                return None

            return new_stake

        return None

    def custom_roi(self, trade: Trade, current_profit: float, current_time: datetime, **kwargs) -> Dict[str, float]:
        time_open = (current_time - trade.open_date).total_seconds() / 3600  
        roi_multiplier = 0.8 + 0.2 * self.leverage_factor.value / 5.0  
        if time_open < 1:  
            dynamic_roi = max(0.002, 0.003 * self.risk_factor.value * (1 + current_profit) * roi_multiplier)
        elif time_open < 6:  
            dynamic_roi = max(0.004, 0.006 * self.risk_factor.value * (1 + current_profit * 1.5) * roi_multiplier)
        elif time_open < 24:  
            dynamic_roi = max(0.006, 0.008 * self.risk_factor.value * (1 + current_profit * 2) * roi_multiplier)
        else:  
            dynamic_roi = max(0.004, 0.005 * self.risk_factor.value * (1 + current_profit * 2.5) * roi_multiplier)
        
        return {"0": dynamic_roi}

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        atr = dataframe.iloc[-1]["atr"]
        dynamic_stoploss = -1.5 * atr / current_rate * self.risk_factor.value / self.leverage_factor.value
        return max(self.stoploss / self.leverage_factor.value, dynamic_stoploss)

    def leverage(self, pair: str, current_time: datetime, current_rate: float,
                 proposed_leverage: float, **kwargs) -> float:
        return self.leverage_factor.value