"""
TheForceV3b - Sıkı Stoploss + Hızlı Exit
=========================================

MÜHENDİSLİK KARARLARI:
-----------------------
V3'te 32 kaybeden işlemin hepsi -5% stoploss'a tosladı.
Bu versiyonda:
1. Stoploss -5% → -3% (kayıpları küçült)
2. Exit daha hızlı (histogram 1 periyotluk düşüşte çık)
3. Entry'de daha sıkı BB filtresi (sadece alt yarı)
4. Trailing offset düşürüldü (kârı daha erken kilitle)

Author: OpenCode Assistant
Date: 2026-05-06
"""

import numpy as np
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class TheForceV3b(IStrategy):

    INTERFACE_VERSION = 3

    minimal_roi = {
        "60": 0.01,
        "30": 0.005,
        "0": 0.003
    }

    # === V3'ten fark: -5% → -3% ===
    stoploss = -0.03

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.015  # V3'te 0.02 idi
    trailing_only_offset_is_reached = True

    timeframe = '15m'
    startup_candle_count = 50

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    order_time_in_force = {
        'entry': 'GTC',
        'exit': 'GTC'
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        # 1. Stochastic
        stoch_fast = ta.STOCHF(dataframe, 5, 3, 3)
        dataframe['fastd'] = stoch_fast['fastd']
        dataframe['fastk'] = stoch_fast['fastk']

        # 2. MACD - BİASSIZ
        macd = ta.MACD(dataframe, 12, 26, 9)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']

        # 3. EMA
        dataframe['ema5'] = ta.EMA(dataframe['close'], timeperiod=5)
        dataframe['ema20'] = ta.EMA(dataframe['close'], timeperiod=20)
        dataframe['ema5o'] = ta.EMA(dataframe['open'], timeperiod=5)

        # 4. Bollinger Bands
        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bb['upperband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_lower'] = bb['lowerband']
        dataframe['bb_width'] = (dataframe['bb_upper'] - dataframe['bb_lower']) / dataframe['bb_middle']
        bb_range = dataframe['bb_upper'] - dataframe['bb_lower']
        bb_range = bb_range.replace(0, np.nan)
        dataframe['bb_position'] = (dataframe['close'] - dataframe['bb_lower']) / bb_range

        # 5. RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # 6. Volume
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()

        # 7. ATR
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0

        dataframe.loc[
            (
                # 1. MACD histogram momentum
                (dataframe['macdhist'] > 0) &
                (dataframe['macdhist'] > dataframe['macdhist'].shift(2))
            ) &
            (
                # 2. Stochastic (daha sıkı!)
                (dataframe['fastk'] >= 25) & (dataframe['fastk'] <= 80) &
                (dataframe['fastd'] >= 25) & (dataframe['fastd'] <= 80)
            ) &
            (
                # 3. BB pozisyonu - ALT YARIDA AL (V3'ten sıkı)
                (dataframe['bb_position'] <= 0.4)  # 0.6 → 0.4
            ) &
            (
                # 4. EMA trend
                (dataframe['ema5'] > dataframe['ema5o'])
            ) &
            (
                # 5. RSI (daha sıkı - 40 → 45)
                (dataframe['rsi'] > 45) & (dataframe['rsi'] < 65)
            ) &
            (
                # 6. Hacim onayı (daha sıkı!)
                (dataframe['volume'] > dataframe['volume_sma'])
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        V3'ten fark: Exit DAHA HIZLI!
        """
        dataframe['exit_long'] = 0

        dataframe.loc[
            (
                # 1. MACD momentum zayıflıyor (1 period - DAHA HIZLI)
                (dataframe['macdhist'] < dataframe['macdhist'].shift(1))
            ) &
            (
                # 2a. Stochastic aşırı alım
                (dataframe['fastk'] > 80) |
                # 2b. BB üst bandına yakın
                (dataframe['bb_position'] > 0.8) |
                # 2c. RSI aşırı alım
                (dataframe['rsi'] > 68)
            ),
            'exit_long'] = 1

        return dataframe
