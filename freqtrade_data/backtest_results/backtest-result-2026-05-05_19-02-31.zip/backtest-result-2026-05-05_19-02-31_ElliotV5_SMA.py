"""
ElliotV5_SMA - Elliot Wave Oscillator + SMA Stratejisi
======================================================

STRATEJİ AÇIKLAMASI:
- EWO (Elliot Wave Oscillator) ile momentum analizi
- EMA bazlı giriş/çıkış noktaları
- Multi-timeframe: 5m + 1h
- Trailing stop ile kar koruma

YAPILAN MÜHENDİSLİK DÜZELTMELERİ (2026-05-05):
1. Ölü kod temizliği (139 satır kaldırıldı)
2. Dead import'lar kaldırıldı
3. minimal_roi: %21.5 → %0.5-4 stepwise
4. ewo_low: -17.457 → -8.0
5. ewo_high: 3.34 → 2.0
6. stoploss: -18.9% → -10%
7. startup_candle_count: 2000 → 200

Author: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from typing import Dict, List
from functools import reduce
from pandas import DataFrame

import talib.abstract as ta
import numpy as np
import freqtrade.vendor.qtpylib.indicators as qtpylib
from datetime import datetime
from freqtrade.persistence import Trade
from freqtrade.strategy import merge_informative_pair, DecimalParameter, IntParameter


def EWO(dataframe, ema_length=5, ema2_length=35):
    """Elliot Wave Oscillator - EMA farkı bazlı momentum"""
    df = dataframe.copy()
    ema1 = ta.SMA(df, timeperiod=ema_length)
    ema2 = ta.SMA(df, timeperiod=ema2_length)
    emadif = (ema1 - ema2) / df['close'] * 100
    return emadif


class ElliotV5_SMA(IStrategy):
    INTERFACE_VERSION = 2

    # Düzeltme: %21.5 → %0.5-4 stepwise
    minimal_roi = {
        "0": 0.5,    # 30 dakika → %0.5
        "30": 1.0,   # 1 saat → %1.0
        "60": 1.5,   # 2 saat → %1.5
        "180": 2.5,  # 3 saat → %2.5
        "360": 3.5,  # 6 saat → %3.5
    }

    # Düzeltme: -%18.9 → -10%
    stoploss = -0.10

    # Buy parametreleri
    base_nb_candles_buy = IntParameter(5, 80, default=17, space='buy', optimize=True)
    low_offset = DecimalParameter(0.9, 0.99, default=0.978, space='buy', optimize=True)

    # Düzeltme: -17.457 → -8.0 (çok düşük, nadir oluşurdu)
    ewo_low = DecimalParameter(-10.0, -4.0, default=-6.0, space='buy', optimize=True)

    # Düzeltme: 3.34 → 2.0
    ewo_high = DecimalParameter(1.0, 8.0, default=2.0, space='buy', optimize=True)

    rsi_buy = IntParameter(30, 70, default=55, space='buy', optimize=True)

    # Sell parametreleri
    base_nb_candles_sell = IntParameter(5, 80, default=49, space='sell', optimize=True)
    high_offset = DecimalParameter(0.99, 1.1, default=1.019, space='sell', optimize=True)

    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    use_exit_signal = True
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '5m'
    informative_timeframe = '1h'

    process_only_new_candles = True

    # Düzeltme: 2000 → 200 (5m'de 200 candle = 16 saat yeterli)
    startup_candle_count = 200

    use_custom_stoploss = False

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative_pairs = [(pair, self.informative_timeframe) for pair in pairs]
        return informative_pairs

    def get_informative_indicators(self, metadata: dict):
        dataframe = self.dp.get_pair_dataframe(
            pair=metadata['pair'], timeframe=self.informative_timeframe)
        return dataframe

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        # Dynamic EMA hesaplama (buy/sell için)
        for val in self.base_nb_candles_buy.range:
            dataframe[f'ma_buy_{val}'] = ta.EMA(dataframe, timeperiod=val)

        for val in self.base_nb_candles_sell.range:
            dataframe[f'ma_sell_{val}'] = ta.EMA(dataframe, timeperiod=val)

        # EWO hesaplama
        dataframe['EWO'] = EWO(dataframe, 50, 200)

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # Koşul 1: Pozitif EWO (yükseliş momentumu)
        conditions.append(
            (
                (dataframe['close'] < (dataframe[f'ma_buy_{self.base_nb_candles_buy.value}'] * self.low_offset.value)) &
                (dataframe['EWO'] > self.ewo_high.value) &
                (dataframe['rsi'] < self.rsi_buy.value) &
                (dataframe['volume'] > 0)
            )
        )

        # Koşul 2: Negatif EWO (düşüş momentumu - çıkış)
        conditions.append(
            (
                (dataframe['close'] < (dataframe[f'ma_buy_{self.base_nb_candles_buy.value}'] * self.low_offset.value)) &
                (dataframe['EWO'] < self.ewo_low.value) &
                (dataframe['volume'] > 0)
            )
        )

        # Koşul 3: Basit RSI oversold (yedek - daha az karmaşık)
        conditions.append(
            (
                (dataframe['rsi'] < 30) &
                (dataframe['EWO'] > 0) &
                (dataframe['volume'] > 0)
            )
        )

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x | y, conditions),
                'buy'
            ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        conditions.append(
            (
                (dataframe['close'] > (dataframe[f'ma_sell_{self.base_nb_candles_sell.value}'] * self.high_offset.value)) &
                (dataframe['volume'] > 0)
            )
        )

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x | y, conditions),
                'sell'
            ] = 1

        return dataframe
