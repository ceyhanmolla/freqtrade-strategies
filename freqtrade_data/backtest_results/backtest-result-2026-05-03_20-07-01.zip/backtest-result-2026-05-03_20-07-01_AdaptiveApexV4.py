import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional

from freqtrade.strategy import (IStrategy, IntParameter, DecimalParameter, 
                                merge_informative_pair, stoploss_from_open)
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

logger = logging.getLogger(__name__)

def chaikin_money_flow(dataframe, n=20):
    mfv = ((dataframe['close'] - dataframe['low']) - (dataframe['high'] - dataframe['close'])) / (dataframe['high'] - dataframe['low'])
    mfv = mfv.fillna(0.0)
    mfv *= dataframe['volume']
    cmf = (mfv.rolling(n, min_periods=0).sum() / dataframe['volume'].rolling(n, min_periods=0).sum())
    return pd.Series(cmf, name='cmf')

def VWAPB(dataframe, window_size=20, num_of_std=1):
    df = dataframe.copy()
    df['vwap'] = qtpylib.rolling_vwap(df, window=window_size)
    rolling_std = df['vwap'].rolling(window=window_size).std()
    df['vwap_low'] = df['vwap'] - (rolling_std * num_of_std)
    return df['vwap_low']

class AdaptiveApexV4(IStrategy):
    INTERFACE_VERSION = 3

    timeframe = '5m'
    informative_timeframe = '1h'

    # --- HÜCUM (Giriş Ayarları) ---
    buy_adx = IntParameter(20, 40, default=25, space="buy")
    buy_rsi_base = IntParameter(25, 45, default=35, space="buy")
    
    # --- SAVUNMA (Anti-Pump & Risk) ---
    anti_pump_threshold = DecimalParameter(1.10, 1.30, default=1.15, space='buy') # 24 saatte %15'ten fazla artmışsa uzak dur
    
    # --- KURTARMA (DCA Ayarları) ---
    position_adjustment_enable = True
    max_entry_position_adjustment = 3 
    max_dca_multiplier = 1.5

    # --- DİNAMİK STOPLOSS (NASOS) ---
    use_custom_stoploss = True
    pHSL = DecimalParameter(-0.150, -0.050, default=-0.10, space='sell')
    pPF_1 = DecimalParameter(0.010, 0.025, default=0.016, space='sell')
    pSL_1 = DecimalParameter(0.010, 0.020, default=0.014, space='sell')
    pPF_2 = DecimalParameter(0.040, 0.080, default=0.050, space='sell')
    pSL_2 = DecimalParameter(0.020, 0.050, default=0.030, space='sell')

    # ROI (Sadece ana hedefler, dinamiğe alan bırakıldı)
    minimal_roi = {
        "0": 0.15,
        "60": 0.05,
        "180": 0.02,
        "300": 0
    }

    stoploss = -0.15

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        return [(pair, self.informative_timeframe) for pair in pairs]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        
        # === 1H INFORMATIVE (Anti-Pump & Makro Trend) ===
        inf_tf = self.informative_timeframe
        informative = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe=inf_tf)

        # DCA için Para Akışı ve RSI
        informative['cmf'] = chaikin_money_flow(informative, 20)
        informative['rsi'] = ta.RSI(informative, timeperiod=14)

        # NFI Anti-Pump Mantığı (Son 24 Saatin Volatilitesi)
        informative['rolling_max_24'] = informative['high'].rolling(24).max()
        informative['rolling_min_24'] = informative['low'].rolling(24).min()
        informative['pump_ratio'] = informative['rolling_max_24'] / informative['rolling_min_24']
        informative['safe_pump'] = informative['pump_ratio'] < self.anti_pump_threshold.value

        dataframe = merge_informative_pair(dataframe, informative, self.timeframe, inf_tf, ffill=True)

        # === 5M NORMAL BİRİMLER (Giriş & Çıkış için) ===
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['ema_9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema_21'] = ta.EMA(dataframe, timeperiod=21)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        
        # Volatilite ve Momentum (AdaptiveMomentum'dan uyarlandı)
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        dataframe['vwap_low'] = VWAPB(dataframe, 20, 1)
        
        # Hacim Spikeları için
        dataframe['volume_sma'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        
        # Dinamik RSI Hesaplaması: Volatilite arttıkça RSI eşiği düşer (Daha zor giriş)
        volatility_factor = dataframe['atr'] / dataframe['close']
        dataframe['dynamic_rsi_threshold'] = np.maximum(20, self.buy_rsi_base.value - (volatility_factor * 10))

        # Giriş Sinyali
        dataframe.loc[
            (
                (dataframe['ema_9'] > dataframe['ema_21']) & # Kısa vadeli yükseliş eğilimi
                (dataframe['adx'] > self.buy_adx.value) &    # Güçlü trend onayı
                (dataframe['rsi'] < dataframe['dynamic_rsi_threshold']) & # Volatilite uyarlamalı Aşırı Satım
                (dataframe['volume'] > dataframe['volume_sma'] * 1.2) &   # Hacim artışı
                (dataframe[f'safe_pump_{self.informative_timeframe}'] == True) & # Anti-Pump devrede
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']
        ] = (1, 'adaptive_sniper_entry')

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''
        return dataframe

    # === DİNAMİK STOPLOSS (NASOS Mimarisi) ===
    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:

        HSL = self.pHSL.value
        PF_1 = self.pPF_1.value
        SL_1 = self.pSL_1.value
        PF_2 = self.pPF_2.value
        SL_2 = self.pSL_2.value

        # Kâr arttıkça stoploss çizgisini yukarı çeken doğrusal interpolasyon
        if current_profit > PF_2:
            sl_profit = SL_2 + (current_profit - PF_2)
        elif current_profit > PF_1:
            sl_profit = SL_1 + ((current_profit - PF_1) * (SL_2 - SL_1) / (PF_2 - PF_1))
        else:
            sl_profit = HSL

        if sl_profit >= current_profit:
            return -0.99

        return stoploss_from_open(sl_profit, current_profit)

    # === TIME STOP & EKSTREM ÇIKIŞLAR ===
    def custom_exit(self, pair: str, trade: Trade, current_time: datetime, current_rate: float,
                    current_profit: float, **kwargs) -> Optional[str]:
        
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return None
            
        last_candle = dataframe.iloc[-1].squeeze()
        trade_duration_minutes = (current_time - trade.open_date_utc).total_seconds() / 60

        # Zaman Aşımı (Time Stop): 12 saat geçtiyse ve kâr edemediyse zorla kapat.
        if trade_duration_minutes > 720 and current_profit < 0.01:
            return 'stale_trade_timeout'
            
        # Ekstrem Dönüş: Ciddi kârdayken momentum aniden bükülürse kaç
        if current_profit > 0.04 and last_candle['rsi'] > 75 and last_candle['rsi'] < dataframe['rsi'].iloc[-2]:
            return 'dynamic_momentum_exit'

        return None

    # === AKILLI DCA (HybridApex Mimarisi) ===
    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float, min_stake: float,
                              max_stake: float, current_entry_rate: float, current_exit_rate: float,
                              current_entry_profit: float, current_exit_profit: float, 
                              **kwargs) -> Optional[float]:

        if current_profit > -0.025: # Sadece %2.5'ten fazla zarardayken kurtarma yap
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None
            
        last_candle = dataframe.iloc[-1].squeeze()
        filled_entries = trade.select_filled_orders(trade.entry_side)
        count_of_entries = len(filled_entries)

        if count_of_entries > self.max_entry_position_adjustment:
            return None

        # Şart 1: 1 Saatlik CMF pozitife dönmüş mü? (Para Girişi)
        cmf_1h = last_candle.get(f'cmf_{self.informative_timeframe}', 0)
        # Şart 2: 1 Saatlik RSI dibe vurmuş mu?
        rsi_1h = last_candle.get(f'rsi_{self.informative_timeframe}', 50)
        # Şart 3: 5 Dakikalıkta fiyat VWAP alt bandından destek buluyor mu?
        vwap_low = last_candle.get('vwap_low', 0)

        # Fiyat ucuzsa VE para girişi başladıysa DCA tetikle
        if (current_rate < vwap_low) and (cmf_1h > 0) and (rsi_1h < 40):
            try:
                # DCA Multiplier ile kademeli olarak artan yatırım
                stake_amount = filled_entries[0].cost * (self.max_dca_multiplier ** count_of_entries)
                logger.info(f"V4 Smart DCA! {trade.pair} | Giris: {count_of_entries} | 1H CMF: {cmf_1h:.3f}")
                return min(stake_amount, max_stake)
            except Exception as e:
                logger.warning(f"DCA hata: {e}")
                return None

        return None