# Ichimoku Cloud based strategy - Modernized 2024 version
# High frequency 5m trading with NASOS-style dynamic stoploss

from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from pandas import DataFrame
import talib.abstract as ta
import pandas as pd
import numpy as np
from datetime import datetime
from functools import reduce


class IchiV1_Modern(IStrategy):
    INTERFACE_VERSION = 3
    timeframe = '5m'

    buy_params = {
        "buy_rsi": 45,
        "buy_rsi_fast": 30,
        "buy_adx": 25,
        "buy_fan_threshold": 1.002,
        "buy_ema_diff": 0.98,
    }

    sell_params = {
        "sell_rsi_exit": 65,
    }

    minimal_roi = {
        "0": 0.05,
        "15": 0.025,
        "45": 0.01,
        "120": 0,
    }

    stoploss = -0.02
    use_custom_stoploss = True

    trailing_stop = False

    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = False

    process_only_new_candles = True
    startup_candle_count = 200

    buy_rsi = IntParameter(30, 60, default=45, space='buy')
    buy_rsi_fast = IntParameter(20, 40, default=30, space='buy')
    buy_adx = DecimalParameter(15, 40, default=25, space='buy')
    sell_rsi_exit = IntParameter(55, 80, default=65, space='sell')

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)
        
        dataframe['adx'] = ta.ADX(dataframe)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe)
        
        for period in [9, 20, 50, 100, 200]:
            dataframe[f'ema_{period}'] = ta.EMA(dataframe, timeperiod=period)
        
        for period in [20, 50, 200]:
            dataframe[f'sma_{period}'] = ta.SMA(dataframe, timeperiod=period)
        
        typical_price = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        dataframe['vwap'] = (typical_price * dataframe['volume']).rolling(window=20).sum() / dataframe['volume'].rolling(window=20).sum()
        
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        
        dataframe['macd'], dataframe['macd_signal'], dataframe['macd_hist'] = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        
        dataframe['tenkan_sen'] = (dataframe['high'].rolling(window=9).max() + dataframe['low'].rolling(window=9).min()) / 2
        dataframe['kijun_sen'] = (dataframe['high'].rolling(window=26).max() + dataframe['low'].rolling(window=26).min()) / 2
        dataframe['senkou_a'] = ((dataframe['tenkan_sen'] + dataframe['kijun_sen']) / 2).shift(26)
        dataframe['senkou_b'] = ((dataframe['high'].rolling(window=52).max() + dataframe['low'].rolling(window=52).min()) / 2).shift(26)
        dataframe['cloud_green'] = dataframe['senkou_a'] > dataframe['senkou_b']
        
        dataframe['ema_8h_equiv'] = ta.EMA(dataframe, timeperiod=8)
        dataframe['ema_40h_equiv'] = ta.EMA(dataframe, timeperiod=40)
        dataframe['fan_magnitude'] = dataframe['ema_8h_equiv'] / dataframe['ema_40h_equiv']
        dataframe['fan_magnitude_gain'] = dataframe['fan_magnitude'] / dataframe['fan_magnitude'].shift(1)
        
        dataframe['trend_up'] = dataframe['close'] > dataframe['ema_50']
        
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        dataframe['volume_ok'] = dataframe['volume'] > dataframe['volume_ma'] * 0.5
        
        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []
        
        conditions.append(
            (dataframe['rsi'] < self.buy_rsi.value) &
            (dataframe['rsi_fast'] < self.buy_rsi_fast.value) &
            (dataframe['rsi'] > dataframe['rsi'].shift(1))
        )
        
        conditions.append(
            (dataframe['adx'] > self.buy_adx.value) &
            (dataframe['plus_di'] > dataframe['minus_di']) &
            (dataframe['rsi'] < 60) &
            (dataframe['volume_ok'])
        )
        
        conditions.append(
            (dataframe['macd'] > dataframe['macd_signal']) &
            (dataframe['macd'].shift(1) <= dataframe['macd_signal'].shift(1)) &
            (dataframe['rsi'] < 50) &
            (dataframe['volume_ok'])
        )
        
        conditions.append(
            (dataframe['fan_magnitude_gain'] >= 1.002) &
            (dataframe['fan_magnitude'] > 1) &
            (dataframe['close'] > dataframe['vwap'])
        )
        
        conditions.append(
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b']) &
            (dataframe['cloud_green']) &
            (dataframe['trend_up'])
        )
        
        conditions.append(
            (dataframe['ema_9'] > dataframe['ema_20']) &
            (dataframe['ema_9'].shift(1) <= dataframe['ema_20'].shift(1)) &
            (dataframe['close'] > dataframe['ema_9'] * 0.98)
        )
        
        if conditions:
            dataframe.loc[reduce(lambda x, y: x | y, conditions), 'buy'] = 1
        
        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []
        
        conditions.append(
            (dataframe['rsi'] > self.sell_rsi_exit.value) &
            (dataframe['rsi'] < dataframe['rsi'].shift(1))
        )
        
        conditions.append(
            (dataframe['close'] > dataframe['open'] * 1.05) &
            (dataframe['rsi'] > 70)
        )
        
        conditions.append(
            (dataframe['macd'] < dataframe['macd_signal']) &
            (dataframe['macd'].shift(1) >= dataframe['macd_signal'].shift(1))
        )
        
        conditions.append(
            (dataframe['adx'] < 20) &
            (dataframe['minus_di'] > dataframe['plus_di'])
        )
        
        if conditions:
            dataframe.loc[reduce(lambda x, y: x | y, conditions), 'sell'] = 1
        
        return dataframe

    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        if current_profit < -0.08:
            return 0.002
        if current_profit < -0.05:
            return 0.01
        if current_profit < -0.03:
            return 0.02
        if current_profit > 0.25:
            return 0.05
        if current_profit > 0.15:
            return 0.03
        if current_profit > 0.08:
            return 0.02
        if current_profit > 0.04:
            return 0.015
        if current_profit > 0.02:
            return 0.01
        return 0.02

    def confirm_trade_exit(self, pair: str, trade: 'Trade', order_type: str, amount: float,
                           rate: float, time_in_force: str, sell_reason: str,
                           current_time: datetime, **kwargs) -> bool:
        return True