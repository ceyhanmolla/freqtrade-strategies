# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
from datetime import datetime
from typing import Optional
import numpy as np
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter, CategoricalParameter
from freqtrade.persistence import Trade


def calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26):
    """Ichimoku Cloud - Tam kapsamlı hesaplama"""
    df = dataframe.copy()
    
    # Tenkan-sen
    df['tenkan_sen'] = (df['high'].rolling(window=conversion).max() + df['low'].rolling(window=conversion).min()) / 2
    
    # Kijun-sen
    df['kijun_sen'] = (df['high'].rolling(window=base).max() + df['low'].rolling(window=base).min()) / 2
    
    # Senkou Span A
    df['senkou_span_a'] = ((df['tenkan_sen'] + df['kijun_sen']) / 2).shift(displacement)
    
    # Senkou Span B
    df['senkou_span_b'] = ((df['high'].rolling(window=span).max() + df['low'].rolling(window=span).min()) / 2).shift(displacement)
    
    # Chikou Span
    df['chikou_span'] = df['close'].shift(-displacement)
    
    # Cloud Thickness
    df['cloud_thickness'] = abs(df['senkou_span_a'] - df['senkou_span_b'])
    df['cloud_thickness_pct'] = df['cloud_thickness'] / df['close'] * 100
    
    # TK Cross
    df['tk_cross'] = 0
    df.loc[df['tenkan_sen'] > df['kijun_sen'], 'tk_cross'] = 1
    df.loc[df['tenkan_sen'] < df['kijun_sen'], 'tk_cross'] = -1
    
    df['tk_cross_bullish'] = (df['tenkan_sen'] > df['kijun_sen']) & (df['tenkan_sen'].shift(1) <= df['kijun_sen'].shift(1))
    df['tk_cross_bearish'] = (df['tenkan_sen'] < df['kijun_sen']) & (df['tenkan_sen'].shift(1) >= df['kijun_sen'].shift(1))
    
    # Chikou confirmation
    df['chikou_above'] = df['chikou_span'] > df['close'].shift(displacement)
    df['chikou_below'] = df['chikou_span'] < df['close'].shift(displacement)
    
    return df


class IchiFan1m(IStrategy):
    """Ichimoku ve EMA Fan stratejisi - Orijinal Parametreler"""
    INTERFACE_VERSION = 3

    timeframe = '5m'
    startup_candle_count = 120

    # Stoploss
    stoploss = -0.10

    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    # ROI (Orijinal)
    minimal_roi = {
        "0": 0.03,
        "30": 0.015,
        "60": 0.01,
        "180": 0
    }

    # ROC Parametreleri (5m için - daha fazla sinyal için periyot 8)
    # 5m * 8 = 40 dk = yaklaşık 1 saatlik momentum
    buy_roc_period = IntParameter(5, 15, default=8, space='buy', optimize=False)
    buy_roc_threshold = DecimalParameter(0.0, 0.015, default=0.002, space='buy', optimize=False)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # === ICHIMOKU CLOUD ===
        ichimoku = calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26)
        
        dataframe['tenkan_sen'] = ichimoku['tenkan_sen']
        dataframe['kijun_sen'] = ichimoku['kijun_sen']
        dataframe['senkou_span_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_span_b'] = ichimoku['senkou_span_b']
        dataframe['senkou_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_b'] = ichimoku['senkou_span_b']
        dataframe['chikou_span'] = ichimoku['chikou_span']
        dataframe['chikou_above'] = ichimoku['chikou_above']
        dataframe['tk_cross'] = ichimoku['tk_cross']
        dataframe['tk_cross_bullish'] = ichimoku['tk_cross_bullish']
        
        # === ROC (Rate of Change) - YENİ YAKLAŞIM ===
        # Basit momentum: (close - close_n) / close_n
        roc_period = self.buy_roc_period.value
        
        dataframe['roc'] = (dataframe['close'] - dataframe['close'].shift(roc_period)) / dataframe['close'].shift(roc_period)
        
        # ROC Gain (momentum değişimi)
        dataframe['roc_gain'] = dataframe['roc'] - dataframe['roc'].shift(1)
        
        # ROC Pozitif (yükseliş momentum)
        dataframe['roc_positive'] = dataframe['roc'] > self.buy_roc_threshold.value
        
        # ROC Artan (momentum hızlanıyor)
        dataframe['roc_rising'] = dataframe['roc_gain'] > 0
        
        # === PIVOT POINTS ===
        pivot = (dataframe['high'].shift(1) + dataframe['low'].shift(1) + dataframe['close'].shift(1)) / 3
        dataframe['pivot'] = pivot
        dataframe['r1'] = 2 * pivot - dataframe['low'].shift(1)
        
        dataframe['price_above_pivot'] = dataframe['close'] > dataframe['pivot']
        dataframe['price_above_r1'] = dataframe['close'] > dataframe['r1']
        
        # Volume
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # === ICHIMOKU TREND (Zorunlu) ===
        ichimoku_bullish = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b'])
        )
        
        # === ROC MOMENTUM ===
        # ROC pozitif + artan = güçlü momentum
        roc_momentum = dataframe['roc_positive'] & dataframe['roc_rising']
        
        # Sadece ROC pozitif (daha fazla sinyal)
        roc_ok = dataframe['roc_positive']
        
        # === GİRİŞ 1: Ichimoku + ROC Güçlü + Pivot R1 ===
        entry1 = ichimoku_bullish & roc_momentum & dataframe['price_above_r1'] & (dataframe['volume'] > 0)
        dataframe.loc[entry1, 'enter_long'] = 1
        dataframe.loc[entry1, 'enter_tag'] = 'ichifan_roc_strong'
        
        # === GİRİŞ 2: Ichimoku + ROC + Pivot ===
        entry2 = ichimoku_bullish & roc_ok & dataframe['price_above_pivot'] & (dataframe['volume'] > 0)
        dataframe.loc[entry2 & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[entry2 & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichifan_roc'
        
        # === GİRİŞ 3: Ichimoku + ROC (Pivot yok) ===
        entry3 = ichimoku_bullish & roc_ok & (dataframe['volume'] > 0)
        dataframe.loc[entry3 & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[entry3 & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichifan_roc_basic'
        
        # === FALLBACK: Sadece Ichimoku ===
        entry4 = ichimoku_bullish & (dataframe['volume'] > 0)
        dataframe.loc[entry4 & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[entry4 & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichimoku_bullish'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe