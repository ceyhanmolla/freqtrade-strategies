"""
EVX_Tactical_Strategy_V2 - Debug Edilmiş Versiyon
================================================

Yapılan değişiklikler:
- Koşullar gevşetildi (debug amaçlı)
- EVX eşiği 0.1 -> 0.0
- det_buy > 0 yerine EVX > 0 yeterli
- Volume filtreleri kaldırıldı

Author: OpenCode Assistant
Date: 2026-05-05
"""

import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy

class EVX_Tactical_Strategy_V2(IStrategy):

    INTERFACE_VERSION = 2

    timeframe = '15m'
    startup_candle_count = 50

    minimal_roi = {
        "0": 0.10,
        "120": 0.05,
        "240": 0.02,
        "480": 0
    }

    stoploss = -0.074

    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Buy Pressure
        high_low_diff = dataframe['high'] - dataframe['low']
        high_low_diff = high_low_diff.replace(0, np.nan)

        buy_pressure = (dataframe['close'] - dataframe['low']) / high_low_diff
        buy_pressure = buy_pressure.fillna(0.5)

        # Bid/Ask Volumes
        dataframe['B'] = dataframe['volume'] * buy_pressure
        dataframe['A'] = dataframe['volume'] - dataframe['B']

        # EVX
        safe_A = dataframe['A'].replace(0, np.nan)
        dataframe['EVX'] = (dataframe['B'] - safe_A) / safe_A
        dataframe['EVX'] = dataframe['EVX'].fillna(0)

        # Matrix Determinants
        dataframe['det_buy'] = (dataframe['A'] * dataframe['open']) - (dataframe['B'] * dataframe['close'])
        dataframe['det_sell'] = (dataframe['A'] * dataframe['close']) - (dataframe['B'] * dataframe['open'])

        # Debug: Her koşulun ne sıklıkla sağlandığını görmek için
        dataframe['cond1'] = (dataframe['det_buy'] > 0)
        dataframe['cond2'] = (dataframe['EVX'] > 0)
        dataframe['cond_both'] = dataframe['cond1'] & dataframe['cond2']

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # GEVŞETİLMİŞ KOŞULLAR - Debug amaçlı
        dataframe['enter_long'] = 0

        # Sadece EVX > 0 yeterli (det_buy kaldırıldı)
        dataframe.loc[
            (dataframe['EVX'] > 0) &
            (dataframe['volume'] > 0),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0

        dataframe.loc[
            (dataframe['EVX'] < -0.02) &
            (dataframe['volume'] > 0),
            'exit_long'] = 1

        return dataframe