# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
from datetime import datetime
from typing import Optional
import numpy as np
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from freqtrade.persistence import Trade


def calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26):
    """Ichimoku Cloud - Tam kapsamlı hesaplama"""
    df = dataframe.copy()
    
    df['tenkan_sen'] = (df['high'].rolling(window=conversion).max() + df['low'].rolling(window=conversion).min()) / 2
    df['kijun_sen'] = (df['high'].rolling(window=base).max() + df['low'].rolling(window=base).min()) / 2
    df['senkou_span_a'] = ((df['tenkan_sen'] + df['kijun_sen']) / 2).shift(displacement)
    df['senkou_span_b'] = ((df['high'].rolling(window=span).max() + df['low'].rolling(window=span).min()) / 2).shift(displacement)
    df['chikou_span'] = df['close'].shift(-displacement)
    
    df['tk_cross'] = 0
    df.loc[df['tenkan_sen'] > df['kijun_sen'], 'tk_cross'] = 1
    df.loc[df['tenkan_sen'] < df['kijun_sen'], 'tk_cross'] = -1
    df['tk_cross_bullish'] = (df['tenkan_sen'] > df['kijun_sen']) & (df['tenkan_sen'].shift(1) <= df['kijun_sen'].shift(1))
    
    df['chikou_above'] = df['chikou_span'] > df['close'].shift(displacement)
    
    return df


class IchiFan1m(IStrategy):
    """Ichimoku + EMA Fan Stratejisi"""
    INTERFACE_VERSION = 3

    timeframe = '5m'
    startup_candle_count = 120

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    minimal_roi = {
        "0": 0.03,
        "30": 0.015,
        "60": 0.01,
        "180": 0
    }

    # EMA Fan Parametreleri
    buy_fan_magnitude_gain = DecimalParameter(0.00000, 0.00005, default=0.00001, space='buy', optimize=False)
    buy_fan_magnitude = DecimalParameter(-0.00100, 0.00100, default=-0.00057, space='buy', optimize=False)
    buy_ema_96_diff = DecimalParameter(0.00000, 0.00100, default=0.00057, space='buy', optimize=False)
    buy_ema_open_48_diff = DecimalParameter(-0.00050, 0.00050, default=-0.00001, space='buy', optimize=False)
    buy_fan_magnitude_shift_value = IntParameter(1, 5, default=1, space='buy', optimize=False)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA Serileri
        for period in [12, 24, 48, 96]:
            dataframe[f'ema_close_{period}'] = ta.EMA(dataframe, timeperiod=period)
        
        dataframe['ema_open_48'] = ta.EMA(dataframe['open'], timeperiod=48)
        
        # Ichimoku Cloud
        ichimoku = calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26)
        
        dataframe['tenkan_sen'] = ichimoku['tenkan_sen']
        dataframe['kijun_sen'] = ichimoku['kijun_sen']
        dataframe['senkou_span_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_span_b'] = ichimoku['senkou_span_b']
        dataframe['senkou_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_b'] = ichimoku['senkou_span_b']
        dataframe['chikou_span'] = ichimoku['chikou_span']
        dataframe['chikou_above'] = ichimoku['chikou_above']
        dataframe['tk_cross'] = ichimoku['tk_cross']
        dataframe['tk_cross_bullish'] = ichimoku['tk_cross_bullish']
        
        # EMA Fan Magnitude
        dataframe['fan_magnitude'] = (dataframe['ema_close_12'] - dataframe['ema_close_96']) / dataframe['ema_close_96']
        
        shift_val = self.buy_fan_magnitude_shift_value.value
        dataframe['fan_magnitude_gain'] = dataframe['fan_magnitude'] - dataframe['fan_magnitude'].shift(shift_val)
        
        dataframe['ema_96_diff'] = (dataframe['close'] - dataframe['ema_close_96']) / dataframe['ema_close_96']
        dataframe['ema_open_48_diff'] = (dataframe['close'] - dataframe['ema_open_48']) / dataframe['ema_open_48']
        
        # Volume
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # Ichimoku Trend Filter
        ichimoku_bullish = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b'])
        )
        
        # EMA Fan Momentum
        fan_momentum = (
            (dataframe['fan_magnitude_gain'] >= self.buy_fan_magnitude_gain.value) &
            (dataframe['fan_magnitude'] >= self.buy_fan_magnitude.value) &
            (dataframe['ema_96_diff'] >= self.buy_ema_96_diff.value) &
            (dataframe['ema_open_48_diff'] >= self.buy_ema_open_48_diff.value)
        )
        
        # Tam Giriş (Ichimoku + Fan Momentum)
        entry1 = ichimoku_bullish & fan_momentum & (dataframe['volume'] > 0)
        dataframe.loc[entry1, 'enter_long'] = 1
        dataframe.loc[entry1, 'enter_tag'] = 'ichifan_full'
        
        # Fallback (Sadece Ichimoku bullish)
        entry2 = ichimoku_bullish & (dataframe['volume'] > 0)
        dataframe.loc[entry2 & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[entry2 & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichimoku_bullish'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe