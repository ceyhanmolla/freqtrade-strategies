import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional

from freqtrade.strategy import (IStrategy, IntParameter, DecimalParameter,
                                merge_informative_pair, stoploss_from_open)
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

logger = logging.getLogger(__name__)


def chaikin_money_flow(dataframe, n=20):
    mfv = ((dataframe['close'] - dataframe['low']) - (dataframe['high'] - dataframe['close'])) / (dataframe['high'] - dataframe['low'])
    mfv = mfv.fillna(0.0)
    mfv *= dataframe['volume']
    cmf = (mfv.rolling(n, min_periods=0).sum() / dataframe['volume'].rolling(n, min_periods=0).sum())
    return pd.Series(cmf, name='cmf')


def VWAPB(dataframe, window_size=20, num_of_std=1):
    df = dataframe.copy()
    df['vwap'] = qtpylib.rolling_vwap(df, window=window_size)
    rolling_std = df['vwap'].rolling(window=window_size).std()
    df['vwap_low'] = df['vwap'] - (rolling_std * num_of_std)
    return df['vwap_low']


class AdaptiveApexV5(IStrategy):
    INTERFACE_VERSION = 3
    
    timeframe = '5m'
    informative_timeframe = '1h'
    
    # --- AM Sniper Giriş Parametreleri ---
    buy_adx = IntParameter(20, 40, default=25, space="buy")
    buy_rsi_base = IntParameter(25, 45, default=35, space="buy")
    
    # --- Anti-Pump ---
    anti_pump_threshold = DecimalParameter(1.10, 1.30, default=1.15, space='buy')
    
    # --- V3 Akıllı DCA ---
    position_adjustment_enable = True
    max_entry_position_adjustment = 3
    max_dca_multiplier = 1.5
    
    # --- NASOS Dinamik Stoploss ---
    use_custom_stoploss = True
    pHSL = DecimalParameter(-0.15, -0.05, default=-0.10, space='sell')
    pPF_1 = DecimalParameter(0.01, 0.025, default=0.016, space='sell')
    pSL_1 = DecimalParameter(0.01, 0.02, default=0.014, space='sell')
    pPF_2 = DecimalParameter(0.04, 0.08, default=0.050, space='sell')
    pSL_2 = DecimalParameter(0.02, 0.05, default=0.030, space='sell')
    
    # --- ROI ---
    minimal_roi = {
        "0": 0.04,
        "30": 0.025,
        "60": 0.015,
        "180": 0
    }
    
    stoploss = -0.10
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True
    
    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        return [(pair, self.informative_timeframe) for pair in pairs]
    
    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # --- 1H INFORMATIVE ---
        inf_tf = self.informative_timeframe
        informative = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe=inf_tf)
        
        informative['cmf'] = chaikin_money_flow(informative, 20)
        informative['rsi'] = ta.RSI(informative, timeperiod=14)
        
        informative['rolling_max_24'] = informative['high'].rolling(24).max()
        informative['rolling_min_24'] = informative['low'].rolling(24).min()
        informative['pump_ratio'] = informative['rolling_max_24'] / informative['rolling_min_24']
        informative['safe_pump'] = informative['pump_ratio'] < self.anti_pump_threshold.value
        
        dataframe = merge_informative_pair(dataframe, informative, self.timeframe, inf_tf, ffill=True)
        
        # --- 5M GÖSTERGELER (AM Mantığı Entegre Edildi) ---
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_prev'] = dataframe['rsi'].shift(1) # RSI bükülme kontrolü için
        
        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14) # Yükseliş gücü
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14) # Düşüş gücü
        
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        
        # VWAP ve Bollinger Bandı (Kesin dönüş noktaları için)
        dataframe['vwap'] = qtpylib.rolling_vwap(dataframe, window=20)
        dataframe['vwap_low'] = VWAPB(dataframe, 20, 1)
        
        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_lower'] = bollinger['lowerband']
        
        dataframe['volume_sma'] = dataframe['volume'].rolling(window=20).mean()
        
        return dataframe
    
    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''
        
        # Dinamik RSI: Volatilite arttıkça eşiği aşağı çeker (AM'den alındı)
        volatility_factor = dataframe['atr'] / dataframe['close']
        dataframe['dynamic_rsi_threshold'] = np.maximum(20, self.buy_rsi_base.value - (volatility_factor * 10))
        
        # KUSURSUZ GİRİŞ (AdaptiveMomentum'un 5m versiyonu):
        # 1. Trend var (ADX > 25) ve trend YUKARI (plus_di > minus_di)
        # 2. Anlık bir geri çekilme yaşanmış (RSI aşırı satımda ve BB alt bandına inmiş)
        # 3. RSI boynunu yukarı bükmüş (rsi > rsi_prev)
        # 4. Saatlikte pump yememiş.
        dataframe.loc[
            (
                (dataframe['adx'] > self.buy_adx.value) &
                (dataframe['plus_di'] > dataframe['minus_di']) & 
                (dataframe['rsi'] < dataframe['dynamic_rsi_threshold']) &
                (dataframe['rsi'] > dataframe['rsi_prev']) & 
                (dataframe['close'] < dataframe['bb_lower'] * 1.02) & 
                (dataframe['close'] > dataframe['vwap'] * 0.990) & 
                (dataframe[f'safe_pump_{self.informative_timeframe}'] == True) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']
        ] = (1, 'am_sniper_dip')
        
        return dataframe
    
    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''
        
        # Momentum kaybı çıkışı (RSI 75 üstü ve boynunu bükmüşse)
        dataframe.loc[
            (
                (dataframe['rsi'] > 75) &
                (dataframe['rsi'] < dataframe['rsi'].shift(1)) &
                (dataframe['close'] > dataframe['ema_50']) &
                (dataframe['volume'] > 0)
            ),
            ['exit_long', 'exit_tag']
        ] = (1, 'rsi_momentum_exit')
        
        return dataframe
    
    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        HSL = self.pHSL.value
        PF_1 = self.pPF_1.value
        SL_1 = self.pSL_1.value
        PF_2 = self.pPF_2.value
        SL_2 = self.pSL_2.value
        
        if current_profit > PF_2:
            sl_profit = SL_2 + (current_profit - PF_2)
        elif current_profit > PF_1:
            sl_profit = SL_1 + ((current_profit - PF_1) * (SL_2 - SL_1) / (PF_2 - PF_1))
        else:
            sl_profit = HSL
        
        if sl_profit >= current_profit:
            return -0.99
        
        return stoploss_from_open(sl_profit, current_profit)
    
    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float, min_stake: float,
                              max_stake: float, current_entry_rate: float, current_exit_rate: float,
                              current_entry_profit: float, current_exit_profit: float,
                              **kwargs) -> Optional[float]:
        if current_profit > -0.02:
            return None
        
        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None
        
        last_candle = dataframe.iloc[-1].squeeze()
        
        filled_entries = trade.select_filled_orders(trade.entry_side)
        count_of_entries = len(filled_entries)
        
        if count_of_entries > self.max_entry_position_adjustment:
            return None
        
        cmf_1h = last_candle.get(f'cmf_{self.informative_timeframe}', 0)
        rsi_1h = last_candle.get(f'rsi_{self.informative_timeframe}', 50)
        vwap_low = last_candle.get('vwap_low', 0)
        
        # Sadece dipten ve para girişi varsa kurtarma yap
        if (current_rate < vwap_low) and (cmf_1h > 0) and (rsi_1h < 40):
            try:
                stake_amount = filled_entries[0].cost * (self.max_dca_multiplier ** count_of_entries)
                logger.info(f"V5 DCA Tetiklendi: {trade.pair} | Giris: {count_of_entries}")
                return min(stake_amount, max_stake)
            except Exception as e:
                logger.warning(f"DCA Hatasi: {e}")
                return None
        
        return None