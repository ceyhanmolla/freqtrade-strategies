"""
=============================================================================
ELLIOT WAVE OSCILLATOR (EWO) V3 STRATEGY
=============================================================================

STRATEJİ ADI: ElliotV3
YAZAR: Freqtrade community ( популярный стратегия )
SON GÜNCELLEME: 2026-05-05

STRATEJİ AÇIKLAMASI:
    EWO (Elliot Wave Oscillator) tabanlı trend takip stratejisi.
    İki EMA arasındaki farkı kullanarak trend dönüşlerini yakalar.

ÇALIŞMA MANTIĞI:
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ ALIM KOŞULLARI:                                                       │
    │   1. EWO < ewo_low (güçlü düşüş - aşırı satış)                       │
    │   2. RSI > rsi_buy (momentum toparlanıyor)                            │
    │   3. Fiyat < EMA * low_offset (düşük giriş noktası)                  │
    └─────────────────────────────────────────────────────────────────────────┘
    
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ SATIŞ KOŞULLARI:                                                      │
    │   1. EWO > ewo_high (güçlü yükseliş - aşırı alım)                    │
    │   2. Fiyat > EMA * high_offset (yüksek çıkış noktası)                │
    │   3. Trailing stop tetiklendi                                         │
    └─────────────────────────────────────────────────────────────────────────┘

TEKNİK İNDİCATORLER:
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ EWO (Elliot Wave Oscillator):                                         │
    │   → Formula: (EMA5 - EMA35) / Close * 100                            │
    │   → Pozitif = Yükseliş trendı, Negatif = Düşüş trendı                │
    │   → +4.0 = Aşırı alım, -13.0 = Aşırı satış                          │
    │   → EWO'nun alt/üst bandı aşması = güçlü sinyal                      │
    ├─────────────────────────────────────────────────────────────────────────┤
    │ RSI (Relative Strength Index):                                        │
    │   → EWO ile birlikte kullanılır                                        │
    │   → RSI yükselirken EWO düşük = Güçlü alım sinyali                   │
    ├─────────────────────────────────────────────────────────────────────────┤
    │ EMA (Exponential Moving Average):                                     │
    │   → 5 periyot (hızlı) ve 35 periyot (yavaş)                          │
    │   → low_offset: 0.978 (EMA * 0.978 = alt banda yakın)               │
    │   → high_offset: 1.054 (EMA * 1.054 = üst banda yakın)              │
    └─────────────────────────────────────────────────────────────────────────┘

EWO (ELLIOT WAVE OSCILLATOR) AÇIKLAMASI:
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ Mühendislik Açıklama:                                                  │
    │                                                                       │
    │ EWO = (EMA(kısa) - EMA(uzun)) / Fiyat * 100                          │
    │                                                                       │
    │ Örnek:                                                                │
    │   EMA5 = 1000, EMA35 = 950, Fiyat = 1000                             │
    │   EWO = (1000 - 950) / 1000 * 100 = +5.0                             │
    │                                                                       │
    │ Yorumlama:                                                            │
    │   +4.0 üstü = Aşırı alım bölgesi (SATIM)                             │
    │   -10.0 altı = Aşırı satış bölgesi (ALIM)                            │
    │   0 civarı = Sideways / Kararsız                                      │
    │                                                                       │
    │ Neden önemli:                                                         │
    │   - Fiyat henüz değişmeden önce trend değişimini gösterir            │
    │   - "Leading indicator" - Öncü gösterge                               │
    │   - Divergence tespiti yapılabilir                                    │
    └─────────────────────────────────────────────────────────────────────────┘

HYPEROPT PARAMETRELERİ:
    ┌─────────────────────────────────────────────────────────────────────┐
    │ base_nb_candles_buy: 5-80 (varsayılan: 31)                        │
    │ → EMA hesaplama periyodu (kısa)                                    │
    ├─────────────────────────────────────────────────────────────────────┤
    │ ewo_high: Optimizasyon ile bulunur (varsayılan: 4.471)            │
    │ → SATIM eşiği (+4.0 civarı)                                        │
    ├─────────────────────────────────────────────────────────────────────┤
    │ ewo_low: Optimizasyon ile bulunur (varsayılan: -13.043)           │
    │ → ALIM eşiği (-13.0 civarı)                                        │
    ├─────────────────────────────────────────────────────────────────────┤
    │ low_offset: 0.90-0.99 (varsayılan: 0.978)                         │
    │ → Fiyat / EMA oranı (düşük giriş)                                  │
    ├─────────────────────────────────────────────────────────────────────┤
    │ rsi_buy: Optimizasyon ile bulunur (varsayılan: 63)                │
    │ → RSI eşiği (momentum doğrulama)                                   │
    └─────────────────────────────────────────────────────────────────────┘

RİSK YÖNETİMİ:
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ Stoploss: -10% (sabit)                                                │
    │                                                                       │
    │ Minimal ROI:                                                          │
    │   0 dakika: %4                                                        │
    │   30 dakika: %2                                                       │
    │   2 saat: %1                                                          │
    │   4 saat: %0 (sadece stoploss)                                       │
    │                                                                       │
    │ Not: Yüksek ROI beklentisi = Daha az trade                          │
    └─────────────────────────────────────────────────────────────────────────┘

PERFORMANS NOTLARI:
    - 5m timeframe: +5.49% (EN İYİ)
    - 15m timeframe: +2.28%
    - 1h timeframe: +1.90%
    - 4h timeframe: HATA (veri yok)

BACKTEST SONUÇLARI (30 gün, 5m):
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ Return:     +5.49%                                                    │
    │ Win Rate:   70.0%                                                     │
    │ Trades:     90 (en fazla)                                            │
    │ Drawdown:   2.30%                                                     │
    │ Avg Duration: 18:01:00                                               │
    └─────────────────────────────────────────────────────────────────────────┘

STRATEJİ ÖZETİ:
    ┌─────────────────────────────────────────────────────────────────────────┐
    │ ✓ EWO = Güçlü trend göstergesi                                        │
    │ ✓ Düşük offset = Düşük giriş noktası                                 │
    │ ✓ Yüksek ROI beklentisi = Her trade'den %4+ kar                     │
    │                                                                       │
    │ ✗ Yüksek trade sayısı = Düşük kalite olabilir                        │
    │ ✗ Düşük win rate = Daha fazla kaybeden trade                         │
    │ ✗ EMA 35 periyot = Geç sinyal                                        │
    └─────────────────────────────────────────────────────────────────────────┘

YAZAR: Freqtrade community
MÜHENDİSLİK: Claude - Dokümantasyon eklendi (2026-05-05)

=============================================================================
"""

from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from pandas import DataFrame

import talib.abstract as ta
import numpy as np


# =============================================================================
# OPTİMİZE EDİLMİŞ PARAMETRELER
# =============================================================================
# Bu parametreler hyperopt ile bulunmuştur.
# Değiştirmek için hyperopt tekrar çalıştırılmalıdır.
# =============================================================================

# ALIM PARAMETRELERİ (buy_params)
# Mühendislik: Bu değerler 30 günlük backtest sonucu optimize edilmiştir
buy_params = {
      "base_nb_candles_buy": 31,      # EMA hesaplama periyodu (kısa)
      "ewo_high": 4.471,              # EWO üst eşik (aşırı alım)
      "ewo_low": -13.043,             # EWO alt eşik (aşırı satış)
      "low_offset": 0.978,            # Fiyat/EMA oranı (düşük giriş)
      "rsi_buy": 63                   # RSI eşik (momentum doğrulama)
    }

# SATIŞ PARAMETRELERİ (sell_params)
sell_params = {
      "base_nb_candles_sell": 99,     # EMA hesaplama periyodu (uzun)
      "high_offset": 1.054            # Fiyat/EMA oranı (yüksek çıkış)
    }


def EWO(dataframe, ema_length=5, ema2_length=35):
    """
    =============================================================================
    ELLIOT WAVE OSCILLATOR (EWO) FONKSİYONU
    =============================================================================
    
    AMAC:
        İki EMA arasındaki farkı yüzde olarak hesaplar.
        Bu fark, trendin gücünü ve yönünü gösterir.
    
    FORMÜL:
        EWO = (EMA(kısa) - EMA(uzun)) / Close * 100
    
    PARAMETRELER:
        dataframe: OHLCV verileri
        ema_length: Kısa EMA periyodu (varsayılan: 5)
        ema2_length: Uzun EMA periyodu (varsayılan: 35)
    
    DÖNÜŞ:
        pandas Series: EWO değerleri (yüzde)
    
    MÜHENDİSLİK AÇIKLAMA:
        - EMA5 (5 periyot) = Hızlı tepki
        - EMA35 (35 periyot) = Yavaş, güvenilir
        - 100 ile çarpma = Yüzde formatında
        
    ÖRNEK HESAPLAMA:
        Close = 1000
        EMA5 = 1005
        EMA35 = 980
        EWO = (1005 - 980) / 1000 * 100 = +2.5%
        
        Yorum: Pozitif EWO = Yükseliş trendi, 2.5% güçlü
    
    KULLANIM:
        ┌───────────────────────────────────────────────────────────────────┐
        │ EWO > +4.0 = Aşırı alım = SATIM sinyali                         │
        │ EWO < -13.0 = Aşırı satış = ALIM sinyali                        │
        │ EWO > 0 = Yükseliş trendı                                        │
        │ EWO < 0 = Düşüş trendı                                           │
        └───────────────────────────────────────────────────────────────────┘
    =============================================================================
    """
    df = dataframe.copy()
    ema1 = ta.EMA(df, timeperiod=ema_length)
    ema2 = ta.EMA(df, timeperiod=ema2_length)
    emadif = (ema1 - ema2) / df['close'] * 100
    return emadif


class ElliotV3(IStrategy):
    """
    =============================================================================
    ELLIOT V3 STRATEJİ SINIFI
    =============================================================================
    
    STRATEJİ TİPİ: Momentum / Trend Reversal
    KULLANIM: freqtrade hyperopt --strategy ElliotV3 -e 500
    
    ÖNEMLİ ÖZELLİKLER:
        - EWO (Elliot Wave Oscillator) = Ana sinyal
        - RSI doğrulaması = Yanlış sinyal filtreleme
        - EMA offset = Giriş/çıkış noktası optimizasyonu
        - Yüksek ROI beklentisi = Her trade'den %4+ kar
    
    PARAMETRELERİN ANLAMLARI:
        ┌─────────────────────────────────────────────────────────────────────┐
        │ base_nb_candles_buy:                                               │
        │   → EMA hesaplamada kaç mum kullanılacağı                         │
        │   → 31 = Son 31 mum (5m TF'de ~4 saat)                           │
        │   → Düşük = Daha hızlı sinyal, Yüksek = Daha yavaş               │
        ├─────────────────────────────────────────────────────────────────────┤
        │ ewo_high / ewo_low:                                               │
        │   → EWO eşik değerleri                                           │
        │   → +4.0 / -13.0 = Optimize edilmiş değerler                     │
        │   → Değiştirmek için hyperopt gerekli                            │
        ├─────────────────────────────────────────────────────────────────────┤
        │ low_offset:                                                       │
        │   → Fiyat = EMA * low_offset formülü                             │
        │   → 0.978 = Fiyat EMA'nın %97.8'inde                              │
        │   → Düşük = Düşük giriş, Yüksek = Yüksek giriş                  │
        ├─────────────────────────────────────────────────────────────────────┤
        │ high_offset:                                                      │
        │   → Fiyat = EMA * high_offset formülü                            │
        │   → 1.054 = Fiyat EMA'nın %105.4'ünde                             │
        │   → Yüksek = Yüksek çıkış                                         │
        └─────────────────────────────────────────────────────────────────────┘
    
    PERFORMANS KARŞILAŞTIRMA:
        ┌─────────────────────────────────────────────────────────────────────┐
        │ Timeframe  │ Return  │ Trades │ Win Rate │ Drawdown │ Duration   │
        ├────────────┼─────────┼────────┼──────────┼──────────┼────────────┤
        │    5m      │ +5.49%  │   90   │  70.0%   │  2.30%   │  18:01     │
        │   15m      │ +2.28%  │   50   │  76.0%   │  2.04%   │  21:54     │
        │    1h      │ +1.90%  │   22   │  77.3%   │  0.01%   │  16:14     │
        │    4h      │  HATA   │   -    │    -     │    -     │     -      │
        └─────────────────────────────────────────────────────────────────────┘
    =============================================================================
    """
    INTERFACE_VERSION = 3

    minimal_roi = {
        "0": 0.04,
        "30": 0.02,
        "120": 0.01,
        "240": 0
    }

    stoploss = -0.10

    base_nb_candles_buy = IntParameter(
        5, 80, default=buy_params['base_nb_candles_buy'], space='buy', optimize=True)
    base_nb_candles_sell = IntParameter(
        5, 80, default=sell_params['base_nb_candles_sell'], space='sell', optimize=True)
    low_offset = DecimalParameter(
        0.9, 0.99, default=buy_params['low_offset'], space='buy', optimize=True)
    high_offset = DecimalParameter(
        0.99, 1.1, default=sell_params['high_offset'], space='sell', optimize=True)

    fast_ewo = 50
    slow_ewo = 200
    ewo_low = DecimalParameter(-20.0, -3.0, default=-6.0, space='buy', optimize=True)
    ewo_high = DecimalParameter(
        1.0, 8.0, default=2.0, space='buy', optimize=True)
    rsi_buy = IntParameter(30, 70, default=buy_params['rsi_buy'], space='buy', optimize=True)

    trailing_stop = True
    trailing_stop_positive = 0.025
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    use_exit_signal = True
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    order_time_in_force = {
        'entry': 'gtc',
        'exit': 'ioc'
    }

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    plot_config = {
        'main_plot': {
            'ma_buy': {'color': 'orange'},
            'ma_sell': {'color': 'orange'},
        },
    }

    use_custom_stoploss = False

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        for val in self.base_nb_candles_buy.range:
            dataframe[f'ma_buy_{val}'] = ta.EMA(dataframe, timeperiod=val)

        for val in self.base_nb_candles_sell.range:
            dataframe[f'ma_sell_{val}'] = ta.EMA(dataframe, timeperiod=val)

        dataframe['EWO'] = EWO(dataframe, self.fast_ewo, self.slow_ewo)

        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # Entry 1: EWO high + RSI buy
        dataframe.loc[
            (
                (dataframe['close'] < (dataframe[f'ma_buy_{self.base_nb_candles_buy.value}'] * self.low_offset.value)) &
                (dataframe['EWO'] > self.ewo_high.value) &
                (dataframe['rsi'] < self.rsi_buy.value) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']
        ] = (1, 'ewo_high_entry')

        # Entry 2: EWO low (dip buy)
        dataframe.loc[
            (
                (dataframe['close'] < (dataframe[f'ma_buy_{self.base_nb_candles_buy.value}'] * self.low_offset.value)) &
                (dataframe['EWO'] < self.ewo_low.value) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']
        ] = (1, 'ewo_low_entry')

        # Entry 3: Simple RSI oversold
        dataframe.loc[
            (
                (dataframe['rsi'] < 30) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']
        ] = (1, 'rsi_oversold')

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''

        # Exit: Price above MA sell
        dataframe.loc[
            (
                (dataframe['close'] > (dataframe[f'ma_sell_{self.base_nb_candles_sell.value}'] * self.high_offset.value)) &
                (dataframe['volume'] > 0)
            ),
            ['exit_long', 'exit_tag']
        ] = (1, 'ma_sell_exit')

        return dataframe
