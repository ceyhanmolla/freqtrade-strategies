# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
from datetime import datetime
from typing import Optional
import numpy as np
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter, CategoricalParameter
from freqtrade.persistence import Trade


def calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26):
    """Ichimoku Cloud - Tam kapsamlı hesaplama"""
    df = dataframe.copy()
    
    # Tenkan-sen
    df['tenkan_sen'] = (df['high'].rolling(window=conversion).max() + df['low'].rolling(window=conversion).min()) / 2
    
    # Kijun-sen
    df['kijun_sen'] = (df['high'].rolling(window=base).max() + df['low'].rolling(window=base).min()) / 2
    
    # Senkou Span A
    df['senkou_span_a'] = ((df['tenkan_sen'] + df['kijun_sen']) / 2).shift(displacement)
    
    # Senkou Span B
    df['senkou_span_b'] = ((df['high'].rolling(window=span).max() + df['low'].rolling(window=span).min()) / 2).shift(displacement)
    
    # Chikou Span
    df['chikou_span'] = df['close'].shift(-displacement)
    
    # Cloud Thickness
    df['cloud_thickness'] = abs(df['senkou_span_a'] - df['senkou_span_b'])
    df['cloud_thickness_pct'] = df['cloud_thickness'] / df['close'] * 100
    
    # TK Cross
    df['tk_cross'] = 0
    df.loc[df['tenkan_sen'] > df['kijun_sen'], 'tk_cross'] = 1
    df.loc[df['tenkan_sen'] < df['kijun_sen'], 'tk_cross'] = -1
    
    df['tk_cross_bullish'] = (df['tenkan_sen'] > df['kijun_sen']) & (df['tenkan_sen'].shift(1) <= df['kijun_sen'].shift(1))
    df['tk_cross_bearish'] = (df['tenkan_sen'] < df['kijun_sen']) & (df['tenkan_sen'].shift(1) >= df['kijun_sen'].shift(1))
    
    # Chikou confirmation
    df['chikou_above'] = df['chikou_span'] > df['close'].shift(displacement)
    df['chikou_below'] = df['chikou_span'] < df['close'].shift(displacement)
    
    return df


class IchiFan1m(IStrategy):
    """Ichimoku ve EMA Fan stratejisi - Orijinal Parametreler"""
    INTERFACE_VERSION = 3

    timeframe = '5m'
    startup_candle_count = 120

    # Stoploss
    stoploss = -0.10

    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    # ROI (Orijinal)
    minimal_roi = {
        "0": 0.03,
        "30": 0.015,
        "60": 0.01,
        "180": 0
    }

    # Buy Parametreleri (Yeni: MACD + RSI yaklaşımı)
    # MACD parametreleri (opsiyonel - sabit değerlerle test)
    buy_macd_rsi_enabled = CategoricalParameter([True, False], default=True, space='buy', optimize=False)
    
    # RSI threshold (aşırı satış seviyesi)
    buy_rsi_oversold = IntParameter(25, 45, default=40, space='buy', optimize=False)
    
    # RSI overbought filter (aşırı alım kontrolü)
    buy_rsi_overbought = IntParameter(65, 85, default=70, space='buy', optimize=False)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA Serileri
        for period in [12, 24, 48, 96]:
            dataframe[f'ema_close_{period}'] = ta.EMA(dataframe, timeperiod=period)
        
        dataframe['ema_open_48'] = ta.EMA(dataframe['open'], timeperiod=48)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # Ichimoku Cloud
        ichimoku = calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26)
        
        dataframe['tenkan_sen'] = ichimoku['tenkan_sen']
        dataframe['kijun_sen'] = ichimoku['kijun_sen']
        dataframe['senkou_span_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_span_b'] = ichimoku['senkou_span_b']
        dataframe['senkou_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_b'] = ichimoku['senkou_span_b']
        dataframe['chikou_span'] = ichimoku['chikou_span']
        dataframe['chikou_above'] = ichimoku['chikou_above']
        dataframe['cloud_thickness'] = ichimoku['cloud_thickness']
        dataframe['cloud_thickness_pct'] = ichimoku['cloud_thickness_pct']
        dataframe['tk_cross'] = ichimoku['tk_cross']
        dataframe['tk_cross_bullish'] = ichimoku['tk_cross_bullish']
        dataframe['tk_cross_bearish'] = ichimoku['tk_cross_bearish']
        
        # === MACD + RSI MOMENTUM (Yeni yaklaşım) ===
        # MACD (Trend momentum)
        macd = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        dataframe['macd'] = macd['macd']
        dataframe['macd_signal'] = macd['macdsignal']
        dataframe['macd_hist'] = macd['macdhist']
        
        # MACD crossover signals
        dataframe['macd_bullish'] = (dataframe['macd'] > dataframe['macd_signal']) & \
                                   (dataframe['macd'].shift(1) <= dataframe['macd_signal'].shift(1))
        dataframe['macd_bearish'] = (dataframe['macd'] < dataframe['macd_signal']) & \
                                   (dataframe['macd'].shift(1) >= dataframe['macd_signal'].shift(1))
        
        # RSI (Aşırı bölge filter)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_oversold'] = dataframe['rsi'] < 40
        dataframe['rsi_neutral'] = (dataframe['rsi'] >= 40) & (dataframe['rsi'] < 65)
        dataframe['rsi_overbought'] = dataframe['rsi'] > 70
        
        # Volume MA
        dataframe['volume_ma'] = dataframe['volume'].rolling(window=20).mean()
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # === ICHIMOKU TREND FİLTER ===
        ichimoku_bullish = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b'])
        )
        
        # === MACD + RSI MOMENTUM (Yeni yaklaşım) ===
        # MACD bullish histogram (momentum pozitif)
        macd_bullish = (dataframe['macd_hist'] > 0) & (dataframe['macd'] > dataframe['macd_signal'])
        
        # RSI not overbought (aşırı alım yok)
        rsi_ok = dataframe['rsi'] < 70
        
        # === TAM GIRIŞ (Ichimoku + MACD + RSI) ===
        entry1 = ichimoku_bullish & macd_bullish & rsi_ok & (dataframe['volume'] > 0)
        dataframe.loc[entry1, 'enter_long'] = 1
        dataframe.loc[entry1, 'enter_tag'] = 'ichifan_macd_rsi'
        
        # === FALLBACK (Sadece Ichimoku bullish) ===
        entry2 = ichimoku_bullish & (dataframe['volume'] > 0)
        dataframe.loc[entry2 & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[entry2 & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichimoku_bullish'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe