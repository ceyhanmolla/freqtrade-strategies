"""
EwoMomentumV2 - İyileştirilmiş EWO Momentum Strategy (V1 Düzeltmesi)
===================================================================

YAPILAN İYİLEŞTİRMELER (V1 -> V2):
1. Stoploss: -10% -> -7% (daha sıkı ama V1 gibi çok da değil)
2. Minimal ROI düşürüldü (daha erken kar realized)
3. EWO parametreleri KORUNANAN (50,200) SMA - orijinal V1 formülü

ÖNEMLİ NOT:
- V1'in başarısının sebebi EWO(50,200) SMA kombinasyonuydu
- Bu parametreler yavaş ama güvenilir sinyaller üretiyor
- EWO(5,35) EMA denenebilir ama farklı sonuçlar verebilir

Author: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame

import talib.abstract as ta
import numpy as np


def EWO(dataframe, ema_length=5, ema2_length=35):
    """Elliot Wave Oscillator - V1 ile aynı formül (SMA bazlı)"""
    df = dataframe.copy()
    # V1 ile AYNI: SMA kullanılıyor (EMA değil!)
    ema1 = ta.SMA(df, timeperiod=ema_length)
    ema2 = ta.SMA(df, timeperiod=ema2_length)
    emadif = (ema1 - ema2) / df['close'] * 100
    return emadif


class EwoMomentumV2(IStrategy):
    INTERFACE_VERSION = 2

    # İYİLEŞTİRME: Orta seviye ROI (V1 ile V2 arası)
    minimal_roi = {
        "0": 0.4,
        "30": 0.8,
        "60": 1.2,
        "180": 2.0,
    }

    # İYİLEŞTİRME: Daha sıkı stoploss (-10% -> -7%)
    stoploss = -0.07

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    use_exit_signal = False
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # V1 İLE AYNI: EWO(50,200) SMA
        dataframe['ema_17'] = ta.EMA(dataframe, timeperiod=17)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['EWO'] = EWO(dataframe, 50, 200)  # V1 ile AYNEN

        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Volume indicator
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['buy'] = 0

        # V1 İLE AYNI giriş koşulları
        buy_cond1 = (
            (dataframe['EWO'] > 0.5) &
            (dataframe['rsi'] < 55) &
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_sma'] * 3)
        )

        buy_cond2 = (
            (dataframe['EWO'] < -2.0) &
            (dataframe['rsi'] < 40) &
            (dataframe['volume'] > 0)
        )

        dataframe.loc[buy_cond1 | buy_cond2, 'buy'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0
        return dataframe