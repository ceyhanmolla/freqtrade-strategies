# --- EN: Freqtrade EVX Strategy Implementation ---
# --- TR: Freqtrade EVX Stratejisi Uygulaması ---

import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy

class EVX_Tactical_Strategy(IStrategy):
    """
    EVX (Excess Volume Index) Tabanlı Taktiksel Hacim Stratejisi

    Bu strateji, piyasadaki teklif/istek (bid/ask) hacim dengesizliklerini
    matris determinantları kullanarak analiz eder ve işlemlere sadece arzın
    tükendiği, talebin ise fiyata baskın geldiği anlarda girer.
    """

    # Interface version - Freqtrade V3 formatı için gerekli
    INTERFACE_VERSION = 3

    # Optimum zaman dilimi
    timeframe = '15m'

    # Yeterli veri olması için başlangıç mum sayısı
    startup_candle_count = 50
    
    # Minimum ROI (Yatırım Getirisi) Savunma Hattı
    minimal_roi = {
        "0": 0.15,    # İşleme girildiğinde %15 kâr hedefi
        "120": 0.05,  # 2 saat sonra %5 kâr yeterlidir
        "240": 0.02,  # 4 saat sonra %2 kârda çıkış yap
        "480": 0      # 8 saat sonra başa baş noktasında tahliye et
    }

    # Sermaye Koruması (Zarar Kes)
    stoploss = -0.074 # Beyaz bültende test edilen %7.4'lük tolerans seviyesi

    # Trailing Stop (Süren Stop) - Kârı kilitlemek için
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Adım 1: Göstergelerin ve EVX Metriklerinin Hesaplanması
        """
        # Hacim Ayrıştırma: Yüksek-Düşük farkı (Sıfıra bölünmeyi engellemek için nan ataması)
        high_low_diff = dataframe['high'] - dataframe['low']
        high_low_diff = high_low_diff.replace(0, np.nan)
        
        # Alım Basıncının (Buy Pressure) Tahmini
        buy_pressure = (dataframe['close'] - dataframe['low']) / high_low_diff
        buy_pressure = buy_pressure.fillna(0.5) # Mumda hareket yoksa hacmi eşit böl
        
        # Bids (B) ve Asks (A) Hacimlerinin Hesaplanması
        dataframe['B'] = dataframe['volume'] * buy_pressure
        dataframe['A'] = dataframe['volume'] - dataframe['B']
        
        # EVX (Excess Volume Index) Hesaplanması: (B - A) / A
        safe_A = dataframe['A'].replace(0, np.nan) # Asks hacmi 0 ise korumaya al
        dataframe['EVX'] = (dataframe['B'] - safe_A) / safe_A
        dataframe['EVX'] = dataframe['EVX'].fillna(0)
        
        # Alım Matrisi Determinantı: det[A, y; B, x] (y=close, x=open)
        # Formül: (A * open) - (B * close)
        dataframe['det_buy'] = (dataframe['A'] * dataframe['open']) - (dataframe['B'] * dataframe['close'])
        
        # Satım Matrisi Determinantı: det[A, x; B, y]
        # Formül: (A * close) - (B * open)
        dataframe['det_sell'] = (dataframe['A'] * dataframe['close']) - (dataframe['B'] * dataframe['open'])
        
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Adım 2: Taarruz (Alım) Koşullarının Belirlenmesi
        """
        dataframe.loc[
            (
                (dataframe['det_buy'] > 0) &      # Matris koşulu sağlandığında
                (dataframe['EVX'] > 0.1) &        # Bid hacmi, Ask hacminden en az %10 fazla olmalı
                (dataframe['volume'] > 0)         # İşlem hacmi sıfırdan büyük olmalı
            ),
            'enter_long'] = 1
            
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        """
        Adım 3: Savunma ve Geri Çekilme (Satım) Koşullarının Belirlenmesi
        """
        dataframe.loc[
(
                (dataframe['det_sell'] < 0) &     # DÜZELTİLDİ: Satış matrisinin doğru koşulu
                (dataframe['EVX'] < -0.02) &      # Satıcıların üstünlüğü (düşürüldü)
                (dataframe['volume'] > 0)
            ),
            'exit_long'] = 1
            
        return dataframe