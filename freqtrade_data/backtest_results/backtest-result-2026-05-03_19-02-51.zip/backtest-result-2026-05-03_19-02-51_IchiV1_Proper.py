# Ichimoku-based strategy - Properly rewritten
# Uses Freqtrade's native informative_pairs for true multi-timeframe analysis

from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from pandas import DataFrame
import talib.abstract as ta
import pandas as pd
import numpy as np
from datetime import datetime
from functools import reduce


class IchiV1_Proper(IStrategy):
    INTERFACE_VERSION = 3
    
    timeframe = '5m'
    inf_1h = '1h'
    inf_4h = '4h'
    
    minimal_roi = {
        "0": 0.04,
        "15": 0.025,
        "45": 0.01,
        "90": 0,
    }
    
    stoploss = -0.02
    use_custom_stoploss = True
    trailing_stop = False
    use_sell_signal = True
    sell_profit_only = True
    ignore_roi_if_buy_signal = False
    process_only_new_candles = True
    startup_candle_count = 400
    exit_timeout = 1440
    
    buy_rsi = IntParameter(30, 55, default=40, space='buy')
    buy_rsi_fast = IntParameter(15, 35, default=25, space='buy')
    buy_adx = DecimalParameter(20, 40, default=25, space='buy')
    sell_rsi = IntParameter(60, 80, default=70, space='sell')
    
    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        informative_pairs = [(pair, self.timeframe) for pair in pairs]
        informative_pairs += [(pair, self.inf_1h) for pair in pairs]
        informative_pairs += [(pair, self.inf_4h) for pair in pairs]
        return informative_pairs
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)
        dataframe['adx'] = ta.ADX(dataframe)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe)
        
        for period in [9, 20, 50, 200]:
            dataframe[f'ema_{period}'] = ta.EMA(dataframe, timeperiod=period)
        
        dataframe['sma_20'] = ta.SMA(dataframe, timeperiod=20)
        
        typical_price = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        dataframe['vwap'] = (typical_price * dataframe['volume']).rolling(20).sum() / dataframe['volume'].rolling(20).sum()
        
        dataframe['macd'], dataframe['macd_signal'], _ = ta.MACD(dataframe, fastperiod=12, slowperiod=26, signalperiod=9)
        
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        
        high9 = dataframe['high'].rolling(9).max()
        low9 = dataframe['low'].rolling(9).min()
        high26 = dataframe['high'].rolling(26).max()
        low26 = dataframe['low'].rolling(26).min()
        
        dataframe['tenkan_sen'] = (high9 + low9) / 2
        dataframe['kijun_sen'] = (high26 + low26) / 2
        
        senkou_a = ((dataframe['tenkan_sen'] + dataframe['kijun_sen']) / 2).shift(26)
        senkou_b = ((dataframe['high'].rolling(52).max() + dataframe['low'].rolling(52).min()) / 2).shift(26)
        dataframe['senkou_a'] = senkou_a
        dataframe['senkou_b'] = senkou_b
        dataframe['cloud_green'] = senkou_a > senkou_b
        
        dataframe['trend_up'] = dataframe['close'] > dataframe['ema_50']
        dataframe['ema9_above_ema20'] = dataframe['ema_9'] > dataframe['ema_20']
        dataframe['ema9_cross_above'] = (dataframe['ema_9'] > dataframe['ema_20']) & (dataframe['ema_9'].shift(1) <= dataframe['ema_20'].shift(1))
        
        dataframe['volume_ma'] = dataframe['volume'].rolling(20).mean()
        dataframe['volume_ok'] = dataframe['volume'] > dataframe['volume_ma'] * 0.3
        
        if 'rsi_1h' not in dataframe.columns:
            dataframe['rsi_1h'] = dataframe['rsi']
            dataframe['ema_50_1h'] = dataframe['ema_50']
            dataframe['close_1h'] = dataframe['close']
        
        if 'rsi_4h' not in dataframe.columns:
            dataframe['rsi_4h'] = dataframe['rsi']
            dataframe['ema_50_4h'] = dataframe['ema_50']
            dataframe['close_4h'] = dataframe['close']
        
        return dataframe
    
    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []
        
        cond1 = (
            (dataframe['rsi'] < self.buy_rsi.value) &
            (dataframe['rsi_fast'] < self.buy_rsi_fast.value) &
            (dataframe['rsi'] > dataframe['rsi'].shift(1)) &
            (dataframe['volume_ok'])
        )
        conditions.append(cond1)
        
        cond2 = (
            (dataframe['adx'] > self.buy_adx.value) &
            (dataframe['plus_di'] > dataframe['minus_di']) &
            (dataframe['rsi'] < 60) &
            (dataframe['volume_ok'])
        )
        conditions.append(cond2)
        
        cond3 = (
            (dataframe['macd'] > dataframe['macd_signal']) &
            (dataframe['macd'].shift(1) <= dataframe['macd_signal'].shift(1)) &
            (dataframe['rsi'] < 50) &
            (dataframe['volume_ok'])
        )
        conditions.append(cond3)
        
        cond4 = (
            (dataframe['ema9_cross_above']) &
            (dataframe['close'] > dataframe['ema_9']) &
            (dataframe['volume_ok'])
        )
        conditions.append(cond4)
        
        cond5 = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b']) &
            (dataframe['cloud_green']) &
            (dataframe['trend_up']) &
            (dataframe['volume_ok'])
        )
        conditions.append(cond5)
        
        cond6 = (
            (dataframe['close'] > dataframe['vwap']) &
            (dataframe['trend_up']) &
            (dataframe['ema9_above_ema20']) &
            (dataframe['volume_ok'])
        )
        conditions.append(cond6)
        
        if conditions:
            dataframe.loc[reduce(lambda x, y: x | y, conditions), 'buy'] = 1
        
        return dataframe
    
    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []
        
        cond1 = (
            (dataframe['rsi'] > self.sell_rsi.value) &
            (dataframe['rsi'] < dataframe['rsi'].shift(1))
        )
        conditions.append(cond1)
        
        cond2 = (
            (dataframe['macd'] < dataframe['macd_signal']) &
            (dataframe['macd'].shift(1) >= dataframe['macd_signal'].shift(1))
        )
        conditions.append(cond2)
        
        cond3 = (
            (dataframe['adx'] < 20) &
            (dataframe['minus_di'] > dataframe['plus_di'])
        )
        conditions.append(cond3)
        
        cond4 = (
            (dataframe['close'] < dataframe['vwap']) &
            (dataframe['close'] > dataframe['open'])
        )
        conditions.append(cond4)
        
        if conditions:
            dataframe.loc[reduce(lambda x, y: x | y, conditions), 'sell'] = 1
        
        return dataframe
    
    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        if current_profit < -0.03:
            return 0.001
        if current_profit < -0.015:
            return 0.01
        if current_profit < 0:
            return 0.015
        if current_profit > 0.15:
            return 0.04
        if current_profit > 0.08:
            return 0.025
        if current_profit > 0.04:
            return 0.015
        if current_profit > 0.02:
            return 0.01
        return self.stoploss
    
    def confirm_trade_exit(self, pair: str, trade: 'Trade', order_type: str, amount: float,
                           rate: float, time_in_force: str, sell_reason: str,
                           current_time: datetime, **kwargs) -> bool:
        return True