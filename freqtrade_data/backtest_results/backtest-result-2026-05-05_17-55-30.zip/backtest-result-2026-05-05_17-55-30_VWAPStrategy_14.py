import numpy as np
import pandas as pd
import talib.abstract as ta
from freqtrade.strategy import IStrategy
from freqtrade.persistence import Trade
from datetime import datetime


def calculate_vwap(df):
    typical_price = (df['high'] + df['low'] + df['close']) / 3
    vwap = (typical_price * df['volume']).rolling(window=1).sum() / df['volume'].rolling(window=1).sum()
    return vwap


class VWAPStrategy_14(IStrategy):

    INTERFACE_VERSION = 2

    timeframe = '5m'

    # Stepwise ROI - daha gerçekçi kar hedefleri
    minimal_roi = {
        "0": 0.5,    # 30 dakika → %0.5
        "30": 0.8,   # 1 saat → %0.8
        "60": 1.0,   # 2 saat → %1.0
        "180": 1.5,  # 3 saat → %1.5
        "360": 2.0,  # 6 saat → %2.0
        "720": 2.5,  # 12 saat → %2.5
    }

    stoploss = -0.10  # -20% yerine -10%

    use_custom_stoploss = True

    custom_info = {}

    exit_profit_only = True


    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime, current_rate: float, current_profit: float, after_fill: bool, **kwargs) -> float:

        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)

        last_candle = dataframe.iloc[-1].squeeze()

        if trade.id in self.custom_info:


                divided_current_profit = current_profit / 2
                if current_profit >= 0.01 and divided_current_profit > self.custom_info[trade.id]:


                        self.custom_info[trade.id] = divided_current_profit

                        return divided_current_profit
                else:


                    return self.custom_info[trade.id]            
        elif pd.notna(last_candle['ATR_stoploss']):

            self.custom_info[trade.id] = last_candle['ATR_stoploss']

            return last_candle['ATR_stoploss']
        else:

             return None

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:

        dataframe['date_copy'] = pd.to_datetime(dataframe['date'])
        dataframe['date_copy'] = dataframe['date_copy'].dt.tz_localize(None)
        dataframe.set_index('date_copy', inplace=True)

        # VWAP - calculate using typical price
        typical_price = (dataframe['high'] + dataframe['low'] + dataframe['close']) / 3
        cumsum_vol = dataframe['volume'].cumsum()
        cumsum_pv = (typical_price * dataframe['volume']).cumsum()
        dataframe['VWAP'] = cumsum_pv / cumsum_vol

        # ATR
        dataframe['ATR'] = ta.ATR(dataframe['high'], dataframe['low'], dataframe['close'], timeperiod=150)
        dataframe['ATR_stoploss'] = dataframe['close'] - dataframe['ATR'] * 3.5

        # EMA 200
        dataframe['ema200'] = ta.EMA(dataframe, timeperiod=200)

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe['close'], timeperiod=16)

        # Bollinger Bands (14 period, 2 std) - manual calculation
        sma = dataframe['close'].rolling(window=14).mean()
        std = dataframe['close'].rolling(window=14).std()
        dataframe['upper_band'] = sma + (std * 2.0)
        dataframe['middle_band'] = sma
        dataframe['lower_band'] = sma - (std * 2.0)

        # Reset index for VWAP_signal calculation
        dataframe.reset_index(inplace=True)

        # VWAP Signal
        VWAP_signal = [0] * len(dataframe)
        backcandles = 15

        for row in range(backcandles, len(dataframe)):

            up_trend = 1
            down_trend = 1

            for i in range(row - backcandles, row + 1):

                if max(dataframe['open'][i], dataframe['close'][i]) >= dataframe['VWAP'][i]:
                    down_trend = 0  # Set down_trend to 0

                if min(dataframe['open'][i], dataframe['close'][i]) <= dataframe['VWAP'][i]:
                    up_trend = 0  # Set up_trend to 0

            if up_trend == 1 and down_trend == 1:
                VWAP_signal[row] = 3  # Neutral signal
            elif up_trend == 1:

                VWAP_signal[row] = 2
            elif down_trend == 1:

                VWAP_signal[row] = 1

        dataframe['VWAP_signal'] = VWAP_signal

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:

        dataframe.loc[
            (
                (dataframe['volume'] > 0) &  # Buy when volume > 0
                (dataframe['VWAP_signal'] == 2) & # Buy when VWAP_signal is 2 (15 candles above VWAP line - indicating bullish trend)
                (dataframe['rsi'] < 45) & # Buy when rsi < 45
                (dataframe['close'] <= dataframe['lower_band']) & # Buy when the current closing price is less than or equal to the current lower bband
                (dataframe['close'].shift(1) <= dataframe['lower_band'].shift(1)) & # Buy when the previous closing price was less than or equal to the lower bband
                (dataframe['lower_band'] != dataframe['upper_band']) # Make sure lower and upper bband is not the same (no momentum)
            ),

            'buy'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:

        # Exit koşulları - daha yüksek RSI eşiği (daha fazla kar bekle)
        dataframe.loc[
            (
                (dataframe['volume'] > 0) &
                (dataframe['close'] >= dataframe['upper_band']) &
                (dataframe['rsi'] > 65) &  # 55 → 65 (daha az erken çıkış)
                (dataframe['lower_band'] != dataframe['upper_band'])
            ),

            'sell'
        ] = 1

        return dataframe
