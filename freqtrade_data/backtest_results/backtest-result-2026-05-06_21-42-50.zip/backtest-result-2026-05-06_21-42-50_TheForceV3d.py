"""
TheForceV3d - Çıkış Sinyalsiz Test
===================================
MÜHENDİSLİK TESTİ: Entry'lerin kalitesini izole ölçmek için
çıkış sinyalleri kapatıldı. Sadece stoploss + trailing stop + ROI ile çıkış.

Eğer bu bile kârlı değilse → sorun entry'lerde.
"""

import numpy as np
from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta


class TheForceV3d(IStrategy):

    INTERFACE_VERSION = 3

    minimal_roi = {"60": 0.01, "30": 0.005, "0": 0.003}

    stoploss = -0.03

    trailing_stop = True
    trailing_stop_positive = 0.008
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    timeframe = '15m'
    startup_candle_count = 50

    # ÇIKIŞ SİNYALİ KAPALI!
    use_exit_signal = False

    order_types = {
        'entry': 'limit',
        'exit': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }
    order_time_in_force = {'entry': 'GTC', 'exit': 'GTC'}

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        stoch_fast = ta.STOCHF(dataframe, 5, 3, 3)
        dataframe['fastd'] = stoch_fast['fastd']
        dataframe['fastk'] = stoch_fast['fastk']

        macd = ta.MACD(dataframe, 12, 26, 9)
        dataframe['macdhist'] = macd['macdhist']

        dataframe['ema5'] = ta.EMA(dataframe['close'], timeperiod=5)
        dataframe['ema20'] = ta.EMA(dataframe['close'], timeperiod=20)
        dataframe['ema5o'] = ta.EMA(dataframe['open'], timeperiod=5)

        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_upper'] = bb['upperband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_lower'] = bb['lowerband']
        bb_range = dataframe['bb_upper'] - dataframe['bb_lower']
        bb_range = bb_range.replace(0, np.nan)
        dataframe['bb_position'] = (dataframe['close'] - dataframe['bb_lower']) / bb_range

        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe.loc[
            (
                (dataframe['macdhist'] > 0) &
                (dataframe['macdhist'] > dataframe['macdhist'].shift(2))
            ) &
            (
                (dataframe['fastk'] >= 20) & (dataframe['fastk'] <= 85) &
                (dataframe['fastd'] >= 20) & (dataframe['fastd'] <= 85)
            ) &
            (
                (dataframe['bb_position'] <= 0.6)
            ) &
            (
                (dataframe['ema5'] > dataframe['ema5o'])
            ) &
            (
                (dataframe['rsi'] > 40)
            ) &
            (
                (dataframe['volume'] > dataframe['volume_sma'] * 0.7)
            ),
            'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # TEST: Çıkış sinyali yok - sadece stoploss/trailing/ROI
        dataframe['exit_long'] = 0
        return dataframe
