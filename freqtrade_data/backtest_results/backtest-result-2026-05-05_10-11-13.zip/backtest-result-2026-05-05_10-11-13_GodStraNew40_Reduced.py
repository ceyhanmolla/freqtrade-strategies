"""
GodStraNew40_Reduced - Reduced Gene Pool Strategy

Purpose: Compare reduced gene pool (8 indicators) vs full gene pool (60+)
to test if simpler is better.

Engineering: 
- Only 8 most reliable indicators
- Easier to understand, maintain, debug
- Less overfitting risk
- Trade-off: May miss some edge cases

Indicators kept (8):
- SMA: Simple Moving Average (trend)
- EMA: Exponential Moving Average (trend)
- RSI: Relative Strength Index (momentum)
- MACD: Moving Average Convergence Divergence (momentum)
- BBANDS: Bollinger Bands (volatility)
- ATR: Average True Range (volatility)
- STOCH: Stochastic (momentum)
- CCI: Commodity Channel Index (momentum)
"""

from freqtrade.strategy import IStrategy, CategoricalParameter
from pandas import DataFrame
import talib.abstract as ta
from functools import reduce
import numpy as np
from random import shuffle

# ========================================
# MAGIC NUMBERS - Configuration Constants
# ========================================
TREND_CHECK_CANDLES = 4
VOLUME_MIN_THRESHOLD = 10
TIME_PERIODS = [5, 10, 15, 20, 50, 100]

# ========================================
# REDUCED GENE POOL (8 indicators instead of 60+)
# ========================================
REDUCED_GOD_GENES = {
    'Overlap Studies': {
        'SMA',                   # Simple Moving Average - trend
        'EMA',                   # Exponential Moving Average - trend
    },
    'Momentum Indicators': {
        'RSI',                   # Relative Strength Index - overbought/oversold
        'MACD-0',               # MACD main line
        'MACD-1',               # MACD signal line
        'STOCH-0',              # Stochastic K
        'STOCH-1',              # Stochastic D
        'CCI',                  # Commodity Channel Index
    },
    'Volatility': {
        'ATR',                  # Average True Range - volatility
    }
}

# Build gene list with timeperiods
god_genes_with_timeperiod = list()
for category, genes in REDUCED_GOD_GENES.items():
    for gene in genes:
        if '-' in gene:
            parts = gene.split('-')
            gene_name = parts[0]
            gene_index = parts[1]
            for period in TIME_PERIODS:
                god_genes_with_timeperiod.append(f'{gene_name}-{gene_index}-{period}')
        else:
            for period in TIME_PERIODS:
                god_genes_with_timeperiod.append(f'{gene}-{period}')

buy_params = {
    "buy_crossed_indicator0": "SMA-5",
    "buy_crossed_indicator1": "SMA-12",
    "buy_crossed_indicator2": "SMA-5",
    "buy_indicator0": "SMA-15",
    "buy_indicator1": "SMA-100",
    "buy_indicator2": "SMA-110",
    "buy_operator0": "<R",
    "buy_operator1": ">",
    "buy_operator2": ">",
    "buy_real_num0": 0.2,
    "buy_real_num1": 0.5,
    "buy_real_num2": 1.0,
}

sell_params = {
    "sell_crossed_indicator0": "SMA-100",
    "sell_crossed_indicator1": "SMA-100",
    "sell_crossed_indicator2": "SMA-15",
    "sell_indicator0": "SMA-5",
    "sell_indicator1": "SMA-5",
    "sell_indicator2": "SMA-12",
    "sell_operator0": "CB",
    "sell_operator1": "CUT",
    "sell_operator2": "OT",
    "sell_real_num0": 0.6,
    "sell_real_num1": 0.5,
    "sell_real_num2": 0.7,
}


def normalize(series):
    """Normalize series to 0-1 range"""
    min_val = np.nanmin(series)
    max_val = np.nanmax(series)
    if max_val - min_val == 0:
        return series
    return (series - min_val) / (max_val - min_val)


def gene_calculator(dataframe, indicator):
    """Calculate indicator value from gene string"""
    gene = indicator.split('-')
    gene_len = len(gene)
    gene_name = gene[0]

    if gene_name in ['RSI', 'CCI', 'ATR', 'ADX', 'MFI', 'STOCH', 'MACD']:
        if gene_len == 2:
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=int(gene[1]),
            )
            return normalize(result)
        elif gene_len == 3:
            index = int(gene[1])
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=int(gene[2]),
            )
            if hasattr(result, '__iter__'):
                result = result.iloc[:, index] if hasattr(result, 'iloc') else np.array(result)[:, index]
            return normalize(result)
    elif gene_name in ['SMA', 'EMA', 'DEMA', 'TEMA', 'KAMA', 'WMA', 'MA', 'TRIMA']:
        if gene_len == 2:
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=int(gene[1]),
            )
            return normalize(result)
    else:
        result = None
        if gene_len == 1:
            result = getattr(ta, gene_name)(dataframe)
            return normalize(result)
        elif gene_len == 2:
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=int(gene[1]),
            )
            return normalize(result)
        elif gene_len == 3:
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=int(gene[2]),
            )
            if hasattr(result, 'iloc'):
                return normalize(result.iloc[:, int(gene[1])])
            return normalize(result)
        elif gene_len == 4:
            gene_timeperiod = int(gene[1])
            sharp_indicator = f'{gene_name}-{gene_timeperiod}'
            dataframe[sharp_indicator] = getattr(ta, gene_name)(
                dataframe,
                timeperiod=gene_timeperiod,
            )
            return normalize(ta.SMA(dataframe[sharp_indicator].fillna(0), TREND_CHECK_CANDLES))
        elif gene_len == 5:
            gene_timeperiod = int(gene[2])
            gene_index = int(gene[1])
            sharp_indicator = f'{gene_name}-{gene_index}-{gene_timeperiod}'
            dataframe[sharp_indicator] = getattr(ta, gene_name)(
                dataframe,
                timeperiod=gene_timeperiod,
            )
            if hasattr(dataframe[sharp_indicator], 'iloc'):
                return normalize(ta.SMA(dataframe[sharp_indicator].iloc[:, gene_index].fillna(0), TREND_CHECK_CANDLES))
            return normalize(ta.SMA(dataframe[sharp_indicator].fillna(0), TREND_CHECK_CANDLES))
    return dataframe['close']


def condition_generator(dataframe, operator, indicator, crossed_indicator, real_num):
    """Generate trading condition from parameters"""
    condition = (dataframe['volume'] > VOLUME_MIN_THRESHOLD)

    dataframe[indicator] = gene_calculator(dataframe, indicator)
    dataframe[crossed_indicator] = gene_calculator(dataframe, crossed_indicator)

    indicator_trend_sma = f"{indicator}-SMA-{TREND_CHECK_CANDLES}"
    crossed_trend_sma = f"{crossed_indicator}-SMA-{TREND_CHECK_CANDLES}"

    if indicator not in dataframe.columns:
        return condition, dataframe
    if crossed_indicator not in dataframe.columns:
        return condition, dataframe

    dataframe[indicator_trend_sma] = ta.SMA(
        dataframe[indicator].fillna(0), timeperiod=TREND_CHECK_CANDLES)
    dataframe[crossed_trend_sma] = ta.SMA(
        dataframe[crossed_indicator].fillna(0), timeperiod=TREND_CHECK_CANDLES)

    if operator == '<R':
        condition = condition & (
            (dataframe[indicator] < real_num) &
            (dataframe[indicator] < dataframe[indicator_trend_sma])
        )
    elif operator == '>':
        condition = condition & (dataframe[indicator] > real_num)
    elif operator == 'CB':
        condition = condition & (
            (dataframe[indicator] > dataframe[crossed_indicator]) &
            (
                (dataframe[indicator].shift(1) <= dataframe[crossed_indicator].shift(1)) |
                (np.isclose(dataframe[indicator].shift(1), dataframe[crossed_indicator].shift(1)))
            )
        )
    elif operator == 'CUT':
        condition = condition & (
            (dataframe[indicator] < dataframe[crossed_indicator]) &
            (
                (dataframe[indicator].shift(1) >= dataframe[crossed_indicator].shift(1)) |
                (np.isclose(dataframe[indicator].shift(1), dataframe[crossed_indicator].shift(1)))
            )
        )
    elif operator == 'OT':
        condition = condition & (
            np.isclose(dataframe[indicator], dataframe[crossed_indicator])
        )

    return condition, dataframe


class GodStraNew40_Reduced(IStrategy):
    """
    GodStraNew40_Reduced - Reduced Gene Pool Strategy

    Purpose: Test if reduced gene pool (8 indicators) performs better
    than full gene pool (60+ indicators).

    Engineering:
    - Only 8 indicators instead of 60+
    - Easier to understand and debug
    - Less overfitting risk
    - Trade-off: May miss some edge cases
    """
    INTERFACE_VERSION = 3
    can_short = False

    timeframe = '15m'

    stoploss = -0.10
    minimal_roi = {"0": 0.025, "60": 0.015, "120": 0.005}

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    buy_crossed_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator0"], space='buy')
    buy_crossed_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator1"], space='buy')
    buy_crossed_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator2"], space='buy')

    buy_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator0"], space='buy')
    buy_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator1"], space='buy')
    buy_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator2"], space='buy')

    buy_operator0 = CategoricalParameter(
        ['<R', '>', 'CB', 'CUT', 'OT'], default=buy_params["buy_operator0"], space='buy')
    buy_operator1 = CategoricalParameter(
        ['<R', '>', 'CB', 'CUT', 'OT'], default=buy_params["buy_operator1"], space='buy')
    buy_operator2 = CategoricalParameter(
        ['<R', '>', 'CB', 'CUT', 'OT'], default=buy_params["buy_operator2"], space='buy')

    buy_real_num0 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0], default=buy_params["buy_real_num0"], space='buy')
    buy_real_num1 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0], default=buy_params["buy_real_num1"], space='buy')
    buy_real_num2 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0], default=buy_params["buy_real_num2"], space='buy')

    sell_crossed_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator0"], space='sell')
    sell_crossed_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator1"], space='sell')
    sell_crossed_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator2"], space='sell')

    sell_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator0"], space='sell')
    sell_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator1"], space='sell')
    sell_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator2"], space='sell')

    sell_operator0 = CategoricalParameter(
        ['>R', '<', 'CB', 'CUT', 'OT'], default=sell_params["sell_operator0"], space='sell')
    sell_operator1 = CategoricalParameter(
        ['>R', '<', 'CB', 'CUT', 'OT'], default=sell_params["sell_operator1"], space='sell')
    sell_operator2 = CategoricalParameter(
        ['>R', '<', 'CB', 'CUT', 'OT'], default=sell_params["sell_operator2"], space='sell')

    sell_real_num0 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0], default=sell_params["sell_real_num0"], space='sell')
    sell_real_num1 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0], default=sell_params["sell_real_num1"], space='sell')
    sell_real_num2 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0], default=sell_params["sell_real_num2"], space='sell')

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def _build_conditions(self, dataframe, param_prefix):
        """Helper method: Build conditions from parameter prefix (buy_ or sell_)"""
        conditions = []
        
        for i in range(3):
            indicator = getattr(self, f'{param_prefix}_indicator{i}').value
            crossed = getattr(self, f'{param_prefix}_crossed_indicator{i}').value
            operator = getattr(self, f'{param_prefix}_operator{i}').value
            real_num = getattr(self, f'{param_prefix}_real_num{i}').value
            
            condition, dataframe = condition_generator(
                dataframe, operator, indicator, crossed, real_num
            )
            conditions.append(condition)
        
        return conditions

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = self._build_conditions(dataframe, 'buy')
        
        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = self._build_conditions(dataframe, 'sell')
        
        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'exit_long'] = 1
        return dataframe