"""
EVX_Tactical_Strategy_V4 - Optimizasyonlu Versiyon
===================================================

V3'ten farkları:
- det_buy > 0 koşulu geri eklendi (daha güvenli girişler)
- Volume filtresi eklendi (anormal hacimleri filtrele)
- ROI ve stoploss korundu

Author: OpenCode Assistant
Date: 2026-05-05
"""

import numpy as np
import pandas as pd
from freqtrade.strategy import IStrategy

class EVX_Tactical_Strategy_V4(IStrategy):

    INTERFACE_VERSION = 3

    timeframe = '15m'
    startup_candle_count = 50

    minimal_roi = {
        "0": 0.15,
        "120": 0.05,
        "240": 0.02,
        "480": 0
    }

    stoploss = -0.074

    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        high_low_diff = dataframe['high'] - dataframe['low']
        high_low_diff = high_low_diff.replace(0, np.nan)

        buy_pressure = (dataframe['close'] - dataframe['low']) / high_low_diff
        buy_pressure = buy_pressure.fillna(0.5)

        dataframe['B'] = dataframe['volume'] * buy_pressure
        dataframe['A'] = dataframe['volume'] - dataframe['B']

        safe_A = dataframe['A'].replace(0, np.nan)
        dataframe['EVX'] = (dataframe['B'] - safe_A) / safe_A
        dataframe['EVX'] = dataframe['EVX'].fillna(0)

        dataframe['det_buy'] = (dataframe['A'] * dataframe['open']) - (dataframe['B'] * dataframe['close'])
        dataframe['det_sell'] = (dataframe['A'] * dataframe['close']) - (dataframe['B'] * dataframe['open'])

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['enter_long'] = 0

        dataframe.loc[
            (
                (dataframe['det_buy'] > 0) &      # Matris koşulu pozitif
                (dataframe['EVX'] > 0) &          # Alım hacmi > Satış hacmi
                (dataframe['volume'] > 0)          # Hacim var
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['exit_long'] = 0

        dataframe.loc[
            (
                (dataframe['det_sell'] < 0) &     # Matris koşulu negatif (satış baskısı)
                (dataframe['EVX'] < 0) &           # Satış hacmi > Alım hacmi
                (dataframe['volume'] > 0)
            ),
            'exit_long'] = 1

        return dataframe