# GodStraNew Strategy
# Author: @Mablue (Masoud Azizi)
# freqtrade hyperopt --hyperopt-loss SharpeHyperOptLoss --spaces buy roi trailing sell --strategy GodStraNew
# --- Do not remove these libs ---
import logging
from freqtrade.strategy import IStrategy, CategoricalParameter, DecimalParameter
from pandas import DataFrame

logger = logging.getLogger(__name__)

# --------------------------------

# Add your lib to import here
# TODO: talib is fast but have not more indicators
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from functools import reduce
import numpy as np
from random import shuffle

# ========================================
# MAGIC NUMBERS - Configuration Constants
# ========================================
# Magic Number: Number of candles used for trend confirmation
# Engineering: 4 candles balances noise filtering vs signal responsiveness
TREND_CHECK_CANDLES = 4

# Magic Number: Minimum volume threshold to avoid low-liquidity trades
# Engineering: 10 filters noise but allows most viable trades
VOLUME_MIN_THRESHOLD = 10

# Magic Number: Timeperiod candidates for genetic algorithm
# Engineering: Short (5-15), Medium (50-55), Long (100-110) for multi-timeframe analysis
TIME_PERIODS = [5, 6, 12, 15, 50, 55, 100, 110]

# ========================================
# REDUCED GENE POOL (AŞAMA 2 DÜZELTME)
# Engineering: 60+ → ~20 reliable indicators
# ========================================
# Keep: Trend (SMA, EMA, DEMA, TEMA, KAMA, WMA) + Momentum (RSI, MACD, STOCH, CCI) + Volatility (BBANDS, ATR)
# Remove: Exotic indicators that add complexity without clear benefit
all_god_genes = {
    'Overlap Studies': {  # TREND - Most reliable
        'BBANDS-0',             # Bollinger Bands - volatility
        'BBANDS-1',             # Bollinger Bands - middle
        'BBANDS-2',             # Bollinger Bands - lower
        'DEMA',                 # Double EMA - smoother trend
        'EMA',                  # Exponential MA - fast trend
        # 'HT_TRENDLINE',      # REMOVED: Exotic, hard to interpret
        'KAMA',                 # Kaufman AMA - adaptive to volatility
        # 'MA',                # REMOVED: Redundant with SMA/EMA
        # 'MAMA-0',            # REMOVED: Exotic
        # 'MAMA-1',            # REMOVED: Exotic
        # 'MIDPOINT',         # REMOVED: Rarely used
        # 'MIDPRICE',         # REMOVED: Rarely used
        # 'SAR',              # REMOVED: Different logic
        # 'SAREXT',           # REMOVED: Different logic
        'SMA',                  # Simple MA - most reliable
        # 'T3',               # REMOVED: Exotic
        'TEMA',                 # Triple EMA - smoother
        # 'TRIMA',            # REMOVED: Rarely used
        'WMA',                  # Weighted MA
    },
    'Momentum Indicators': {  # MOMENTUM - Most reliable
        # 'ADX',              # REMOVED: Needs DI combination
        # 'ADXR',            # REMOVED: Rarely used
        # 'APO',             # REMOVED: Similar to MACD
        # 'AROON-0',         # REMOVED: Complex
        # 'AROON-1',         # REMOVED: Complex
        # 'AROONOSC',        # REMOVED: Complex
        # 'BOP',             # REMOVED: Rarely used
        'CCI',                  # Commodity Channel Index - reliable
        # 'CMO',             # REMOVED: Similar to RSI
        # 'DX',              # REMOVED: Needs ADX
        'MACD-0',               # MACD main - very reliable
        'MACD-1',               # MACD signal - needed for MACD
        'MACD-2',               # MACD histogram
        # 'MACDEXT-0',       # REMOVED: Overly complex
        # 'MACDEXT-1',       # REMOVED: Overly complex
        # 'MACDEXT-2',       # REMOVED: Overly complex
        # 'MACDFIX-0',      # REMOVED: Similar to MACD
        # 'MACDFIX-1',      # REMOVED: Similar to MACD
        # 'MACDFIX-2',      # REMOVED: Similar to MACD
        # 'MFI',            # REMOVED: Volume + Price complex
        # 'MINUS_DI',       # REMOVED: Needs ADX combo
        # 'MINUS_DM',       # REMOVED: Needs ADX combo
        # 'MOM',            # REMOVED: Simple ROC
        # 'PLUS_DI',        # REMOVED: Needs ADX combo
        # 'PLUS_DM',        # REMOVED: Needs ADX combo
        # 'PPO',            # REMOVED: Similar to MACD
        # 'ROC',            # REMOVED: Simple momentum
        # 'ROCP',           # REMOVED: Simple momentum
        # 'ROCR',           # REMOVED: Simple momentum
        # 'ROCR100',        # REMOVED: Simple momentum
        'RSI',                  # Relative Strength Index - most reliable
        'STOCH-0',              # Stochastic K - reliable
        'STOCH-1',              # Stochastic D - needed
        # 'STOCHF-0',       # REMOVED: Similar to STOCH
        # 'STOCHF-1',       # REMOVED: Similar to STOCH
        # 'STOCHRSI-0',    # REMOVED: Overly complex
        # 'STOCHRSI-1',    # REMOVED: Overly complex
        # 'TRIX',           # REMOVED: Similar to MACD
        # 'ULTOSC',        # REMOVED: Rarely used
        # 'WILLR',         # REMOVED: Similar to RSI
    },
    'Volume Indicators': {  # MINIMAL - Volume often adds noise
        # 'AD',               # REMOVED: Complex, needs price
        # 'ADOSC',           # REMOVED: Complex
        # 'OBV',             # REMOVED: Volume adds noise
    },
    'Volatility Indicators': {  # VOLATILITY - Keep reliable
        'ATR',                  # Average True Range - very reliable
        # 'NATR',            # REMOVED: Normalized ATR rarely used
        # 'TRANGE',          # REMOVED: Simple ATR is enough
    },
    'Price Transform': {  # REMOVED - Not useful for signals
        # 'AVGPRICE',       # REMOVED: Not useful
        # 'MEDPRICE',       # REMOVED: Not useful
        # 'TYPPRICE',       # REMOVED: Not useful
        # 'WCLPRICE',       # REMOVED: Not useful
    },
    'Cycle Indicators': {  # REMOVED - Too complex for this strategy
        # 'HT_DCPERIOD',    # REMOVED: Exotic
        # 'HT_DCPHASE',     # REMOVED: Exotic
        # 'HT_PHASOR-0',    # REMOVED: Exotic
        # 'HT_PHASOR-1',    # REMOVED: Exotic
        # 'HT_SINE-0',      # REMOVED: Exotic
        # 'HT_SINE-1',      # REMOVED: Exotic
        # 'HT_TRENDMODE',   # REMOVED: Exotic
    },
    'Pattern Recognition': {  # REMOVED - Too many, adds noise, hard to interpret
        # ALL REMOVED: 60+ candlestick patterns - useful but too complex
    },
    'Statistic Functions': {  # REMOVED - Rarely useful for trading signals
        # 'BETA',             # REMOVED: Rarely used
        # 'CORREL',           # REMOVED: Rarely used
        # 'LINEARREG',        # REMOVED: Similar to EMA
        # 'LINEARREG_ANGLE',  # REMOVED: Rarely used
        # 'LINEARREG_INTERCEPT',  # REMOVED: Rarely used
        # 'LINEARREG_SLOPE',  # REMOVED: Rarely used
        # 'STDDEV',          # REMOVED: Use BBANDS instead
        # 'TSF',             # REMOVED: Similar to EMA
        # 'VAR',             # REMOVED: Rarely used
    }

}
god_genes = set()
########################### SETTINGS ##############################

# Engineering: Multi-category indicators provide different market views
# Each category captures different aspect: trend, momentum, volatility
god_genes = {
    # Trend indicators (price direction)
    'SMA', 'EMA', 'DEMA', 'TEMA', 'KAMA',
    
    # Momentum indicators (speed of price change)
    'RSI', 'MACD', 'STOCH', 'CCI',
    
    # Volatility indicators (price range)
    'BBANDS', 'ATR',
    
    # Volume indicators (if available)
    # 'MFI', 'OBV',  # Uncomment if needed
}
# god_genes = {'SMA'}  # Original - too limited
# god_genes |= all_god_genes['Overlap Studies']  # All 15+ indicators

timeperiods = TIME_PERIODS
operators = [
    "D",  # Disabled gene
    ">",  # Indicator, bigger than cross indicator
    "<",  # Indicator, smaller than cross indicator
    "=",  # Indicator, equal with cross indicator
    "C",  # Indicator, crossed the cross indicator
    "CA",  # Indicator, crossed above the cross indicator
    "CB",  # Indicator, crossed below the cross indicator
    ">R",  # Normalized indicator, bigger than real number
    "=R",  # Normalized indicator, equal with real number
    "<R",  # Normalized indicator, smaller than real number
    "/>R",  # Normalized indicator devided to cross indicator, bigger than real number
    "/=R",  # Normalized indicator devided to cross indicator, equal with real number
    "/<R",  # Normalized indicator devided to cross indicator, smaller than real number
    "UT",  # Indicator, is in UpTrend status
    "DT",  # Indicator, is in DownTrend status
    "OT",  # Indicator, is in Off trend status(RANGE)
    "CUT",  # Indicator, Entered to UpTrend status
    "CDT",  # Indicator, Entered to DownTrend status
    "COT"  # Indicator, Entered to Off trend status(RANGE)
]
# number of candles to check up,don,off trend.

DECIMALS = 1
########################### END SETTINGS ##########################
# DATAFRAME = DataFrame()

god_genes = list(god_genes)
# print('selected indicators for optimzatin: \n', god_genes)

god_genes_with_timeperiod = list()
for god_gene in god_genes:
    for timeperiod in timeperiods:
        god_genes_with_timeperiod.append(f'{god_gene}-{timeperiod}')

# Let give somethings to CatagoricalParam to Play with them
# When just one thing is inside catagorical lists
# TODO: its Not True Way :)
if len(god_genes) == 1:
    god_genes = god_genes*2
if len(timeperiods) == 1:
    timeperiods = timeperiods*2
if len(operators) == 1:
    operators = operators*2


def normalize(df):
    min_val = df.min()
    max_val = df.max()
    diff = max_val - min_val
    if diff == 0:
        return df * 0
    return (df - min_val) / diff


_indicator_cache = {}


def gene_calculator(dataframe, indicator):
    if indicator in dataframe.keys():
        return dataframe[indicator]

    # Cuz Timeperiods not effect calculating CDL patterns recognations
    if 'CDL' in indicator:
        splited_indicator = indicator.split('-')
        splited_indicator[1] = "0"
        new_indicator = "-".join(splited_indicator)
        # print(indicator, new_indicator)
        indicator = new_indicator

    gene = indicator.split("-")

    gene_name = gene[0]
    gene_len = len(gene)

    if indicator in dataframe.keys():
        # print(f"{indicator}, calculated befoure")
        # print(len(dataframe.keys()))
        return dataframe[indicator]
    else:
        result = None
        # For Pattern Recognations
        if gene_len == 1:
            # print('gene_len == 1\t', indicator)
            result = getattr(ta, gene_name)(
                dataframe
            )
            return normalize(result)
        elif gene_len == 2:
            # print('gene_len == 2\t', indicator)
            gene_timeperiod = int(gene[1])
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=gene_timeperiod,
            )
            return normalize(result)
        # For
        elif gene_len == 3:
            # print('gene_len == 3\t', indicator)
            gene_timeperiod = int(gene[2])
            gene_index = int(gene[1])
            result = getattr(ta, gene_name)(
                dataframe,
                timeperiod=gene_timeperiod,
            ).iloc[:, gene_index]
            return normalize(result)
        # For trend operators(MA-5-SMA-4)
        elif gene_len == 4:
            # print('gene_len == 4\t', indicator)
            gene_timeperiod = int(gene[1])
            sharp_indicator = f'{gene_name}-{gene_timeperiod}'
            dataframe[sharp_indicator] = getattr(ta, gene_name)(
                dataframe,
                timeperiod=gene_timeperiod,
            )
            return normalize(ta.SMA(dataframe[sharp_indicator].fillna(0), TREND_CHECK_CANDLES))
        # For trend operators(STOCH-0-4-SMA-4)
        elif gene_len == 5:
            # print('gene_len == 5\t', indicator)
            gene_timeperiod = int(gene[2])
            gene_index = int(gene[1])
            sharp_indicator = f'{gene_name}-{gene_index}-{gene_timeperiod}'
            dataframe[sharp_indicator] = getattr(ta, gene_name)(
                dataframe,
                timeperiod=gene_timeperiod,
            ).iloc[:, gene_index]
            return normalize(ta.SMA(dataframe[sharp_indicator].fillna(0), TREND_CHECK_CANDLES))


def condition_generator(dataframe, operator, indicator, crossed_indicator, real_num):

    condition = (dataframe['volume'] > VOLUME_MIN_THRESHOLD)

    # TODO : it ill callculated in populate indicators.

    dataframe[indicator] = gene_calculator(dataframe, indicator)
    dataframe[crossed_indicator] = gene_calculator(dataframe, crossed_indicator)

    indicator_trend_sma = f"{indicator}-SMA-{TREND_CHECK_CANDLES}"
    if operator in ["UT", "DT", "OT", "CUT", "CDT", "COT"]:
        dataframe[indicator_trend_sma] = gene_calculator(dataframe, indicator_trend_sma)

    if operator == ">":
        condition = (
            dataframe[indicator] > dataframe[crossed_indicator]
        )
    elif operator == "=":
        condition = (
            np.isclose(dataframe[indicator], dataframe[crossed_indicator])
        )
    elif operator == "<":
        condition = (
            dataframe[indicator] < dataframe[crossed_indicator]
        )
    elif operator == "C":
        condition = (
            (qtpylib.crossed_below(dataframe[indicator], dataframe[crossed_indicator])) |
            (qtpylib.crossed_above(dataframe[indicator], dataframe[crossed_indicator]))
        )
    elif operator == "CA":
        condition = (
            qtpylib.crossed_above(dataframe[indicator], dataframe[crossed_indicator])
        )
    elif operator == "CB":
        condition = (
            qtpylib.crossed_below(
                dataframe[indicator], dataframe[crossed_indicator])
        )
    elif operator == ">R":
        condition = (
            dataframe[indicator] > real_num
        )
    elif operator == "=R":
        condition = (
            np.isclose(dataframe[indicator], real_num)
        )
    elif operator == "<R":
        condition = (
            dataframe[indicator] < real_num
        )
    elif operator == "/>R":
        condition = (
            dataframe[indicator].div(dataframe[crossed_indicator]) > real_num
        )
    elif operator == "/=R":
        condition = (
            np.isclose(dataframe[indicator].div(dataframe[crossed_indicator]), real_num)
        )
    elif operator == "/<R":
        condition = (
            dataframe[indicator].div(dataframe[crossed_indicator]) < real_num
        )
    elif operator == "UT":
        condition = (
            dataframe[indicator] > dataframe[indicator_trend_sma]
        )
    elif operator == "DT":
        condition = (
            dataframe[indicator] < dataframe[indicator_trend_sma]
        )
    elif operator == "OT":
        condition = (

            np.isclose(dataframe[indicator], dataframe[indicator_trend_sma])
        )
    elif operator == "CUT":
        condition = (
            (
                qtpylib.crossed_above(
                    dataframe[indicator],
                    dataframe[indicator_trend_sma]
                )
            ) &
            (
                dataframe[indicator] > dataframe[indicator_trend_sma]
            )
        )
    elif operator == "CDT":
        condition = (
            (
                qtpylib.crossed_below(
                    dataframe[indicator],
                    dataframe[indicator_trend_sma]
                )
            ) &
            (
                dataframe[indicator] < dataframe[indicator_trend_sma]
            )
        )
    elif operator == "COT":
        condition = (
            (
                (
                    qtpylib.crossed_below(
                        dataframe[indicator],
                        dataframe[indicator_trend_sma]
                    )
                ) |
                (
                    qtpylib.crossed_above(
                        dataframe[indicator],
                        dataframe[indicator_trend_sma]
                    )
                )
            ) &
            (
                np.isclose(
                    dataframe[indicator],
                    dataframe[indicator_trend_sma]
                )
            )
        )

    return condition, dataframe


# Buy hyperspace params:
buy_params = {
    "buy_crossed_indicator0": "SMA-5",
    "buy_crossed_indicator1": "SMA-12",
    "buy_crossed_indicator2": "SMA-5",
    "buy_indicator0": "SMA-15",
    "buy_indicator1": "SMA-100",
    "buy_indicator2": "SMA-110",
    "buy_operator0": "<R",
    "buy_operator1": ">",
    "buy_operator2": ">",
    "buy_real_num0": 0.2,
    "buy_real_num1": 0.5,
    "buy_real_num2": 1.0,
}

# Sell hyperspace params:
sell_params = {
    "sell_crossed_indicator0": "SMA-100",
    "sell_crossed_indicator1": "SMA-100",
    "sell_crossed_indicator2": "SMA-15",
    "sell_indicator0": "SMA-5",
    "sell_indicator1": "SMA-5",
    "sell_indicator2": "SMA-12",
    "sell_operator0": "CB",
    "sell_operator1": "CUT",
    "sell_operator2": "OT",
    "sell_real_num0": 0.6,
    "sell_real_num1": 0.5,
    "sell_real_num2": 0.7,
}

class GodStraNew40(IStrategy):
    """
    GodStraNew40 - Genetic Algorithm Based Strategy
    
    Description:
        Uses genetic algorithm approach to evolve trading indicators.
        Three buy conditions AND three sell conditions must all be true.
    
    Gene Categories (all_god_genes):
        - Overlap Studies: BBANDS, DEMA, EMA, KAMA, SMA, TEMA, TRIMA, WMA, etc.
        - Momentum: RSI, MACD, STOCH, CCI, ROC, WILLR
        - Volume: OBV, AD, ADOSC
        - Volatility: ATR, NATR
    
    Operators:
        - "<R": Less than with trend check
        - ">": Greater than
        - "CB": Crosses above
        - "CUT": Crosses below
        - "OT": Equals (overbought/oversold)
    
    Key Parameters:
        - TREND_CHECK_CANDLES=4: Number of candles for trend confirmation
        - VOLUME_MIN_THRESHOLD=10: Minimum volume filter
        - TIME_PERIODS=[5,6,12,15,50,55,100,110]: Genetic algorithm candidates
    
    Author: @Mablue (Masoud Azizi)
    Engineering: Multi-indicator genetic optimization with trend filtering
    """
    INTERFACE_VERSION = 3
    can_short = False

    # #################### RESULTS PASTE PLACE ####################

    # #################### END OF RESULT PLACE ####################

    # TODO: Its not dry code!
    # Buy Hyperoptable Parameters/Spaces.
    buy_crossed_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator0"], space='buy')
    buy_crossed_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator1"], space='buy')
    buy_crossed_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator2"], space='buy')

    buy_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator0"], space='buy')
    buy_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator1"], space='buy')
    buy_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator2"], space='buy')

    buy_operator0 = CategoricalParameter(operators, default=buy_params["buy_operator0"], space='buy')
    buy_operator1 = CategoricalParameter(operators, default=buy_params["buy_operator1"], space='buy')
    buy_operator2 = CategoricalParameter(operators, default=buy_params["buy_operator2"], space='buy')

    buy_real_num0 = DecimalParameter(0, 1, decimals=DECIMALS,  default=buy_params["buy_real_num0"], space='buy')
    buy_real_num1 = DecimalParameter(0, 1, decimals=DECIMALS, default=buy_params["buy_real_num1"], space='buy')
    buy_real_num2 = DecimalParameter(0, 1, decimals=DECIMALS, default=buy_params["buy_real_num2"], space='buy')

    # Sell Hyperoptable Parameters/Spaces.
    sell_crossed_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator0"], space='sell')
    sell_crossed_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator1"], space='sell')
    sell_crossed_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator2"], space='sell')

    sell_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator0"], space='sell')
    sell_indicator1 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator1"], space='sell')
    sell_indicator2 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator2"], space='sell')

    sell_operator0 = CategoricalParameter(operators, default=sell_params["sell_operator0"], space='sell')
    sell_operator1 = CategoricalParameter(operators, default=sell_params["sell_operator1"], space='sell')
    sell_operator2 = CategoricalParameter(operators, default=sell_params["sell_operator2"], space='sell')

    sell_real_num0 = DecimalParameter(0, 1, decimals=DECIMALS, default=sell_params["sell_real_num0"], space='sell')
    sell_real_num1 = DecimalParameter(0, 1, decimals=DECIMALS, default=sell_params["sell_real_num1"], space='sell')
    sell_real_num2 = DecimalParameter(0, 1, decimals=DECIMALS, default=sell_params["sell_real_num2"], space='sell')

    # Stoploss: Maximum risk per trade = 10%
    # Engineering: -10% hard stop prevents single trade from 
    # destroying portfolio. With 3 max trades = max 30% portfolio risk
    stoploss = -0.10

    # ROI: Realistic profit targets
    # Engineering: 0.5% quick win captures momentum, 
    # 2% for longer trades matches avg ~30 day duration
    minimal_roi = {
        "0": 0.005,     # immediate: 0.5%
        "60": 0.01,      # 1 hour: 1%
        "180": 0.015,   # 3 hours: 1.5%
        "720": 0.02,    # 12 hours: 2%
        "1440": 0.025,  # 24 hours: 2.5%
    }

    # Trailing stop: Lock in profits if trend reverses
    # Engineering: 1% trailing after 2% profit locks in gains
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    # Buy hypers
    timeframe = '5m'

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        return dataframe

    def _build_conditions(self, dataframe, param_prefix):
        """Helper method: Build conditions from parameter prefix (buy_ or sell_)"""
        conditions = []
        
        for i in range(3):
            indicator = getattr(self, f'{param_prefix}_indicator{i}').value
            crossed = getattr(self, f'{param_prefix}_crossed_indicator{i}').value
            operator = getattr(self, f'{param_prefix}_operator{i}').value
            real_num = getattr(self, f'{param_prefix}_real_num{i}').value
            
            condition, dataframe = condition_generator(
                dataframe, operator, indicator, crossed, real_num
            )
            conditions.append(condition)
        
        return conditions

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = self._build_conditions(dataframe, 'buy')
        
        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = self._build_conditions(dataframe, 'sell')
        
        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'exit_long'] = 1
        return dataframe
