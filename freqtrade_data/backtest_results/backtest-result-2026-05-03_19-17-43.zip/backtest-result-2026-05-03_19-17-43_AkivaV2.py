# AkivaV2 - Modern EWO Strategy (Rewritten from akiva6)
# Based on research: ElliotV8, NASOSv5, E0V1E2 patterns
# Target: 1+ trade/day with positive returns

from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter
from pandas import DataFrame
import talib.abstract as ta
import pandas as pd
import numpy as np
from datetime import datetime
from functools import reduce


def EWO(dataframe, ema_length=50, ema2_length=200):
    ema1 = ta.EMA(dataframe, timeperiod=ema_length)
    ema2 = ta.EMA(dataframe, timeperiod=ema2_length)
    return (ema1 - ema2) / dataframe['close'] * 100


class AkivaV2(IStrategy):
    INTERFACE_VERSION = 3
    
    timeframe = '5m'
    inf_1h = '1h'
    
    # ROI - Düşük eşikler daha fazla trade için
    minimal_roi = {
        "0": 0.03,
        "10": 0.02,
        "30": 0.015,
        "60": 0.01,
        "120": 0,
    }
    
    # Stoploss - makul değer
    stoploss = -0.02
    use_custom_stoploss = True
    
    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True
    
    # Sell signals
    use_exit_signal = True
    exit_profit_only = True
    ignore_roi_if_entry_signal = False
    
    # Processing
    process_only_new_candles = True
    startup_candle_count = 400
    exit_timeout = 720
    
    # Parameters - EWO Optimized
    base_nb_candles_buy = IntParameter(5, 20, default=12, space='buy')
    base_nb_candles_sell = IntParameter(10, 40, default=20, space='sell')
    
    low_offset = DecimalParameter(0.90, 0.98, default=0.95, space='buy')
    low_offset_2 = DecimalParameter(0.90, 0.98, default=0.95, space='buy')
    high_offset = DecimalParameter(0.95, 1.05, default=1.0, space='sell')
    high_offset_2 = DecimalParameter(1.0, 1.3, default=1.1, space='sell')
    
    ewo_high = DecimalParameter(1.0, 5.0, default=3.0, space='buy')
    ewo_high_2 = DecimalParameter(1.0, 4.0, default=2.5, space='buy')
    ewo_low = DecimalParameter(-8.0, -3.0, default=-5.0, space='buy')
    
    rsi_buy = IntParameter(35, 60, default=45, space='buy')
    rsi_fast_buy = IntParameter(25, 50, default=35, space='buy')
    
    # Sell params
    sell_rsi = IntParameter(60, 80, default=70, space='sell')
    
    @property
    def protections(self):
        return [
            {"method": "CooldownPeriod", "stop_duration_candles": 5},
            {
                "method": "MaxDrawdown",
                "lookback_period_candles": 48,
                "trade_limit": 20,
                "stop_duration_candles": 4,
                "max_allowed_drawdown": 0.2
            },
            {
                "method": "StoplossGuard",
                "lookback_period_candles": 24,
                "trade_limit": 4,
                "stop_duration_candles": 2,
                "only_per_pair": False
            },
        ]
    
    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        return [(pair, self.timeframe) for pair in pairs] + \
               [(pair, self.inf_1h) for pair in pairs]
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMAs for buy/sell
        for val in self.base_nb_candles_buy.range:
            dataframe[f'ma_buy_{val}'] = ta.EMA(dataframe, timeperiod=val)
        
        for val in self.base_nb_candles_sell.range:
            dataframe[f'ma_sell_{val}'] = ta.EMA(dataframe, timeperiod=val)
        
        # Standard indicators
        dataframe['ema_8'] = ta.EMA(dataframe, timeperiod=8)
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_100'] = ta.EMA(dataframe, timeperiod=100)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        
        dataframe['sma_9'] = ta.SMA(dataframe, timeperiod=9)
        dataframe['sma_200'] = ta.SMA(dataframe, timeperiod=200)
        dataframe['sma_200_dec'] = dataframe['sma_200'] < dataframe['sma_200'].shift(20)
        
        # HMA
        dataframe['hma_50'] = self._hull_moving_average(dataframe['close'], window=50)
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)
        dataframe['rsi_slow'] = ta.RSI(dataframe, timeperiod=20)
        
        # EWO
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        
        # ATR for volatility
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)
        
        # Volume
        dataframe['volume_ma'] = dataframe['volume'].rolling(20).mean()
        dataframe['volume_ok'] = dataframe['volume'] > dataframe['volume_ma'] * 0.3
        
        return dataframe
    
    def _hull_moving_average(self, series, window):
        if window % 2 == 0:
            window += 1
        half_window = (window // 2) + 1
        wma1 = series.rolling(window=half_window).mean()
        wma2 = series.rolling(window=window).mean()
        hull = (2 * wma1 - wma2).rolling(window=int(np.sqrt(window))).mean()
        return hull
    
    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Basit ve güvenilir buy sinyalleri
        dataframe['enter_long'] = 0
        
        # Condition 1: EWO High
        cond1 = (
            (dataframe['rsi_fast'] < 40) &
            (dataframe['EWO'] > 2.5) &
            (dataframe['close'] < dataframe['ema_50'] * 0.97) &
            (dataframe['volume'] > 0)
        )
        
        # Condition 2: RSI oversold + düşük fiyat
        cond2 = (
            (dataframe['rsi'] < 35) &
            (dataframe['rsi_fast'] < 30) &
            (dataframe['close'] < dataframe['ema_20'] * 0.95) &
            (dataframe['volume'] > 0)
        )
        
        # Condition 3: EWO Low (dip)
        cond3 = (
            (dataframe['EWO'] < -4) &
            (dataframe['rsi_fast'] < 35) &
            (dataframe['close'] < dataframe['ema_50'] * 0.93) &
            (dataframe['volume'] > 0)
        )
        
        dataframe.loc[cond1 | cond2 | cond3, 'enter_long'] = 1
        
        return dataframe
    
    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        
        # Sell 1: RSI overbought
        cond1 = (dataframe['rsi'] > 65) & (dataframe['rsi'] < dataframe['rsi'].shift(1))
        
        # Sell 2: Fiyat HMA'nın altına düştü
        cond2 = (dataframe['close'] < dataframe['hma_50']) & (dataframe['close'] > dataframe['open'])
        
        # Sell 3: Strong momentum kaybı
        cond3 = (dataframe['EWO'] < 0) & (dataframe['rsi_fast'] > 60)
        
        dataframe.loc[cond1 | cond2 | cond3, 'exit_long'] = 1
        
        return dataframe
    
    def custom_stoploss(self, pair: str, trade: 'Trade', current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:
        # Negatif pozisyonlarda hızlı çıkış
        if current_profit < -0.02:
            return 0.001
        if current_profit < -0.01:
            return 0.01
        if current_profit < 0:
            return 0.015
        
        # Kâr artınca stop yükselir (NASOS tarzı)
        if current_profit > 0.15:
            return 0.05
        if current_profit > 0.08:
            return 0.03
        if current_profit > 0.04:
            return 0.02
        if current_profit > 0.02:
            return 0.015
        
        return self.stoploss
    
    def confirm_trade_exit(self, pair: str, trade: 'Trade', order_type: str, amount: float,
                           rate: float, time_in_force: str, sell_reason: str,
                           current_time: datetime, **kwargs) -> bool:
        return True