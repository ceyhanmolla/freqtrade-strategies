"""
EwoMomentumV2 - İyileştirilmiş EWO Momentum Strategy
===================================================

YAPILAN İYİLEŞTİRMELER (V1 -> V2):
1. Stoploss: -10% -> -5% (daha sıkı risk yönetimi)
2. Minimal ROI düşürüldü (kar realizasyonu daha erken)
3. EWO parametreleri: (50,200) -> (5,35) (gerçek EWO standardı)
4. Volume filtresi iyileştirildi

BACKTEST SONUÇLARI (30 gün) - V1:
- Profit: +43.67%
- Trades: 16
- Win Rate: 93.8%
- Drawdown: 5.33%

Author: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame

import talib.abstract as ta
import numpy as np


def EWO(dataframe, ema_length=5, ema2_length=35):
    """Elliot Wave Oscillator - EMA farkı bazlı momentum (Standart 5,35)"""
    df = dataframe.copy()
    ema1 = ta.EMA(df, timeperiod=ema_length)
    ema2 = ta.EMA(df, timeperiod=ema2_length)
    emadif = (ema1 - ema2) / df['close'] * 100
    return emadif


class EwoMomentumV2(IStrategy):
    INTERFACE_VERSION = 2

    # İYİLEŞTİRME: Daha muhafazakâr ROI
    minimal_roi = {
        "0": 0.3,
        "30": 0.6,
        "60": 1.0,
        "180": 2.0,
    }

    # İYİLEŞTİRME: Daha sıkı stoploss
    stoploss = -0.05

    trailing_stop = True
    trailing_stop_positive = 0.004
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    use_exit_signal = False
    exit_profit_only = False
    exit_profit_offset = 0.008
    ignore_roi_if_entry_signal = True

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # İYİLEŞTİRME: Standart EWO (5,35) - orijinal (50,200) yerine
        dataframe['ema_5'] = ta.EMA(dataframe, timeperiod=5)
        dataframe['ema_35'] = ta.EMA(dataframe, timeperiod=35)
        dataframe['EWO'] = EWO(dataframe, 5, 35)

        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Volume indicator
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['buy'] = 0

        # Koşul 1: Pozitif EWO + düşük RSI (Trend takibi)
        buy_cond1 = (
            (dataframe['EWO'] > 0.2) &        # Düşürüldü: 0.5 -> 0.2
            (dataframe['rsi'] < 60) &            # Yükseltildi: 55 -> 60
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_sma'] * 4)  # 3x -> 4x
        )

        # Koşul 2: Negatif EWO (Aşırı satım - daha hassas)
        buy_cond2 = (
            (dataframe['EWO'] < -1.5) &        # Düşürüldü: -2.0 -> -1.5
            (dataframe['rsi'] < 45) &            # Yükseltildi: 40 -> 45
            (dataframe['volume'] > 0) &
            (dataframe['volume'] < dataframe['volume_sma'] * 3)
        )

        dataframe.loc[buy_cond1 | buy_cond2, 'buy'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0
        return dataframe