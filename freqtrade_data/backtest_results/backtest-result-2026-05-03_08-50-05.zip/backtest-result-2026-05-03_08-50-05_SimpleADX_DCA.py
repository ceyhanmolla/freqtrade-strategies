import logging
from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter
from typing import Dict, Optional
from pandas import DataFrame
import talib.abstract as ta
from datetime import datetime
from freqtrade.persistence import Trade
import math

logger = logging.getLogger(__name__)


class SimpleADX_DCA(IStrategy):
    INTERFACE_VERSION = 3
    can_short = False

    minimal_roi = {
        "0": 0.003,
        "30": 0.006,
        "60": 0.010,
        "120": 0.015,
        "240": 0.020,
        "360": 0.025,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    timeframe = "15m"
    process_only_new_candles = True
    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    max_open_trades = 3
    position_adjustment_enable = True
    max_entry_position_adjustment = 3

    startup_candle_count = 200

    order_types = {
        "entry": "limit",
        "exit": "limit",
        "stoploss": "market",
        "stoploss_on_exchange": False,
    }

    order_time_in_force = {"entry": "GTC", "exit": "GTC"}

    buy_rsi = IntParameter(20, 45, default=35, space="buy", optimize=True)
    sell_rsi = IntParameter(55, 85, default=70, space="sell", optimize=True)
    buy_adx = IntParameter(15, 40, default=25, space="buy", optimize=True)
    buy_ema_fast = IntParameter(5, 15, default=9, space="buy", optimize=True)
    buy_ema_slow = IntParameter(20, 50, default=30, space="buy", optimize=True)
    dca_trigger = DecimalParameter(-0.02, -0.08, default=-0.03, decimals=3, space="buy", optimize=True)
    dca_multiplier = DecimalParameter(1.2, 2.0, default=1.5, decimals=2, space="buy", optimize=True)

    def __init__(self, config: dict) -> None:
        super().__init__(config)
        self.last_dca_level = {}

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=14)
        dataframe["rsi_fast"] = ta.RSI(dataframe, timeperiod=7)
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=14)
        dataframe["plus_di"] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe["minus_di"] = ta.MINUS_DI(dataframe, timeperiod=14)

        for val in self.buy_ema_fast.range:
            dataframe[f"ema_fast_{val}"] = ta.EMA(dataframe, timeperiod=val)

        for val in self.buy_ema_slow.range:
            dataframe[f"ema_slow_{val}"] = ta.EMA(dataframe, timeperiod=val)

        dataframe["ema_9"] = ta.EMA(dataframe, timeperiod=9)
        dataframe["ema_21"] = ta.EMA(dataframe, timeperiod=21)
        dataframe["ema_50"] = ta.EMA(dataframe, timeperiod=50)
        dataframe["ema_200"] = ta.EMA(dataframe, timeperiod=200)

        macd = ta.MACD(dataframe)
        dataframe["macd"] = macd["macd"]
        dataframe["macd_signal"] = macd["macdsignal"]
        dataframe["macd_hist"] = macd["macdhist"]

        bollinger = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe["bb_lower"] = bollinger["lowerband"]
        dataframe["bb_middle"] = bollinger["middleband"]
        dataframe["bb_upper"] = bollinger["upperband"]
        dataframe["bb_width"] = (dataframe["bb_upper"] - dataframe["bb_lower"]) / dataframe["bb_middle"]

        dataframe["atr"] = ta.ATR(dataframe, timeperiod=14)
        dataframe["atr_percent"] = (dataframe["atr"] / dataframe["close"]) * 100

        dataframe["volume_sma"] = dataframe["volume"].rolling(window=20).mean()
        dataframe["volume_ratio"] = dataframe["volume"] / dataframe["volume_sma"]

        dataframe["high_20"] = dataframe["high"].rolling(window=20).max()
        dataframe["low_20"] = dataframe["low"].rolling(window=20).min()
        dataframe["price_position"] = (dataframe["close"] - dataframe["low_20"]) / (dataframe["high_20"] - dataframe["low_20"])

        dataframe["close_prev"] = dataframe["close"].shift(1)
        dataframe["rsi_prev"] = dataframe["rsi"].shift(1)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata["pair"]
        open_trades = Trade.get_open_trades()
        if any(trade.pair == pair for trade in open_trades):
            return dataframe

        last_candle = dataframe.iloc[-1]
        prev_candle = dataframe.iloc[-2] if len(dataframe) > 1 else last_candle

        buy_ema_fast = self.buy_ema_fast.value
        buy_ema_slow = self.buy_ema_slow.value

        dataframe.loc[
            (
                (dataframe[f"ema_fast_{buy_ema_fast}"] > dataframe[f"ema_slow_{buy_ema_slow}"]) &
                (dataframe["adx"] > self.buy_adx.value) &
                (dataframe["rsi"] < self.buy_rsi.value) &
                (dataframe["rsi_prev"] < dataframe["rsi"]) &
                (dataframe["volume"] > dataframe["volume_sma"] * 1.2) &
                (dataframe["close"] < dataframe["bb_lower"] * 1.02) &
                (dataframe["plus_di"] > dataframe["minus_di"]) &
                (dataframe["volume"] > 0)
            ),
            ["enter_long", "enter_tag"]
        ] = (1, "adx_rsi_buy")

        dataframe.loc[
            (
                (dataframe["ema_9"] > dataframe["ema_21"]) &
                (dataframe["macd"] > dataframe["macd_signal"]) &
                (dataframe["macd_hist"] > 0) &
                (dataframe["rsi"] < 45) &
                (dataframe["adx"] > 20) &
                (dataframe["volume_ratio"] > 1.3) &
                (dataframe["volume"] > 0)
            ),
            ["enter_long", "enter_tag"]
        ] = (1, "ema_macd_buy")

        dataframe.loc[
            (
                (dataframe["rsi"] < 30) &
                (dataframe["adx"] > self.buy_adx.value) &
                (dataframe["price_position"] < 0.2) &
                (dataframe["volume_ratio"] > 1.1) &
                (dataframe["volume"] > 0)
            ),
            ["enter_long", "enter_tag"]
        ] = (1, "oversold_buy")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        last_candle = dataframe.iloc[-1]

        dataframe.loc[
            (
                (dataframe["rsi"] > self.sell_rsi.value) &
                (dataframe["rsi"] > dataframe["rsi"].shift(1)) &
                (dataframe["ema_9"] < dataframe["ema_21"]) &
                (dataframe["volume"] > 0)
            ),
            "exit_long"
        ] = 1

        dataframe.loc[
            (
                (dataframe["close"] > dataframe["bb_upper"] * 1.01) &
                (dataframe["rsi"] > 70) &
                (dataframe["volume"] > 0)
            ),
            "exit_long"
        ] = 1

        return dataframe

    def custom_exit(self, pair: str, trade: 'Trade', current_time: 'datetime',
                   current_rate: float, current_profit: float, **kwargs):
        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe.empty:
            return None

        last_candle = dataframe.iloc[-1].squeeze()
        filled_buys = trade.select_filled_orders('buy')
        count_of_buys = len(filled_buys)

        if current_profit > 0.05 and last_candle['rsi'] > 80:
            return 'rsi_overbought_exit'

        if current_profit > 0.03 and last_candle['macd'] < last_candle['macd_signal']:
            return 'macd_cross_down'

        if current_profit > 0.08 and count_of_buys >= 2 and last_candle['rsi'] > 65:
            return 'profit_take_rsi'

        if current_profit < -0.05 and count_of_buys >= 3:
            if last_candle['rsi'] < 35 and last_candle['adx'] > 25:
                return 'dca_recovery_wait'

        return None

    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                             current_rate: float, current_profit: float, min_stake: float,
                             max_stake: float, **kwargs):
        if current_profit > self.dca_trigger.value:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None

        last_candle = dataframe.iloc[-1].squeeze()
        filled_buys = trade.select_filled_orders('buy')
        count_of_buys = len(filled_buys)

        if count_of_buys >= self.max_entry_position_adjustment:
            return None

        if last_candle['rsi'] > 40:
            return None

        if last_candle['adx'] < 15:
            return None

        dca_trigger_value = self.dca_trigger.value
        safety_order_trigger = abs(dca_trigger_value) * count_of_buys

        if current_profit <= (-1 * abs(safety_order_trigger)):
            try:
                stake_amount = filled_buys[0].cost
                stake_amount = stake_amount * self.dca_multiplier.value
                amount = stake_amount / current_rate

                logger.info(f"DCA buy #{count_of_buys + 1} for {trade.pair}, stake: {stake_amount}, amount: {amount}")
                return stake_amount
            except Exception as e:
                logger.info(f"Error in DCA for {trade.pair}: {str(e)}")
                return None

        return None