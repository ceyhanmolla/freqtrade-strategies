# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# isort: skip_file
import numpy as np
import pandas as pd
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
from freqtrade.strategy import IStrategy, DecimalParameter, IntParameter


def calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26):
    """Ichimoku Cloud hesaplaması"""
    df = dataframe.copy()
    
    # Tenkan-sen (Conversion Line)
    df['tenkan_sen'] = (df['high'].rolling(window=conversion).max() + df['low'].rolling(window=conversion).min()) / 2
    
    # Kijun-sen (Base Line)
    df['kijun_sen'] = (df['high'].rolling(window=base).max() + df['low'].rolling(window=base).min()) / 2
    
    # Senkou Span A (Leading Span A)
    df['senkou_span_a'] = ((df['tenkan_sen'] + df['kijun_sen']) / 2).shift(displacement)
    
    # Senkou Span B (Leading Span B)
    df['senkou_span_b'] = ((df['high'].rolling(window=span).max() + df['low'].rolling(window=span).min()) / 2).shift(displacement)
    
    # Chuikou Span (Lagging Span)
    df['chikou_span'] = df['close'].shift(-displacement)
    
    return df


class IchiFan1m(IStrategy):
    """
    Ichimoku ve EMA Fan stratejisi - Freqtrade uyumlu
    """
    INTERFACE_VERSION = 3

    # Zaman dilimi - 5m olarak değiştirildi
    timeframe = '5m'
    startup_candle_count = 120

    # Stoploss
    stoploss = -0.10

    # Trailing stop
    trailing_stop = True
    trailing_stop_positive = 0.02
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    # ROI
    minimal_roi = {
        "0": 0.03,
        "30": 0.015,
        "60": 0.01,
        "180": 0
    }

    # Hyperopt parametreleri (optimize=False ile varsayılan)
    buy_fan_magnitude_gain = DecimalParameter(0.00000, 0.00005, default=0.00001, space='buy', optimize=False)
    buy_fan_magnitude = DecimalParameter(-0.00100, 0.00100, default=-0.00057, space='buy', optimize=False)
    buy_ema_96_diff = DecimalParameter(0.00000, 0.00100, default=0.00057, space='buy', optimize=False)
    buy_ema_open_48_diff = DecimalParameter(-0.00050, 0.00050, default=-0.00001, space='buy', optimize=False)
    buy_fan_magnitude_shift_value = IntParameter(1, 5, default=1, space='buy', optimize=False)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # EMA Göstergeleri
        dataframe['ema_close_12'] = ta.EMA(dataframe, timeperiod=12)
        dataframe['ema_close_24'] = ta.EMA(dataframe, timeperiod=24)
        dataframe['ema_close_48'] = ta.EMA(dataframe, timeperiod=48)
        dataframe['ema_close_96'] = ta.EMA(dataframe, timeperiod=96)
        
        # Açılış fiyatına dayalı EMA
        dataframe['ema_open_48'] = ta.EMA(dataframe['open'], timeperiod=48)

        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # Ichimoku Cloud - Manuel hesaplama
        ichimoku = calculate_ichimoku(dataframe, conversion=9, base=26, span=52, displacement=26)
        dataframe['senkou_span_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_span_b'] = ichimoku['senkou_span_b']
        dataframe['senkou_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_b'] = ichimoku['senkou_span_b']

        # Fan Magnitude: Hızlı EMA ile Yavaş EMA arasındaki yüzdelik fark
        dataframe['fan_magnitude'] = (dataframe['ema_close_12'] - dataframe['ema_close_96']) / dataframe['ema_close_96']

        # Fan Magnitude Gain
        shift_val = self.buy_fan_magnitude_shift_value.value
        dataframe['fan_magnitude_gain'] = dataframe['fan_magnitude'] - dataframe['fan_magnitude'].shift(shift_val)

        # Yüzdelik fiyat farklılıkları
        dataframe['ema_96_diff'] = (dataframe['close'] - dataframe['ema_close_96']) / dataframe['ema_close_96']
        dataframe['ema_open_48_diff'] = (dataframe['close'] - dataframe['ema_open_48']) / dataframe['ema_open_48']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # Giriş koşulları - GEVŞETİLMİŞ versiyon
        buy_condition = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b']) &
            (dataframe['fan_magnitude_gain'] >= self.buy_fan_magnitude_gain.value) &
            (dataframe['fan_magnitude'] >= self.buy_fan_magnitude.value) &
            (dataframe['ema_96_diff'] >= self.buy_ema_96_diff.value) &
            (dataframe['ema_open_48_diff'] >= self.buy_ema_open_48_diff.value) &
            (dataframe['volume'] > 0)
        )

        dataframe.loc[buy_condition, 'enter_long'] = 1
        dataframe.loc[buy_condition, 'enter_tag'] = 'ichifan_entry'

        # Fallback: Ichimoku bullish - daha basit giriş
        fallback_condition = (
            (dataframe['close'] > dataframe['senkou_a']) &
            (dataframe['close'] > dataframe['senkou_b']) &
            (dataframe['volume'] > 0)
        )
        dataframe.loc[fallback_condition & (dataframe['enter_long'] == 0), 'enter_long'] = 1
        dataframe.loc[fallback_condition & (dataframe['enter_long'] == 0), 'enter_tag'] = 'ichimoku_bullish'

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''

        # Çıkış koşulları - RSI overbought daha güvenli
        # Ichimoku bearish sinyal çok erken çıkışlara neden olabilir
        dataframe.loc[
            (dataframe['rsi'] > 80),
            ['exit_long', 'exit_tag']
        ] = (1, 'rsi_extreme')

        return dataframe