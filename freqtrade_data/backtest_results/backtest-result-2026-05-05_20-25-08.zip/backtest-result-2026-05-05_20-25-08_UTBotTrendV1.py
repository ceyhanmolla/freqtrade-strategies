"""
UTBotTrendV1 - UTBot Alerts Strategy (Simplified)
================================================

STRATEJİ AÇIKLAMASI:
- ATR-based trailing stop (Chandelier Exit benzeri)
- EMA filter ile trend doğrulama
- ADX ile trend gücü kontrolü

MÜHENDİSLİK NOTU:
- Orijinal UTBot çok karmaşık loop gerektiriyor
- Basit ATR trailing stop ile test edildi
- Farklı sonuç: Doküman 2021-2023 test, biz 2026 test

Author: Engineering from Medium doc
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame
import numpy as np
import talib.abstract as ta


class UTBotTrendV1(IStrategy):
    INTERFACE_VERSION = 2

    minimal_roi = {
        "0": 0.4,
        "30": 0.8,
        "60": 1.5,
    }

    stoploss = -0.10

    trailing_stop = True
    trailing_stop_positive = 0.012
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    use_exit_signal = False
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '15m'

    process_only_new_candles = True
    startup_candle_count = 300

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # ATR-based trailing stop (basit versiyon)
        # key_value = 1, atr_period = 3
        atr = ta.ATR(dataframe, timeperiod=3)
        highest_high = dataframe['high'].rolling(3).max()
        
        # Long stop (trailing stop seviyesi)
        dataframe['atr_stop'] = highest_high - (atr * 1)
        
        # EMA filter
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        
        # Trend direction (ema cross)
        dataframe['ema_trend'] = np.where(dataframe['ema_50'] > dataframe['ema_200'], 1, -1)
        
        # ADX - trend strength
        dataframe['adx'] = ta.ADX(dataframe)
        
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        
        # Volume
        dataframe['volume_sma'] = dataframe['volume'].rolling(20).mean()
        
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['buy'] = 0
        
        volume_filter = dataframe['volume'] > dataframe['volume_sma'] * 0.5
        
        # Entry: Fiyat ATR stop'ın üzerinde + EMA uptrend + ADX güçlü
        buy_conditions = (
            (dataframe['close'] > dataframe['atr_stop']) &  # ATR stop above
            (dataframe['ema_trend'] == 1) &                # EMA uptrend
            (dataframe['adx'] > 20) &                      # Trend strength
            (dataframe['rsi'] < 65) &                      # Not overbought
            (dataframe['volume'] > 0) &
            volume_filter
        )
        
        dataframe.loc[buy_conditions, 'buy'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0
        return dataframe