# HybridApexV3 - Hybrid Strategy with DCA and NASOS-style Stoploss
# Combines: Anti-Pump Filter, CMF, DCA, Dynamic Stoploss

import logging
import numpy as np
import pandas as pd
from datetime import datetime
from typing import Optional

from freqtrade.strategy import (IStrategy, IntParameter, DecimalParameter, 
                                 merge_informative_pair, stoploss_from_open)
from freqtrade.persistence import Trade
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib

logger = logging.getLogger(__name__)


def chaikin_money_flow(dataframe, n=20):
    mfv = ((dataframe['close'] - dataframe['low']) - (dataframe['high'] - dataframe['close'])) / (dataframe['high'] - dataframe['low'])
    mfv = mfv.fillna(0.0)
    mfv *= dataframe['volume']
    cmf = (mfv.rolling(n, min_periods=0).sum() / dataframe['volume'].rolling(n, min_periods=0).sum())
    return pd.Series(cmf, name='cmf')


def VWAPB(dataframe, window_size=20, num_of_std=1):
    df = dataframe.copy()
    df['vwap'] = qtpylib.rolling_vwap(df, window=window_size)
    rolling_std = df['vwap'].rolling(window=window_size).std()
    df['vwap_low'] = df['vwap'] - (rolling_std * num_of_std)
    return df['vwap_low']


class HybridApexV3(IStrategy):
    INTERFACE_VERSION = 3

    timeframe = '5m'
    informative_timeframe = '1h'

    # DCA Settings
    position_adjustment_enable = True
    max_entry_position_adjustment = 3
    max_dca_multiplier = 1.5

    # NASOS Dynamic Stoploss Settings
    use_custom_stoploss = True
    pHSL = DecimalParameter(-0.150, -0.050, default=-0.10, space='sell')
    pPF_1 = DecimalParameter(0.010, 0.025, default=0.016, space='sell')
    pSL_1 = DecimalParameter(0.010, 0.020, default=0.014, space='sell')
    pPF_2 = DecimalParameter(0.040, 0.080, default=0.050, space='sell')
    pSL_2 = DecimalParameter(0.020, 0.050, default=0.030, space='sell')

    # Anti-Pump Settings
    anti_pump_threshold = DecimalParameter(1.10, 1.30, default=1.15, space='buy')

    # Minimal ROI - earlier profit taking
    minimal_roi = {
        "0": 0.05,
        "30": 0.03,
        "60": 0.02,
        "180": 0
    }

    stoploss = -0.10

    # Trailing stop - more conservative
    trailing_stop = True
    trailing_stop_positive = 0.03
    trailing_stop_positive_offset = 0.04
    trailing_only_offset_is_reached = True

    def informative_pairs(self):
        pairs = self.dp.current_whitelist()
        return [(pair, self.informative_timeframe) for pair in pairs]

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # 1H INFORMATIVE (Anti-Pump & CMF)
        inf_tf = self.informative_timeframe
        informative = self.dp.get_pair_dataframe(pair=metadata['pair'], timeframe=inf_tf)

        informative['cmf'] = chaikin_money_flow(informative, 20)
        informative['rsi'] = ta.RSI(informative, timeperiod=14)

        informative['rolling_max_24'] = informative['high'].rolling(24).max()
        informative['rolling_min_24'] = informative['low'].rolling(24).min()
        informative['pump_ratio'] = informative['rolling_max_24'] / informative['rolling_min_24']
        informative['safe_pump'] = informative['pump_ratio'] < self.anti_pump_threshold.value

        dataframe = merge_informative_pair(dataframe, informative, self.timeframe, inf_tf, ffill=True)

        # 5M Normal Indicators
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=4)
        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['vwap_low'] = VWAPB(dataframe, 20, 1)
        
        # ATR for volatility
        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Initialize columns
        dataframe['enter_long'] = 0
        dataframe['enter_tag'] = ''

        # Entry conditions:
        # 1. RSI oversold (< 30)
        # 2. Price below EMA20 (buy the dip)
        # 3. Anti-pump filter (1h timeframe)
        # 4. Volume > 0
        dataframe.loc[
            (
                (dataframe['rsi'] < 30) &
                (dataframe['close'] < dataframe['ema_20']) &
                (dataframe[f'safe_pump_{self.informative_timeframe}'] == True) &
                (dataframe['volume'] > 0)
            ),
            ['enter_long', 'enter_tag']
        ] = (1, 'rsi_oversold')

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        # Initialize columns
        dataframe['exit_long'] = 0
        dataframe['exit_tag'] = ''

        # Exit conditions - more relaxed:
        # 1. RSI very overbought (>80) and turning down
        # 2. Strong trend reversal: price below EMA20 + RSI turning down
        dataframe.loc[
            (
                (dataframe['rsi'] > 80) &
                (dataframe['rsi'] < dataframe['rsi'].shift(1)) &
                (dataframe['volume'] > 0)
            ),
            ['exit_long', 'exit_tag']
        ] = (1, 'rsi_very_high')

        # Alternative: trend reversal
        dataframe.loc[
            (
                (dataframe['close'] < dataframe['ema_50']) &
                (dataframe['rsi_fast'] > 70) &
                (dataframe['rsi_fast'] < dataframe['rsi_fast'].shift(1)) &
                (dataframe['volume'] > 0)
            ),
            ['exit_long', 'exit_tag']
        ] = (1, 'trend_reversal')

        return dataframe

    # NASOS DYNAMIC STOPLOSS MODULE
    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float, **kwargs) -> float:

        HSL = self.pHSL.value
        PF_1 = self.pPF_1.value
        SL_1 = self.pSL_1.value
        PF_2 = self.pPF_2.value
        SL_2 = self.pSL_2.value

        if current_profit > PF_2:
            sl_profit = SL_2 + (current_profit - PF_2)
        elif current_profit > PF_1:
            sl_profit = SL_1 + ((current_profit - PF_1) * (SL_2 - SL_1) / (PF_2 - PF_1))
        else:
            sl_profit = HSL

        if sl_profit >= current_profit:
            return -0.99

        return stoploss_from_open(sl_profit, current_profit)

    # DCA MODULE
    def adjust_trade_position(self, trade: Trade, current_time: datetime,
                              current_rate: float, current_profit: float, min_stake: float,
                              max_stake: float, current_entry_rate: float, current_exit_rate: float,
                              current_entry_profit: float, current_exit_profit: float, 
                              **kwargs) -> Optional[float]:

        # Only DCA when in loss
        if current_profit > -0.02:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe.empty:
            return None
            
        last_candle = dataframe.iloc[-1].squeeze()

        filled_entries = trade.select_filled_orders(trade.entry_side)
        count_of_entries = len(filled_entries)

        if count_of_entries > self.max_entry_position_adjustment:
            return None

        # Smart DCA conditions:
        # Price below VWAP band + positive CMF (money flow) + 1h RSI oversold
        cmf_1h = last_candle.get(f'cmf_{self.informative_timeframe}', 0)
        rsi_1h = last_candle.get(f'rsi_{self.informative_timeframe}', 50)
        vwap_low = last_candle.get('vwap_low', 0)

        if (current_rate < vwap_low) and (cmf_1h > 0) and (rsi_1h < 40):
            try:
                stake_amount = filled_entries[0].cost * (self.max_dca_multiplier ** count_of_entries)
                logger.info(f"Smart DCA Triggered! {trade.pair} | Entry: {count_of_entries} | CMF_1H: {cmf_1h:.3f}")
                return min(stake_amount, max_stake)
            except Exception as e:
                logger.warning(f"DCA calculation error: {e}")
                return None

        return None