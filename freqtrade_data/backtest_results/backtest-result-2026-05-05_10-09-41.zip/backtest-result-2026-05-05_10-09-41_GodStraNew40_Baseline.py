"""
GodStraNew40_Baseline - Baseline Comparison Strategy

Purpose: Compare genetic algorithm strategy with simple baseline.
This is used to detect overfitting - if GA is not significantly better
than simple baseline, then we have overfitting risk.

Baseline logic: Simple SMA crossover without genetic optimization.
"""

from freqtrade.strategy import IStrategy, CategoricalParameter
from pandas import DataFrame, Series as PdSeries
import talib.abstract as ta
from functools import reduce

TREND_CHECK_CANDLES = 4
VOLUME_MIN_THRESHOLD = 10

buy_params = {
    "buy_indicator0": "SMA-50",
    "buy_crossed_indicator0": "SMA-20",
    "buy_operator0": "<R",
    "buy_real_num0": 0.0,
    "buy_indicator1": "SMA-50",
    "buy_crossed_indicator1": "SMA-20",
    "buy_operator1": ">",
    "buy_real_num1": 0.0,
}

sell_params = {
    "sell_indicator0": "SMA-50",
    "sell_crossed_indicator0": "SMA-20",
    "sell_operator0": ">R",
    "sell_real_num0": 0.0,
    "sell_indicator1": "SMA-50",
    "sell_crossed_indicator1": "SMA-20",
    "sell_operator1": "<",
    "sell_real_num1": 0.0,
}

god_genes_with_timeperiod = ['SMA-5', 'SMA-10', 'SMA-20', 'SMA-50', 'SMA-100']


class GodStraNew40_Baseline(IStrategy):
    """
    GodStraNew40_Baseline - Simple SMA Strategy for Comparison

    Purpose: Detect overfitting by comparing with baseline.
    If genetic algorithm is not significantly better than this simple
    strategy, we have overfitting.
    """
    INTERFACE_VERSION = 3
    can_short = False

    timeframe = '15m'

    stoploss = -0.10
    minimal_roi = {"0": 0.02, "60": 0.01, "120": 0.005}

    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.02
    trailing_only_offset_is_reached = True

    buy_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_indicator0"], space='buy')
    buy_crossed_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=buy_params["buy_crossed_indicator0"], space='buy')
    buy_operator0 = CategoricalParameter(
        ['<R', '>', 'CB', 'CUT', 'OT'], default=buy_params["buy_operator0"], space='buy')
    buy_real_num0 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.5, 1.0], default=buy_params["buy_real_num0"], space='buy')

    sell_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_indicator0"], space='sell')
    sell_crossed_indicator0 = CategoricalParameter(
        god_genes_with_timeperiod, default=sell_params["sell_crossed_indicator0"], space='sell')
    sell_operator0 = CategoricalParameter(
        ['>R', '<', 'CB', 'CUT', 'OT'], default=sell_params["sell_operator0"], space='sell')
    sell_real_num0 = CategoricalParameter(
        [0.0, 0.1, 0.2, 0.5, 1.0], default=sell_params["sell_real_num0"], space='sell')

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        for period in [5, 10, 20, 50, 100]:
            dataframe[f'SMA-{period}'] = ta.SMA(dataframe, timeperiod=period)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        sma_50 = dataframe['SMA-50'].fillna(0)
        trend_sma = ta.SMA(sma_50, timeperiod=TREND_CHECK_CANDLES)
        trend_prev = PdSeries(trend_sma).shift(1).values

        condition = (
            (dataframe['volume'] > VOLUME_MIN_THRESHOLD) &
            (sma_50 > 0) &
            (sma_50 < dataframe['close']) &
            (trend_prev < trend_sma)
        )
        conditions.append(condition)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'enter_long'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        sma_50 = dataframe['SMA-50'].fillna(0)
        trend_sma = ta.SMA(sma_50, timeperiod=TREND_CHECK_CANDLES)
        trend_prev = PdSeries(trend_sma).shift(1).values

        condition = (
            (dataframe['volume'] > VOLUME_MIN_THRESHOLD) &
            (sma_50 > 0) &
            (sma_50 > dataframe['close']) &
            (trend_prev > trend_sma)
        )
        conditions.append(condition)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'exit_long'] = 1
        return dataframe