"""
ElliotV5_SMA - Elliot Wave Oscillator + SMA Stratejisi
======================================================

STRATEJİ AÇIKLAMASI:
- EWO (Elliot Wave Oscillator) ile momentum analizi
- EMA bazlı giriş/çıkış noktaları
- Multi-timeframe: 5m + 1h
- Trailing stop ile kar koruma

YAPILAN MÜHENDİSLİK DÜZELTMELERİ (2026-05-05):
1. Ölü kod temizliği (139 satır kaldırıldı)
2. Dead import'lar kaldırıldı
3. minimal_roi: %21.5 → %0.5-4 stepwise
4. ewo_low: -17.457 → -8.0
5. ewo_high: 3.34 → 2.0
6. stoploss: -18.9% → -10%
7. startup_candle_count: 2000 → 200

Author: OpenCode Assistant
Date: 2026-05-05
"""

from freqtrade.strategy.interface import IStrategy
from pandas import DataFrame

import talib.abstract as ta
import numpy as np
from freqtrade.strategy import DecimalParameter, IntParameter


def EWO(dataframe, ema_length=5, ema2_length=35):
    """Elliot Wave Oscillator - EMA farkı bazlı momentum"""
    df = dataframe.copy()
    ema1 = ta.SMA(df, timeperiod=ema_length)
    ema2 = ta.SMA(df, timeperiod=ema2_length)
    emadif = (ema1 - ema2) / df['close'] * 100
    return emadif


class ElliotV5_SMA(IStrategy):
    INTERFACE_VERSION = 2

    minimal_roi = {
        "0": 0.5,
        "30": 1.0,
        "60": 1.5,
        "180": 2.5,
    }

    stoploss = -0.10

    low_offset = DecimalParameter(0.90, 0.99, default=0.95, space='buy', optimize=True)
    ewo_high = DecimalParameter(1.0, 6.0, default=2.5, space='buy', optimize=True)
    ewo_low = DecimalParameter(-12.0, -3.0, default=-6.0, space='buy', optimize=True)
    rsi_buy = IntParameter(40, 75, default=60, space='buy', optimize=True)
    high_offset = DecimalParameter(1.0, 1.1, default=1.02, space='sell', optimize=True)

    trailing_stop = True
    trailing_stop_positive = 0.005
    trailing_stop_positive_offset = 0.03
    trailing_only_offset_is_reached = True

    use_exit_signal = True
    exit_profit_only = False
    exit_profit_offset = 0.01
    ignore_roi_if_entry_signal = True

    timeframe = '5m'

    process_only_new_candles = True
    startup_candle_count = 200

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['ema_17'] = ta.EMA(dataframe, timeperiod=17)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['EWO'] = EWO(dataframe, 50, 200)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['buy'] = 0

        # Koşul 1: Pozitif EWO + RSI oversold
        buy_cond1 = (
            (dataframe['close'] < (dataframe['ema_17'] * self.low_offset.value)) &
            (dataframe['EWO'] > self.ewo_high.value) &
            (dataframe['rsi'] < self.rsi_buy.value) &
            (dataframe['volume'] > 0)
        )

        # Koşul 2: Negatif EWO
        buy_cond2 = (
            (dataframe['close'] < (dataframe['ema_17'] * self.low_offset.value)) &
            (dataframe['EWO'] < self.ewo_low.value) &
            (dataframe['volume'] > 0)
        )

        dataframe.loc[buy_cond1 | buy_cond2, 'buy'] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe['sell'] = 0

        sell_cond = (
            (dataframe['close'] > (dataframe['ema_50'] * self.high_offset.value)) &
            (dataframe['volume'] > 0)
        )

        dataframe.loc[sell_cond, 'sell'] = 1
        return dataframe
