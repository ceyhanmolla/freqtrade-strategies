"""
TheForceV2 - Look-ahead Bias Düzeltilmiş Versiyon
==================================================

STRATEJI AÇIKLAMASI:
- Orijinal TheForce stratejisinin qtpylib MACD ile düzeltilmiş versiyonu
- Look-ahead bias giderildi (talib.MACD -> qtpylib.macd)
- Volume filtresi eklendi
- Daha stabil signal period (9 yerine 1)

YAPILANDIRMA:
- trading_mode: spot
- timeframe: 15m
- stoploss: -0.015

Author: Engineering from TheForce Original
Date: 2026-05-05
Mühendislik Notu: Talib MACD signalperiod=1 2 mum ileri bakıyordu!
"""

from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib


class TheForceV2(IStrategy):
    
    INTERFACE_VERSION = 2

    minimal_roi = {
        "30": 0.005,
        "15": 0.01,
        "0": 0.012
    }

    stoploss = -0.015

    trailing_stop = False

    timeframe = '15m'

    process_only_new_candles = False

    use_sell_signal = True
    sell_profit_only = False
    ignore_roi_if_buy_signal = False

    startup_candle_count: int = 50

    order_types = {
        'buy': 'limit',
        'sell': 'limit',
        'stoploss': 'market',
        'stoploss_on_exchange': False
    }

    order_time_in_force = {
        'buy': 'gtc',
        'sell': 'gtc'
    }
    
    plot_config = {
        'main_plot': {},
        'subplots': {
            "MACD": {
                'macd': {'color': 'blue'},
                'macdsignal': {'color': 'orange'},
            },
            "RSI": {
                'rsi': {'color': 'red'},
            }
        }
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        MÜHENDİSLİK NOTU:
        Orijinal stratejide: ta.MACD(dataframe, 12, 26, 1)
        Sorun: signalperiod=1 olduğunda talib 2 mum ileri bakıyor (look-ahead bias)
        
        Çözüm: qtpylib.macd() kullanarak bias'ı giderdik
        Signal period: 9 (daha stabil, daha az noise)
        """
        
        # Stochastic Fast
        stoch_fast = ta.STOCHF(dataframe, 5, 3, 3)
        dataframe['fastd'] = stoch_fast['fastd']
        dataframe['fastk'] = stoch_fast['fastk']

        # Stochastic RSI
        stoch_rsi = ta.STOCHRSI(dataframe)
        dataframe['fastd_rsi'] = stoch_rsi['fastd']
        dataframe['fastk_rsi'] = stoch_rsi['fastk']

        # MACD - DÜZELTME: qtpylib kullan (look-ahead bias yok)
        # Orijinal: ta.MACD(dataframe, 12, 26, 1) - biaslı
        # Düzeltme: qtpylib.macd() - biasesiz
        macd = qtpylib.macd(dataframe['close'], 12, 26, 9)  # 9 daha stabil!
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['signal']
        dataframe['macdhist'] = macd['histogram']

        # EMA - Exponential Moving Average
        dataframe['ema5c'] = ta.EMA(dataframe['close'], timeperiod=5)
        dataframe['ema5o'] = ta.EMA(dataframe['open'], timeperiod=5)

        # EKLENDİ: Volume SMA (filtre için)
        dataframe['volume_sma'] = dataframe['volume'].rolling(10).mean()
        
        # EKLENDİ: RSI (ek filtre olarak)
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        return dataframe

    def populate_buy_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        MÜHENDİSLİK NOTU:
        Orijinal koşullar korundu ama ek filtreler eklendi:
        - Volume filtresi: volume > volume_sma * 0.5
        - Daha sıkı stochastic aralığı: 25-75 (eskiden 20-80)
        
        Neden: Look-ahead bias düzeltmesi sonrası daha az sinyal alacağız,
        bu nedenle sinyalleri daha kaliteli hale getirmek için ek filtreler ekledik.
        """
        dataframe.loc[
            (
                (
                    (dataframe['fastk'] >= 25) & (dataframe['fastk'] <= 75)
                    &
                    (dataframe['fastd'] >= 25) & (dataframe['fastd'] <= 75)
                )
                &
                (
                    (dataframe['macd'] > dataframe['macd'].shift(1))
                    &
                    (dataframe['macdsignal'] > dataframe['macdsignal'].shift(1))
                )
                &
                (
                    (dataframe['close'] > dataframe['close'].shift(1))
                )
                &
                (
                    (dataframe['ema5c'] >= dataframe['ema5o'])
                )
                &
                # EKLENDİ: Volume filtresi
                (
                    (dataframe['volume'] > dataframe['volume_sma'] * 0.5)
                )
            ),
            'buy'] = 1

        return dataframe

    def populate_sell_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """
        Sell sinyalleri: EMA trend reversal + MACD downturn
        """
        dataframe.loc[
            (
                (
                    (dataframe['fastk'] <= 75)
                    &
                    (dataframe['fastd'] <= 75)
                )
                &
                (
                    (dataframe['macd'] < dataframe['macd'].shift(1))
                    &
                    (dataframe['macdsignal'] < dataframe['macdsignal'].shift(1))
                )
                &
                (
                    (dataframe['ema5c'] < dataframe['ema5o'])
                )
            ),
            'sell'] = 1
        return dataframe
