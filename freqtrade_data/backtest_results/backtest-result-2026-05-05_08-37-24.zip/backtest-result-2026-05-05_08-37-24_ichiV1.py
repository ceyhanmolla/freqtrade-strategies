import logging
from freqtrade.strategy import IStrategy
from freqtrade.strategy import (CategoricalParameter, DecimalParameter, 
                                IntParameter)
from pandas import DataFrame
import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas as pd
pd.options.mode.chained_assignment = None
from functools import reduce
from datetime import datetime

logger = logging.getLogger(__name__)


def ichimoku_manual(dataframe, conversion_line_period=20, base_line_periods=60, laggin_span=120, displacement=30):
    high = dataframe['high']
    low = dataframe['low']
    close = dataframe['close']
    
    conversion_line = (high.rolling(conversion_line_period).max() + low.rolling(conversion_line_period).min()) / 2
    base_line = (high.rolling(base_line_periods).max() + low.rolling(base_line_periods).min()) / 2
    
    leading_senkou_span_a = ((conversion_line + base_line) / 2).shift(displacement)
    
    leading_senkou_span_b = ((high.rolling(52).max() + low.rolling(52).min()) / 2).shift(displacement)
    
    return {
        'tenkan_sen': conversion_line,
        'kijun_sen': base_line,
        'senkou_span_a': leading_senkou_span_a,
        'senkou_span_b': leading_senkou_span_b,
    }


class ichiV1(IStrategy):

    INTERFACE_VERSION = 3
    can_short = False

    buy_trend_above_senkou_level = IntParameter(1, 8, default=5, space="buy")
    buy_trend_bullish_level = IntParameter(1, 8, default=6, space="buy")
    buy_fan_magnitude_shift_value = IntParameter(1, 8, default=5, space="buy")
    buy_min_fan_magnitude_gain = DecimalParameter(0.980, 1.020, default=1.002, space="buy")
    
    sell_trend_indicator = CategoricalParameter(
        ["trend_close_5m", "trend_close_15m", "trend_close_30m", "trend_close_1h"], 
        default="trend_close_15m", 
        space="sell"
    )

    minimal_roi = {
        "0": 0.061,
        "3": 0.023,
        "6": 0.008,
        "19": 0
    }

    stoploss = -0.217

    timeframe = '1m'

    startup_candle_count = 130
    process_only_new_candles = False

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False
    
    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        heikinashi = qtpylib.heikinashi(dataframe)
        dataframe_open = heikinashi['open']
        dataframe_close = dataframe['close']

        dataframe['trend_close_5m'] = dataframe_close
        dataframe['trend_close_15m'] = ta.EMA(dataframe_close, timeperiod=3)
        dataframe['trend_close_30m'] = ta.EMA(dataframe_close, timeperiod=6)
        dataframe['trend_close_1h'] = ta.EMA(dataframe_close, timeperiod=12)
        dataframe['trend_close_2h'] = ta.EMA(dataframe_close, timeperiod=24)
        dataframe['trend_close_4h'] = ta.EMA(dataframe_close, timeperiod=48)

        dataframe['trend_open_5m'] = dataframe_open
        dataframe['trend_open_15m'] = ta.EMA(dataframe_open, timeperiod=3)
        dataframe['trend_open_30m'] = ta.EMA(dataframe_open, timeperiod=6)
        dataframe['trend_open_1h'] = ta.EMA(dataframe_open, timeperiod=12)
        dataframe['trend_open_2h'] = ta.EMA(dataframe_open, timeperiod=24)
        dataframe['trend_open_4h'] = ta.EMA(dataframe_open, timeperiod=48)

        dataframe['fan_magnitude'] = (dataframe['trend_close_1h'] / dataframe['trend_close_4h'])
        dataframe['fan_magnitude_gain'] = dataframe['fan_magnitude'] / dataframe['fan_magnitude'].shift(1)

        ichimoku = ichimoku_manual(dataframe, conversion_line_period=20, base_line_periods=60, laggin_span=120, displacement=30)
        
        dataframe['senkou_a'] = ichimoku['senkou_span_a']
        dataframe['senkou_b'] = ichimoku['senkou_span_b']

        return dataframe


    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        conditions = []

        if self.buy_trend_above_senkou_level.value >= 1:
            conditions.append(dataframe['trend_close_5m'] > dataframe['senkou_a'])
            conditions.append(dataframe['trend_close_5m'] > dataframe['senkou_b'])

        if self.buy_trend_above_senkou_level.value >= 2:
            conditions.append(dataframe['trend_close_15m'] > dataframe['senkou_a'])
            conditions.append(dataframe['trend_close_15m'] > dataframe['senkou_b'])

        if self.buy_trend_above_senkou_level.value >= 4:
            conditions.append(dataframe['trend_close_1h'] > dataframe['senkou_a'])
            conditions.append(dataframe['trend_close_1h'] > dataframe['senkou_b'])

        if self.buy_trend_bullish_level.value >= 1:
            conditions.append(dataframe['trend_close_5m'] > dataframe['trend_open_5m'])

        if self.buy_trend_bullish_level.value >= 2:
            conditions.append(dataframe['trend_close_15m'] > dataframe['trend_open_15m'])

        if self.buy_trend_bullish_level.value >= 4:
            conditions.append(dataframe['trend_close_1h'] > dataframe['trend_open_1h'])

        conditions.append(dataframe['fan_magnitude_gain'] >= self.buy_min_fan_magnitude_gain.value)
        conditions.append(dataframe['fan_magnitude'] > 1)

        for x in range(self.buy_fan_magnitude_shift_value.value):
            conditions.append(dataframe['fan_magnitude'].shift(x+1) < dataframe['fan_magnitude'])

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'enter_long'] = 1

        return dataframe


    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:

        conditions = []

        conditions.append(qtpylib.crossed_below(dataframe['trend_close_5m'], dataframe[self.sell_trend_indicator.value]))

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'exit_long'] = 1

        return dataframe