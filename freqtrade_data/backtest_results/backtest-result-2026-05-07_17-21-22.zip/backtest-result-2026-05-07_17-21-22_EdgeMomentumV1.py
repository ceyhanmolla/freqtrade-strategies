"""
EdgeMomentumV1 — Edge-Tabanlı Momentum Stratejisi
==================================================
Polymarket UP/DOWN stratejisinin yapısını kullanır:
- has_edge() ile model vs market olasılık karşılaştırması
- Direction-based alpha/floor parametreleri
- Sürekli edge fonksiyonu (doubt compression)

Uyarlama:
- model_prob: indikatörlerden hesaplanan bileşik olasılık (0-1)
- market_prob: fiyatın mevcut pozisyonu (0-1)
- Edge: model_prob > required_model_prob(market_prob, alpha, floor)

Entry:
  Long: model_prob_bullish > required(market_prob, alpha_long, floor_long)
  Short: model_prob_bearish > required(market_prob, alpha_short, floor_short)

Exit:
  minimal_roi (stepwise take profit)
  trailing_stop
  custom_stoploss (ATR-based)

Indicators:
  model_prob_bullish: composite of RSI, BB, trend — higher when oversold
  model_prob_bearish: composite inverted — higher when overbought
  market_prob: normalized RSI (0-1) — what market is currently pricing
"""

import numpy as np
import pandas as pd
import talib.abstract as ta
from freqtrade.strategy import IStrategy
from freqtrade.persistence import Trade
from datetime import datetime


def required_model_prob(market_prob: float, alpha: float = 1.5, floor: float = 0.35) -> float:
    if market_prob <= 0.0:
        return floor
    if market_prob >= 1.0:
        return 1.0
    raw = 1.0 - (1.0 - market_prob) ** alpha
    return max(floor, raw)


def has_edge(model_prob: float, market_prob: float, alpha: float = 1.5, floor: float = 0.35) -> bool:
    if market_prob < floor:
        return False
    if model_prob <= market_prob:
        return False
    return model_prob >= required_model_prob(market_prob, alpha, floor)


class EdgeMomentumV1(IStrategy):

    INTERFACE_VERSION = 2

    timeframe = '15m'

    minimal_roi = {
        "0": 0.08,
        "30": 0.04,
        "60": 0.02,
        "120": 0.01,
    }

    stoploss = -0.08

    trailing_stop = True
    trailing_stop_positive = 0.015
    trailing_stop_positive_offset = 0.025
    trailing_only_offset_is_reached = True

    use_custom_stoploss = True

    startup_candle_count = 100

    process_only_new_candles = True

    can_short = False

    custom_info = {}

    # Edge parameters
    alpha_long = 1.8
    alpha_short = 1.8
    floor_long = 0.30
    floor_short = 0.30
    min_model_prob = 0.20

    def custom_stoploss(self, pair: str, trade: Trade, current_time: datetime,
                        current_rate: float, current_profit: float,
                        after_fill: bool, **kwargs) -> float:

        if current_profit > 0:
            return current_profit * 0.5

        if current_profit < -0.05:
            return -0.05

        return -1

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)
        dataframe['rsi_fast'] = ta.RSI(dataframe, timeperiod=7)

        dataframe['ema_20'] = ta.EMA(dataframe, timeperiod=20)
        dataframe['ema_50'] = ta.EMA(dataframe, timeperiod=50)
        dataframe['ema_200'] = ta.EMA(dataframe, timeperiod=200)

        bb = ta.BBANDS(dataframe, timeperiod=20, nbdevup=2.0, nbdevdn=2.0)
        dataframe['bb_lower'] = bb['lowerband']
        dataframe['bb_middle'] = bb['middleband']
        dataframe['bb_upper'] = bb['upperband']
        dataframe['bb_width'] = (dataframe['bb_upper'] - dataframe['bb_lower']) / dataframe['bb_middle']

        dataframe['atr'] = ta.ATR(dataframe, timeperiod=14)

        dataframe['adx'] = ta.ADX(dataframe, timeperiod=14)
        dataframe['plus_di'] = ta.PLUS_DI(dataframe, timeperiod=14)
        dataframe['minus_di'] = ta.MINUS_DI(dataframe, timeperiod=14)

        dataframe['cmf'] = ta.ADOSC(dataframe, timeperiod_fast=3, timeperiod_slow=10)

        dataframe['volume_sma'] = dataframe['volume'].rolling(window=20).mean()
        dataframe['volume_ratio'] = dataframe['volume'] / dataframe['volume_sma']

        window = 20
        dataframe['hh'] = dataframe['high'].rolling(window=window).max()
        dataframe['ll'] = dataframe['low'].rolling(window=window).min()
        dataframe['range_pos'] = (dataframe['close'] - dataframe['ll']) / (dataframe['hh'] - dataframe['ll'])
        dataframe['range_pos'] = dataframe['range_pos'].clip(0, 1)

        # === model_prob_bullish (0-1): how bullish the composite picture is ===
        rsi_reversed = 1.0 - (dataframe['rsi'] / 100.0)

        bb_pos = np.where(
            dataframe['bb_upper'] != dataframe['bb_lower'],
            (dataframe['bb_upper'] - dataframe['close']) / (dataframe['bb_upper'] - dataframe['bb_lower']),
            0.5
        )
        bb_pos = np.clip(bb_pos, 0, 1)

        trend_bullish = ((dataframe['close'] > dataframe['ema_50'])).astype(float)

        vol_confirmation = (dataframe['volume_ratio'] > 1.2).astype(float) * 0.5

        di_bullish = (dataframe['plus_di'] > dataframe['minus_di']).astype(float) * 0.3

        rsi_component = rsi_reversed * 0.35
        bb_component = bb_pos * 0.25
        trend_component = trend_bullish * 0.20
        vol_component = vol_confirmation * 0.10
        di_component = di_bullish * 0.10

        dataframe['model_prob_bullish'] = (rsi_component + bb_component + trend_component
                                            + vol_component + di_component).clip(0, 1)

        # === model_prob_bearish (0-1): how bearish the composite picture is ===
        rsi_direct = dataframe['rsi'] / 100.0

        bb_pos_rev = np.where(
            dataframe['bb_upper'] != dataframe['bb_lower'],
            (dataframe['close'] - dataframe['bb_lower']) / (dataframe['bb_upper'] - dataframe['bb_lower']),
            0.5
        )
        bb_pos_rev = np.clip(bb_pos_rev, 0, 1)

        trend_bearish = ((dataframe['close'] < dataframe['ema_50'])).astype(float)

        di_bearish = (dataframe['minus_di'] > dataframe['plus_di']).astype(float) * 0.3

        rsi_component_b = rsi_direct * 0.35
        bb_component_b = bb_pos_rev * 0.25
        trend_component_b = trend_bearish * 0.20
        vol_component_b = vol_confirmation * 0.10
        di_component_b = di_bearish * 0.10

        dataframe['model_prob_bearish'] = (rsi_component_b + bb_component_b + trend_component_b
                                            + vol_component_b + di_component_b).clip(0, 1)

        # === market_prob (0-1): what the market is pricing in ===
        dataframe['market_prob'] = (dataframe['rsi'] / 100.0).clip(0, 1)

        # === edge indicators (for debugging/reference) ===
        dataframe['required_prob_long'] = dataframe['market_prob'].apply(
            lambda p: required_model_prob(p, self.alpha_long, self.floor_long)
        )
        dataframe['required_prob_short'] = dataframe['market_prob'].apply(
            lambda p: required_model_prob(p, self.alpha_short, self.floor_short)
        )

        dataframe['has_edge_long'] = dataframe.apply(
            lambda row: has_edge(
                row['model_prob_bullish'],
                row['market_prob'],
                self.alpha_long,
                self.floor_long
            ),
            axis=1
        )
        dataframe['has_edge_short'] = dataframe.apply(
            lambda row: has_edge(
                row['model_prob_bearish'],
                1 - row['market_prob'],
                self.alpha_short,
                self.floor_short
            ),
            axis=1
        )

        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[
            (
                (dataframe['volume'] > 0) &
                (dataframe['has_edge_long'] == True) &
                (dataframe['model_prob_bullish'] >= self.min_model_prob) &
                (dataframe['adx'] > 15) &
                (dataframe['volume_ratio'] > 0.5)
            ),
            'enter_long'
        ] = 1

        dataframe.loc[
            (
                (dataframe['volume'] > 0) &
                (dataframe['has_edge_short'] == True) &
                (dataframe['model_prob_bearish'] >= self.min_model_prob) &
                (dataframe['adx'] > 15) &
                (dataframe['volume_ratio'] > 0.5)
            ),
            'enter_short'
        ] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        return dataframe
